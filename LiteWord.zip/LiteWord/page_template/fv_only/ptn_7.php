<!-- wp:wdl/fv-7 -->
<div class="wp-block-wdl-fv-7 fv-7 undefined"><div class="fv-7__inner"><h1 class="title"><div class="sub">初心者のためのWordPressテーマ</div><div class="main">LiteWord</div></h1><p class="description">テキストテキストテキストテキストテキストテキスト</p><div class="btn"><a href="" class="btn-text">詳細はこちら</a></div></div><div class="bg_image"><video autoplay muted loop playsinline data-playback-rate="1" class="lazy-video" style="display:none"><source src="https://cdn.pixabay.com/video/2023/11/19/189813-887078786_large.mp4" type="video/mp4"/></video><div class="filter" style="background-color:#000000;opacity:0.5"></div></div><script>
                        document.addEventListener('DOMContentLoaded', function() {
                            const video = document.querySelector('.fv-7 .lazy-video');
                            if (video) {
                                video.style.display = 'block';
                                video.playbackRate = video.getAttribute('data-playback-rate');
                            }
                        });
                        </script></div>
<!-- /wp:wdl/fv-7 -->