<!-- wp:wdl/shin-gas-station-01-fv-lower-01 {"mainTitle":"お問い合わせ","subTitle":"Contact","filterBackgroundColor":"#f7fcfd","filterOpacity":1} -->
<div class="wp-block-wdl-shin-gas-station-01-fv-lower-01 shin-gas-station-01-fv-lower-01 min-h-pc-380px min-h-tb-300px min-h-sp-220px"><div class="shin-gas-station-01-fv-lower-01_inner" style="max-width:100%"><h1><span class="main">お問い合わせ</span><span class="sub">Contact</span></h1></div><div class="filter" style="background-color:#f7fcfd;opacity:1"></div></div>
<!-- /wp:wdl/shin-gas-station-01-fv-lower-01 -->

<!-- wp:wdl/lw-space-1 {"pcHeight":64,"tbHeight":40,"spHeight":32} -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:64px"></div><div class="tb" style="height:40px"></div><div class="sp" style="height:32px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:wdl/shin-gas-station-01-contact -->
<div class="wp-block-wdl-shin-gas-station-01-contact shin-gas-station-01-contact">[lw_mail_form_select id='1']</div>
<!-- /wp:wdl/shin-gas-station-01-contact -->