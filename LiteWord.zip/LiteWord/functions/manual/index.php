<?php
if ( !defined( 'ABSPATH' ) ) exit;
get_template_part('./functions/manual/info');
get_template_part('./functions/manual/contents');