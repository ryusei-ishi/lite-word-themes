<!-- wp:heading {"level":3,"className":"is-style-h_03"} -->
<h3 class="wp-block-heading is-style-h_03">基本設定</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul style="list-style-type:undefined" class="wp-block-list"><!-- wp:list-item -->
<li><a href="https://www.youtube.com/watch?v=OJGjMe80J7I" target="_blank" rel="noreferrer noopener">noindex解除方法</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/OJGjMe80J7I?si=Nn5v4CVLD8msPiUP&amp;t=89" target="_blank" rel="noreferrer noopener">アナリティクス登録の流れ</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/OJGjMe80J7I?si=7hJ1XiX5IUN5N33b&amp;t=729" target="_blank" rel="noreferrer noopener">サーチコンソールの設定</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/CDd23_FGLWM" target="_blank" rel="noreferrer noopener">サイトタイトルとメタディスクリプションの設定</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/rnA7PT7JC78" target="_blank" rel="noreferrer noopener">固定ページ・投稿ページのタイトルとメタディスクリプションの設定</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/-HoZdgxsjJ0" target="_blank" rel="noreferrer noopener">カテゴリーページのタイトルとメタディスクリプションの設定</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://www.youtube.com/watch?v=RhhA0T-9MZ4">OGP設定</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/AZFcHuWfjaE" target="_blank" rel="noreferrer noopener">サイトマップ設定について</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/EvKy5yvlvTU" target="_blank" rel="noreferrer noopener">クローラーへの通知設定について</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p class=""></p>
<!-- /wp:paragraph -->