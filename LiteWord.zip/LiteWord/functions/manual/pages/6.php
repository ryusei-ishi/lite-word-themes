<!-- wp:heading {"level":3,"className":"is-style-h_03"} -->
<h3 class="wp-block-heading is-style-h_03">基本</h3>
<!-- /wp:heading -->

<!-- wp:list {"ordered":true} -->
<ol style="list-style-type:undefined" class="wp-block-list"><!-- wp:list-item -->
<li><a href="https://youtu.be/2rrIjJjPA4E" target="_blank" rel="noreferrer noopener">お問合わせフォームの呼び出し方法</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/fEkmVWNJg8g" target="_blank" rel="noreferrer noopener">項目設定方法</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/2EJ5-_ilsJU" target="_blank" rel="noreferrer noopener">送信ボタンのテキストを変更する方法</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/yUSuPt8rbKE">受信メールの設定</a>（お問合わせ内容を自分のメールで受信させるなど）</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/fZT1IF5PIxQ" target="_blank" rel="noreferrer noopener">同意・規約などのチェックボタンの設定</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/z4FzZwQmkAo">サンクスページの設定</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>サンクスメールの設定<!-- wp:list -->
<ul style="list-style-type:undefined" class="wp-block-list"><!-- wp:list-item -->
<li>基本</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>ショートコードの設定方法</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/LzW99YRE9Cw" target="_blank" rel="noreferrer noopener">reCAPTCHA設定</a>（迷惑メール対策）</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>受信履歴について</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>有効・無効設定</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>フォームの内容が受信できない時に確認項目</li>
<!-- /wp:list-item --></ol>
<!-- /wp:list -->