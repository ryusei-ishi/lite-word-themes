<?php
if ( !defined( 'ABSPATH' ) ) exit;

// マニュアルウェルカムボックスは不要のため無効化