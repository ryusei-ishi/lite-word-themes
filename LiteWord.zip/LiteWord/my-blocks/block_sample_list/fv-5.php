<!-- wp:wdl/fv-5 -->
<div class="wp-block-wdl-fv-5 fv-5 min-h-pc-280px min-h-tb-220px min-h-sp-180px"><div class="fv-5_inner"><h1 class="ttl" style="color:#fff"><span class="main" style="color:#fff">PORTFOLIO</span></h1><p class="description" style="color:#fff">テキストを入力してください。</p></div><div class="filter" style="background-color:var(--color-main);opacity:0.95"></div></div>
<!-- /wp:wdl/fv-5 -->