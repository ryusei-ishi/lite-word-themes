<!-- wp:wdl/lw-contact-3 {"maxWidth":800,"uniqueClass":"lw-contact-3-e7e8ca1f"} -->
<div class="wp-block-wdl-lw-contact-3 lw-contact-3 lw-contact-3-e7e8ca1f" style="max-width:800px">[lw_mail_form_select id='1']<style>
                    .lw-contact-3-e7e8ca1f .lw_mail_form .label_in label,.supplement_text { color: #000000; }
                    .lw-contact-3-e7e8ca1f .lw_mail_form input[type="text"],
                    .lw-contact-3-e7e8ca1f .lw_mail_form input[type="email"],
                    .lw-contact-3-e7e8ca1f .lw_mail_form input[type="tel"],
                    .lw-contact-3-e7e8ca1f .lw_mail_form input[type="url"],
                    .lw-contact-3-e7e8ca1f .lw_mail_form input[type="password"],
                    .lw-contact-3-e7e8ca1f .lw_mail_form textarea,
                    .lw-contact-3-e7e8ca1f .lw_mail_form select {
                        background-color: #f6f6f6;
                        color: #000000;
                    }
                    .lw-contact-3-e7e8ca1f .lw_mail_form select option { color: #000000; }
                    .lw-contact-3-e7e8ca1f .lw_mail_form .checkbox_in label,
                    .lw-contact-3-e7e8ca1f .lw_mail_form .radio_in label {
                        color: #000000;
                    }
                    .lw-contact-3-e7e8ca1f .lw_mail_form .submit_wrap button {
                        background-color: #007cba;
                        color: #ffffff;
                    }
                    .lw-contact-3-e7e8ca1f .lw_mail_form .required:not(.is-optional) {
                        background-color: #da3838 !important;
                        color: #ffffff !important;
                    }
                    .lw-contact-3-e7e8ca1f .lw_mail_form .required.is-optional {
                        background-color: #dddddd !important;
                        color: #000000 !important;
                    }
                </style></div>
<!-- /wp:wdl/lw-contact-3 -->