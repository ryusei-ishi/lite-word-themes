<!-- wp:wdl/fv-2 -->
<div class="wp-block-wdl-fv-2 fv-2 min-h-pc-320px min-h-tb-280px min-h-sp-220px"><h1 class="ttl" style="color:#fff">タイトル</h1><div class="filter" style="background-color:var(--color-main);opacity:0.9"></div><style>
                        .fv-2 h1:after {
                            background: #ef5d68;
                        }
                    </style></div>
<!-- /wp:wdl/fv-2 -->

<!-- wp:paragraph -->
<p class=""></p>
<!-- /wp:paragraph -->