<!-- wp:wdl/lw-pr-custom-title-13 {"colorMain":"#e1b924","maxWidth":540} -->
<div class="wp-block-wdl-lw-pr-custom-title-13 lw-pr-custom-title-13" style="--color-main:#e1b924;max-width:540px"><h2 class="ttl"><span class="sub">サブタイトル</span><span class="main">カスタムタイトル</span><div class="left"></div><div class="right"></div></h2></div>
<!-- /wp:wdl/lw-pr-custom-title-13 -->