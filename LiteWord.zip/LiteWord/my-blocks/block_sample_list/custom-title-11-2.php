<!-- wp:wdl/lw-pr-custom-title-11 {"subTitle":"","colorMain":"#e45454","borderRadius":18} -->
<div class="wp-block-wdl-lw-pr-custom-title-11 lw-pr-custom-title-11" style="--color-main:#e45454;width:100%;margin:1em auto"><h2 class="ttl" style="border-radius:18px"><span class="main">カスタムタイトル</span></h2></div>
<!-- /wp:wdl/lw-pr-custom-title-11 -->