<!-- wp:wdl/profile-1 {"imageUrl":"https://lite-word.com/wp-content/uploads/2024/11/AdobeStock_416612983.jpeg","altText":""} -->
<div class="wp-block-wdl-profile-1 profile-1" style="background-color:#ebebeb"><div class="profile_1_inner"><div class="profile_1_image"><img loading="lazy" src="https://lite-word.com/wp-content/uploads/2024/11/AdobeStock_416612983.jpeg" alt=""/></div><div class="profile_1_content"><h2 style="color:#000000">PROFILE</h2><p style="color:#000000;white-space:pre-wrap">名前：東京太郎
生年月日：1990年1月1日
出身地：東京都
趣味：読書、映画鑑賞、旅行</p></div></div></div>
<!-- /wp:wdl/profile-1 -->