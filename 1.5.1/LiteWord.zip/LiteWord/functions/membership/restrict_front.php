<?php
if ( !defined( 'ABSPATH' ) ) exit;
/* ===============================================================
 * LiteWord   ― 会員限定表示機能（フロント）
 * =============================================================== */

/**
 * フロント側：アクセス制御
 */
add_action( 'template_redirect', 'lw_protect_view_by_role' );
function lw_protect_view_by_role() {

    /* ---------- 適用対象を絞る ---------- */
    if ( ! is_singular( [ 'post', 'page' ] ) ) {
        return; // 単一投稿・固定ページ以外はスルー
    }

    /* ---------- 管理者は常に閲覧可 ---------- */
    if ( current_user_can( 'administrator' ) || current_user_can( 'manage_options' ) ) {
        return;
    }

    $post_id       = get_queried_object_id();
    /* ---------- 空要素を除去して正しい判定に ---------- */
    $allowed_roles = array_values( array_filter(
        (array) get_post_meta( $post_id, '_lw_allowed_roles', true ),
        'strlen'          // 空文字 '' を除外
    ) );

    /* ---------- 無選択なら全員閲覧可 ---------- */
    if ( empty( $allowed_roles ) ) {
        return;
    }

    /* ---------- 未ログイン → フロントページへ ---------- */
    if ( ! is_user_logged_in() ) {
        wp_redirect( home_url() );
        exit;
    }

    /* ---------- ロールが一致しなければフロントページへ ---------- */
    $user = wp_get_current_user();
    if ( ! array_intersect( $user->roles, $allowed_roles ) ) {
        wp_redirect( home_url() );
        exit;
    }
}