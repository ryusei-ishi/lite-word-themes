<?php
/**
 * LiteWord - アクティベート画面（テンプレート取得・保存）
 * ----------------------------------------------------------
 * ・ユーザーが入力したトークンで購入テンプレート一覧を取得
 * ・API が返す allowed_domain（カンマ区切り）と
 *   サイト URL を照合し、合わなければ active_flag=0
 * ・サブスクリプション契約時は sub_pre_set を追加
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function lw_normalize_url_parts_2( $url ) {
	$url = trim( $url );
	if ( $url === '' ) return [ '', '/' ];

	if ( ! preg_match( '#^https?://#i', $url ) ) {
		$url = 'https://' . ltrim( $url, '/' );
	}
	$parts = wp_parse_url( trailingslashit( $url ) );
	$host  = strtolower( preg_replace( '/^www\./i', '', $parts['host'] ?? '' ) );
	$path  = strtolower( $parts['path'] ?? '/' );

	return [ $host, $path ];
}

/* =========================================================
 * 変数初期化
 * ======================================================= */
$current_user_id = get_current_user_id();
$saved_token     = get_user_meta( $current_user_id, 'lw_target_shop_token', true );
$message         = '';

/* =========================================================
 * 0) リセット処理
 * ======================================================= */
if ( $_SERVER['REQUEST_METHOD'] === 'POST' && isset( $_POST['reset_templates'] ) ) {

	if ( ! current_user_can( 'administrator' ) ) wp_die( 'アクセス権限がありません。' );
	check_admin_referer( 'lw_reset_templates_action', 'lw_reset_templates_nonce' );

	global $wpdb;
	$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}lw_template_setting" );

	$message = '<div class="up_message"><p>テンプレートデータをリセットしました。</p></div>';
}

/* =========================================================
 * 1) トークン保存処理
 * ======================================================= */
if ( $_SERVER['REQUEST_METHOD'] === 'POST'
	 && isset( $_POST['user_token'], $_POST['save_token'] ) ) {

	$token = sanitize_text_field( $_POST['user_token'] );
	update_user_meta( $current_user_id, 'lw_target_shop_token', $token );
	$saved_token = $token;
	$message     = '<div class="up_message"><p>トークンを保存しました。</p></div>';
}

/* =========================================================
 * 2) テンプレート取得＆保存処理（ドメイン自動登録対応）
 * ======================================================= */
if ( $_SERVER['REQUEST_METHOD'] === 'POST'
	 && isset( $_POST['user_token'], $_POST['fetch_templates'] ) ) {

	if ( ! current_user_can( 'administrator' ) ) wp_die( 'アクセス権限がありません。' );

	$token = sanitize_text_field( $_POST['user_token'] );
	
	// 現在のサイトドメインを取得
	$current_domain = wp_parse_url( home_url(), PHP_URL_HOST );
	
	$shop_url = "https://shop.lite-word.com";// 本番用
	$shop_test_url = "http://localhost/SUPPORT_LOUNGE/LiteWord_SHOP"; // テスト用
	
	// APIリクエストにドメインパラメータを追加
	$api = $shop_url . '/wp-json/liteword/v1/secure-purchase-history?token=' .
	       urlencode( $token ) . '&domain=' . urlencode( $current_domain );
	       
	$response = wp_remote_get( $api );

	if ( is_wp_error( $response ) ) {
		$message = '<div class="error_message"><p>API通信エラー：' .
		           esc_html( $response->get_error_message() ) . '</p></div>';

	} else {

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		// 共通関数を使用してデータ処理
		if ( lw_process_api_data_to_templates( $data ) ) {
			$message = '<div class="up_message"><p>テンプレートデータの取得と保存に成功しました！</p></div>';
		} else {
			$message = '<div class="error_message"><p>アクティベートに失敗しました。トークンをご確認ください。</p></div>';
		}
	}
}
?>
<!-- =========================================================
     管理画面 UI
========================================================= -->
<div class="none_plugin_message"></div>
<div class="token_setting">
	<div class="wrap">
		<h1 class="token_title">LiteWord データ反映処理</h1>

		<div class="token_step">
			<h2 class="step_title">ステップ１</h2>
			<p>LiteWord Studioへログインし、あなたのアクセストークンを取得してください。</p>
			<ul class="token_links">
				<li><span class="dashicons dashicons-arrow-right-alt2"></span> <a href="https://shop.lite-word.com/user_login?redirect_url=https://shop.lite-word.com/template_activate" target="_blank" rel="noopener noreferrer">LiteWord Studioはこちら</a></li>
				<li><span class="dashicons dashicons-arrow-right-alt2"></span> <a href="https://www.youtube.com/watch?v=sYnHo9-Ax7Y" target="_blank" rel="noopener noreferrer">説明動画はこちら</a></li>
			</ul>
		</div>

		<div class="token_step">
			<h2 class="step_title">ステップ２</h2>
			<p>取得した「アクセストークン」を入力し、トークン保存ボタンを押してください。</p>
			<form method="post" class="token_form">
				<label for="user_token">アクセストークン</label>
				<input type="password" name="user_token" id="user_token" value="<?php echo esc_attr( $saved_token ); ?>" required>
				<button type="submit" name="save_token" class="button button-primary">トークンを保存</button>
			</form>
		</div>

		<div class="token_step">
			<h2 class="step_title">ステップ３</h2>
			<p>最後に下のボタンを押すとLiteWord Studioと通信をしてデータが反映されます。</p>

			<form method="post" class="template_fetch_form" style="display:inline-block;">
				<input type="hidden" name="user_token" value="<?php echo esc_attr( $saved_token ); ?>">
				<button type="submit" name="fetch_templates" class="button button-secondary">テンプレートを取得して保存</button>
			</form>

			<form method="post" class="template_reset_form" id="template_reset_form" style="display:inline-block; margin-left:12px;">
				<?php wp_nonce_field( 'lw_reset_templates_action', 'lw_reset_templates_nonce' ); ?>
				<input type="hidden" name="reset_templates" value="1">
				<button type="submit" class="button button-secondary">リセット</button>
			</form>

			<?php echo $message; ?>
		</div>
	</div>
</div>

<style>
/* 既存のスタイルをそのまま維持 */
#wpbody-content{padding-bottom:0;}
#wpcontent{padding-left:0;}
#wpfooter{display:none;}
.up_message{
	margin-top:20px;padding:10px;border:1px solid rgb(22,184,60);color:rgb(4,116,30);border-radius:4px;
}
.up_message p{margin:0;}
.error_message{
	margin-top:20px;padding:10px;border:1px solid rgb(255,0,0);color:rgb(255,0,0);border-radius:4px;
}
.error_message p{margin:0;}
.token_setting{
	padding:40px 20px 200px;font-family:inherit;color:#333;font-size:15px;
	background:linear-gradient(45deg,#7e3be3,#2b72b5,#44ea76);background-size:200% 200%;
	animation:bggradient 20s ease infinite;
}
@keyframes bggradient{
	0%{background-position:0% 50%;}
	50%{background-position:100% 50%;}
	100%{background-position:0% 50%;}
}
.token_setting .wrap{max-width:720px;margin:0 auto;background:#fff;padding:30px 40px;border-radius:6px;box-shadow:0 1px 3px rgba(0,0,0,.1);}
.token_setting .wrap p{font-size:16px;}
.token_title{font-size:22px;margin-bottom:24px;border-bottom:2px solid #0073aa;padding-bottom:8px;font-weight:600;}
.token_step{margin-bottom:32px;}
.step_title{font-size:18px;margin-bottom:10px;color:#0073aa;}
.token_links{padding-left:0;list-style:none;}
.token_links li{margin-bottom:6px;font-size:15px;display:flex;align-items:center;}
.token_links .dashicons{color:#0073aa;margin-right:6px;}
.token_form{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:10px;}
.token_form label{width:100%;display:block;}
.token_form input[type="password"]{flex:1;padding:8px 10px;border:1px solid #ccd0d4;border-radius:4px;width:100%;max-width:400px;font-size:14px;}
.token_form .button{height:auto;padding:8px 14px;font-size:14px;}
.template_fetch_form .button,
.template_reset_form .button{margin-top:10px;font-size:14px;padding:10px 18px;}
</style>

<script>
document.addEventListener('DOMContentLoaded', () => {
	const resetForm = document.getElementById('template_reset_form');
	if (resetForm) {
		resetForm.addEventListener('submit', e => {
			if ( ! confirm('購入したテンプレートデータをこのWordPressサイト内のみリセットします。本当によろしいですか？') ) {
				e.preventDefault();
			}
		});
	}
});
</script>