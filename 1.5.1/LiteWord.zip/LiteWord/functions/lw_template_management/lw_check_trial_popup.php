<?php
if ( !defined( 'ABSPATH' ) ) exit;
/**
 * LiteWord 2週間試用期間システム - リッチバージョン（修正版）
 */

// ログイン後のリダイレクトをフック
add_filter('login_redirect', 'lw_check_trial_popup', 10, 3);
function lw_check_trial_popup($redirect_to, $request, $user) {
    // ログインが失敗した場合（$userがWP_Errorの場合）は処理しない
    if (is_wp_error($user) || !is_object($user)) {
        return $redirect_to;
    }
    
    if (!user_can($user, 'administrator')) {
        return $redirect_to;
    }
    
    // サブスクリプション契約者は無料オファーを表示しない（修正版）
    if (lw_is_subscription_active()) {
        return $redirect_to;
    }
    
    // trial_periodの状態を確認
    $templateSetting = new LwTemplateSetting();
    $trial_setting = $templateSetting->get_template_setting_by_id('trial_period');
    
    // trial_periodが存在しない場合
    if (!$trial_setting) {
        // 初回の場合、試用開始ポップアップを表示
        set_transient('lw_show_trial_popup_' . $user->ID, true, 60);
    } else {
        // 最後のタイムスタンプから経過日数を計算
        $last_timestamp = strtotime($trial_setting['timestamp']);
        $now = time();
        $days_elapsed = floor(($now - $last_timestamp) / (60 * 60 * 24));
        
        if ($trial_setting['active_flag'] == 1) {
            // 試用期間中の場合
            $days_remaining = lw_get_trial_days_remaining_without_update(); // 更新しないバージョンを使用
            
            if ($days_remaining <= 0) {
                // 期間終了した場合、ポップアップを表示
                // シンプルなキーで期限切れポップアップ表示済みかチェック
                $expired_shown_key = 'lw_trial_expired_shown_' . date('Y-m-d', $last_timestamp);
                if (!get_user_meta($user->ID, $expired_shown_key, true)) {
                    set_transient('lw_show_trial_expired_popup_' . $user->ID, true, 60);
                }
            } elseif ($days_remaining <= 5 && $days_remaining > 0) {
                // 残り5日以下の場合
                set_transient('lw_show_trial_warning_popup_' . $user->ID, $days_remaining, 60);
            }
        } elseif ($days_elapsed >= 60) {
            // 試用期間終了後60日経過した場合、再度試用開始ポップアップを表示
            set_transient('lw_show_trial_popup_' . $user->ID, true, 60);
        }
    }
    
    return $redirect_to;
}

// 管理画面でポップアップを表示
add_action('admin_footer', 'lw_trial_popup_script');
function lw_trial_popup_script() {
    $current_user_id = get_current_user_id();
    if (!current_user_can('administrator')) {
        return;
    }
    
    // サブスクリプション契約者はポップアップを表示しない（修正版）
    if (lw_is_subscription_active()) {
        // すべてのトランジェントを削除してクリーンアップ
        delete_transient('lw_show_trial_popup_' . $current_user_id);
        delete_transient('lw_show_trial_warning_popup_' . $current_user_id);
        delete_transient('lw_show_trial_expired_popup_' . $current_user_id);
        return;
    }
    
    // 初回試用開始ポップアップ
    if (get_transient('lw_show_trial_popup_' . $current_user_id)) {
        delete_transient('lw_show_trial_popup_' . $current_user_id);
        lw_render_trial_start_popup();
        return;
    }
    
    // 残り日数警告ポップアップ
    $days_remaining = get_transient('lw_show_trial_warning_popup_' . $current_user_id);
    if ($days_remaining !== false) {
        delete_transient('lw_show_trial_warning_popup_' . $current_user_id);
        lw_render_trial_warning_popup($days_remaining);
        return;
    }
    
    // 期限切れポップアップ
    if (get_transient('lw_show_trial_expired_popup_' . $current_user_id)) {
        delete_transient('lw_show_trial_expired_popup_' . $current_user_id);
        
        // 期限切れポップアップを表示済みとして記録（シンプルなキーを使用）
        $templateSetting = new LwTemplateSetting();
        $trial_setting = $templateSetting->get_template_setting_by_id('trial_period');
        if ($trial_setting) {
            $expired_shown_key = 'lw_trial_expired_shown_' . date('Y-m-d', strtotime($trial_setting['timestamp']));
            update_user_meta($current_user_id, $expired_shown_key, true);
            
            // ポップアップ表示と同時にactive_flagを0に更新
            global $wpdb;
            $table_name = $wpdb->prefix . 'lw_template_setting';
            $wpdb->update(
                $table_name,
                array('active_flag' => 0),
                array('template_id' => 'trial_period'),
                array('%d'),
                array('%s')
            );
        }
        
        lw_render_trial_expired_popup();
        return;
    }
    
    // 期限切れだがポップアップ未表示の場合の追加チェック
    lw_check_and_show_expired_popup_if_needed();
}


// 期限切れだがポップアップ未表示の場合の追加チェック関数（新規追加）
function lw_check_and_show_expired_popup_if_needed() {
    $current_user_id = get_current_user_id();
    $templateSetting = new LwTemplateSetting();
    $trial_setting = $templateSetting->get_template_setting_by_id('trial_period');
    
    if ($trial_setting && $trial_setting['active_flag'] == 1) {
        $days_remaining = lw_get_trial_days_remaining_without_update();
        
        if ($days_remaining <= 0) {
            // 期限切れだがまだポップアップを表示していない場合
            $expired_shown_key = 'lw_trial_expired_shown_' . date('Y-m-d', strtotime($trial_setting['timestamp']));
            if (!get_user_meta($current_user_id, $expired_shown_key, true)) {
                // ポップアップを即座に表示
                update_user_meta($current_user_id, $expired_shown_key, true);
                
                // active_flagを0に更新
                global $wpdb;
                $table_name = $wpdb->prefix . 'lw_template_setting';
                $wpdb->update(
                    $table_name,
                    array('active_flag' => 0),
                    array('template_id' => 'trial_period'),
                    array('%d'),
                    array('%s')
                );
                
                lw_render_trial_expired_popup();
            }
        }
    }
}

// 試用開始ポップアップのレンダリング（リッチバージョン）
function lw_render_trial_start_popup() {
    $templateSetting = new LwTemplateSetting();
    $trial_setting = $templateSetting->get_template_setting_by_id('trial_period');
    
    // 再試用の場合のメッセージを判定
    $is_retry = ($trial_setting && $trial_setting['active_flag'] == 0);
    
    ?>
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideUp {
            from { 
                opacity: 0;
                transform: translateY(30px) scale(0.95);
            }
            to { 
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }
        
        @keyframes sparkle {
            0%, 100% { opacity: 0; transform: scale(0) rotate(0deg); }
            50% { opacity: 1; transform: scale(1) rotate(180deg); }
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }
        
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(52, 152, 219, 0.7); }
            70% { box-shadow: 0 0 0 10px rgba(52, 152, 219, 0); }
            100% { box-shadow: 0 0 0 0 rgba(52, 152, 219, 0); }
        }
        body:has(.lw-trial-overlay),
        html:has(.lw-trial-overlay) {
            overflow: hidden; /* ポップアップ表示中はスクロール禁止 */
        }
        
        .lw-trial-overlay {
            position: fixed;
            top: 0;
            left: 0;
            padding: 80px 24px;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(52, 152, 219, 0.9), rgba(155, 89, 182, 0.9));
            backdrop-filter: blur(5px);
            z-index: 999999;
            display: flex;
            align-items: start;
            justify-content: center;
            animation: fadeIn 0.3s ease;
            overflow-y: scroll;
            box-sizing: border-box;
        }
        
        .lw-trial-popup {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            padding: 60px 50px 50px;
            border-radius: 20px;
            max-width: 580px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            text-align: center;
            position: relative;
            animation: slideUp 0.5s ease;
            overflow: hidden;
        }
        
        .lw-trial-popup::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(52, 152, 219, 0.1) 0%, transparent 70%);
            animation: float 6s ease-in-out infinite;
        }
        
        .lw-sparkle {
            position: absolute;
            width: 20px;
            height: 20px;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%233498db"><path d="M12 0l2.5 9.5L24 12l-9.5 2.5L12 24l-2.5-9.5L0 12l9.5-2.5z"/></svg>') center/contain no-repeat;
            animation: sparkle 3s ease-in-out infinite;
        }
        
        .lw-sparkle:nth-child(1) { top: 10%; left: 10%; animation-delay: 0s; }
        .lw-sparkle:nth-child(2) { top: 20%; right: 15%; animation-delay: 1s; }
        .lw-sparkle:nth-child(3) { bottom: 15%; left: 20%; animation-delay: 2s; }
        
        .lw-trial-badge {
            position: absolute;
            top: -30px;
            left: 50%;
            transform: translateX(-50%);
            background: linear-gradient(135deg, #f39c12, #e74c3c);
            color: white;
            padding: 8px 24px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 15px rgba(231, 76, 60, 0.4);
            animation: pulse 2s infinite;
        }
        
        .lw-trial-popup h2 {
            margin: 0 0 30px;
            color: #2c3e50;
            font-size: 32px;
            line-height: 1.4;
            font-weight: bold;
            position: relative;
            z-index: 1;
        }
        
        .lw-trial-popup h2 .highlight {
            background: linear-gradient(45deg, #3498db, #9b59b6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: inline-block;
            font-size: 36px;
        }
        
        .lw-trial-features {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin: 30px 0 40px;
            position: relative;
            z-index: 1;
        }
        
        .lw-trial-feature {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }
        
        .lw-trial-feature:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }
        
        .lw-trial-feature-icon {
            font-size: 36px;
            margin-bottom: 10px;
        }
        
        .lw-trial-feature-text {
            color: #7f8c8d;
            font-size: 14px;
            line-height: 1.4;
        }
        
        .lw-trial-popup p {
            margin: 0 0 20px;
            color: #5a6c7d;
            font-size: 18px;
            line-height: 1.6;
            position: relative;
            z-index: 1;
        }
        
        .lw-trial-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-top: 40px;
            position: relative;
            z-index: 1;
        }
        
        .lw-trial-btn {
            padding: 18px 40px;
            border: none;
            border-radius: 50px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .lw-trial-btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        
        .lw-trial-btn:hover::before {
            width: 300px;
            height: 300px;
        }
        
        .lw-trial-btn-yes {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: #fff;
            box-shadow: 0 6px 20px rgba(52, 152, 219, 0.4);
            transform: scale(1.05);
        }
        
        .lw-trial-btn-yes:hover {
            transform: scale(1.1);
            box-shadow: 0 8px 25px rgba(52, 152, 219, 0.5);
        }
        
        .lw-trial-btn-no {
            background: #ecf0f1;
            color: #7f8c8d;
        }
        
        .lw-trial-btn-no:hover {
            background: #bdc3c7;
            color: #2c3e50;
        }
        
        .lw-trial-skip-checkbox {
            margin-top: 25px;
            text-align: center;
            font-size: 14px;
            color: #95a5a6;
            position: relative;
            z-index: 1;
        }
        
        .lw-trial-skip-checkbox input[type="checkbox"] {
            margin-right: 8px;
            vertical-align: middle;
        }
        
        .lw-trial-skip-checkbox label {
            cursor: pointer;
            user-select: none;
            transition: color 0.3s ease;
        }
        
        .lw-trial-skip-checkbox label:hover {
            color: #7f8c8d;
        }
    </style>
    
    <div class="lw-trial-overlay" id="lwTrialOverlay">
        <div class="lw-trial-popup">
            <div class="lw-sparkle"></div>
            <div class="lw-sparkle"></div>
            <div class="lw-sparkle"></div>
            
            <div class="lw-trial-badge">🎉 プレミアム機能が無料に！</div>
            
            <h2><?php echo $is_retry ? '<span class="highlight">LiteWordプレミアム</span>を<br>再度お試しいただけます！' : '<span class="highlight">LiteWordプレミアム</span>を<br>試してみませんか？'; ?></h2>
            
            <div class="lw-trial-features">
                <div class="lw-trial-feature">
                    <div class="lw-trial-feature-icon">🎨</div>
                    <div class="lw-trial-feature-text"><span style="font-size: 20px; font-weight: bold; color: #3498db;">40+</span><br>デザインパーツ</div>
                </div>
                <div class="lw-trial-feature">
                    <div class="lw-trial-feature-icon">📐</div>
                    <div class="lw-trial-feature-text">プロ仕様の<br>レイアウト</div>
                </div>
                <div class="lw-trial-feature">
                    <div class="lw-trial-feature-icon">🎯</div>
                    <div class="lw-trial-feature-text">理想のサイトを<br>すぐに実現</div>
                </div>
            </div>
            
            <p><strong>14日間</strong>、ほぼすべての有料デザインパーツが<br>
            <strong>使い放題</strong>でお試しいただけます！</p>
            
            <p style="font-size: 16px; color: #3498db; margin-bottom: 0;">
            🎯 プロ級のサイトデザインを今すぐ実現
            </p>
            
            <p style="font-size: 14px; color: #95a5a6;">
            💳 クレジットカード登録不要<br>
            🔄 自動課金なし<?php echo $is_retry ? '<br>✨ 60日ごとに再利用可能' : ''; ?>
            </p>
            
            <div class="lw-trial-buttons">
                <button class="lw-trial-btn lw-trial-btn-yes" id="lwTrialYes">
                    <span style="position: relative; z-index: 1;">🚀 今すぐ始める</span>
                </button>
                <button class="lw-trial-btn lw-trial-btn-no" id="lwTrialNo">
                    <span style="position: relative; z-index: 1;">後で</span>
                </button>
            </div>
            
            <div class="lw-trial-skip-checkbox">
                <label>
                    <input type="checkbox" id="lwTrialSkipCheckbox">
                    60日間、このメッセージを表示しない
                </label>
            </div>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // 紙吹雪エフェクト
        function createConfetti() {
            const colors = ['#3498db', '#e74c3c', '#f39c12', '#9b59b6', '#2ecc71'];
            const confettiCount = 50;
            
            for (let i = 0; i < confettiCount; i++) {
                const confetti = $('<div class="confetti"></div>');
                confetti.css({
                    position: 'fixed',
                    width: '10px',
                    height: '10px',
                    background: colors[Math.floor(Math.random() * colors.length)],
                    left: Math.random() * 100 + '%',
                    top: '-20px',
                    opacity: Math.random(),
                    transform: 'rotate(' + Math.random() * 360 + 'deg)',
                    pointerEvents: 'none',
                    zIndex: 1000000
                });
                
                $('body').append(confetti);
                
                confetti.animate({
                    top: '100%',
                    opacity: 0
                }, {
                    duration: 3000 + Math.random() * 2000,
                    easing: 'linear',
                    complete: function() {
                        $(this).remove();
                    }
                });
            }
        }
        
        $('#lwTrialYes').on('click', function() {
            const $btn = $(this);
            $btn.prop('disabled', true).html('<span style="position: relative; z-index: 1;">⏳ 処理中...</span>');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'lw_activate_trial',
                    nonce: '<?php echo wp_create_nonce('lw_trial_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        createConfetti();
                        $btn.html('<span style="position: relative; z-index: 1;">✅ 完了！</span>');
                        
                        // 成功メッセージをポップアップ内に表示
                        const successMsg = $('<div style="margin-top: 20px; padding: 15px; background: #d4edda; color: #155724; border-radius: 10px; font-weight: bold;">🎊 LiteWordプレミアムの試用期間が開始されました！</div>');
                        $('.lw-trial-buttons').after(successMsg);
                        
                        setTimeout(function() {
                            $('#lwTrialOverlay').fadeOut(600, function() {
                                $(this).remove(); // DOM要素を削除
                                location.reload();
                            });
                        }, 2000);
                    } else {
                        alert('エラーが発生しました。もう一度お試しください。');
                        $btn.prop('disabled', false).html('<span style="position: relative; z-index: 1;">🚀 今すぐ始める</span>');
                    }
                }
            });
        });
        
        $('#lwTrialNo').on('click', function() {
            if ($('#lwTrialSkipCheckbox').is(':checked')) {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'lw_skip_trial_for_60days',
                        nonce: '<?php echo wp_create_nonce('lw_skip_trial_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#lwTrialOverlay').fadeOut(400, function() {
                                $(this).remove(); // DOM要素を削除
                            });
                        } else {
                            alert('エラーが発生しました。');
                        }
                    }
                });
            } else {
                $('#lwTrialOverlay').fadeOut(400, function() {
                    $(this).remove(); // DOM要素を削除
                });
            }
        });
        
        $('#lwTrialOverlay').on('click', function(e) {
            if (e.target.id === 'lwTrialOverlay') {
                $(this).fadeOut(400, function() {
                    $(this).remove(); // DOM要素を削除
                });
            }
        });
    });
    </script>
    <?php
}

// 残り日数警告ポップアップのレンダリング（リッチバージョン）
function lw_render_trial_warning_popup($days_remaining) {
    ?>
    <style>
        @keyframes warningPulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        @keyframes clockTick {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .lw-trial-overlay {
            position: fixed;
            top: 0;
            left: 0;
            padding: 80px 24px;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(243, 156, 18, 0.9), rgba(230, 126, 34, 0.9));
            backdrop-filter: blur(5px);
            z-index: 999999;
            display: flex;
            align-items: start;
            justify-content: center;
            animation: fadeIn 0.3s ease;
            overflow-y: scroll;
            box-sizing: border-box;
        }
        
        .lw-trial-popup {
            background: linear-gradient(135deg, #ffffff 0%, #fff9f5 100%);
            padding: 50px;
            border-radius: 20px;
            max-width: 520px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            text-align: center;
            position: relative;
            animation: slideUp 0.5s ease, warningPulse 2s ease-in-out infinite;
        }
        
        .lw-trial-clock {
            position: absolute;
            top: -40px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #f39c12, #e67e22);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            box-shadow: 0 6px 20px rgba(243, 156, 18, 0.4);
        }
        
        .lw-trial-clock::after {
            content: '⏰';
            animation: clockTick 3s linear infinite;
        }
        
        .lw-trial-popup h2 {
            margin: 30px 0 20px;
            color: #e67e22;
            font-size: 28px;
            line-height: 1.4;
            font-weight: bold;
        }
        
        .lw-trial-countdown {
            background: linear-gradient(135deg, #fff3e0, #ffe0b2);
            border-radius: 15px;
            padding: 25px;
            margin: 20px 0 30px;
            box-shadow: inset 0 2px 10px rgba(243, 156, 18, 0.1);
        }
        
        .lw-trial-countdown-number {
            font-size: 48px;
            font-weight: bold;
            color: #e67e22;
            display: block;
            margin-bottom: 5px;
        }
        
        .lw-trial-countdown-text {
            margin-top: 18px;
            display: block;
            color: #f39c12;
            font-size: 18px;
        }
        
        .lw-trial-popup p {
            margin: 0 0 30px;
            color: #7f8c8d;
            font-size: 16px;
            line-height: 1.6;
        }
        
        .lw-trial-progress {
            width: 100%;
            height: 8px;
            background: #ecf0f1;
            border-radius: 4px;
            overflow: hidden;
            margin: 20px 0;
        }
        
        .lw-trial-progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #e74c3c, #e67e22, #f39c12);
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        
        .lw-trial-btn-warning {
            background: linear-gradient(135deg, #f39c12, #e67e22);
            color: #fff;
            padding: 18px 40px;
            border: none;
            border-radius: 50px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 6px 20px rgba(243, 156, 18, 0.4);
        }
        
        .lw-trial-btn-warning:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(243, 156, 18, 0.5);
        }
    </style>
    
    <div class="lw-trial-overlay" id="lwTrialWarningOverlay">
        <div class="lw-trial-popup">
            <div class="lw-trial-clock"></div>
            
            <h2>⚠️ もうすぐ試用期間が終了します</h2>
            
            <div class="lw-trial-countdown">
                <span class="lw-trial-countdown-number"><?php echo $days_remaining; ?></span>
                <span class="lw-trial-countdown-text">日後に終了</span>
            </div>
            
            <div class="lw-trial-progress">
                <div class="lw-trial-progress-bar" style="width: <?php echo ((14 - $days_remaining) / 14) * 100; ?>%"></div>
            </div>
            
            <p>
                LiteWordプレミアムの試用期間があと<strong><?php echo $days_remaining; ?>日</strong>で終了します。<br>
                期間終了後はプレミアム機能が利用できなくなります。
            </p>
            
            <p style="font-size: 14px; color: #95a5a6;">
            💡 無料期間が終了する前に<a href="<?=lw_premium_info_link()?>" target="_blank">プレミアムプラン</a>をご検討ください
            </p>
            
            <div class="lw-trial-buttons">
                <button class="lw-trial-btn-warning" id="lwTrialWarningOk">確認しました</button>
            </div>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('#lwTrialWarningOk, #lwTrialWarningOverlay').on('click', function(e) {
            if (e.target.id === 'lwTrialWarningOk' || e.target.id === 'lwTrialWarningOverlay') {
                $('#lwTrialWarningOverlay').fadeOut(400, function() {
                    $(this).remove(); // DOM要素を削除
                });
            }
        });
    });
    </script>
    <?php
}

// 期限切れポップアップのレンダリング（リッチバージョン）
function lw_render_trial_expired_popup() {
    ?>
    <style>
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        
        @keyframes fadeToGray {
            0% { filter: grayscale(0%); }
            100% { filter: grayscale(100%); }
        }
        
        .lw-trial-overlay {
            position: fixed;
            top: 0;
            left: 0;
            padding: 80px 24px;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(44, 62, 80, 0.95), rgba(52, 73, 94, 0.95));
            backdrop-filter: blur(5px);
            z-index: 999999;
            display: flex;
            align-items: start;
            justify-content: center;
            animation: fadeIn 0.3s ease;
            overflow-y: scroll;
            box-sizing: border-box;
        }
        
        .lw-trial-popup {
            background: linear-gradient(135deg, #ffffff 0%, #f5f5f5 100%);
            padding: 50px;
            border-radius: 20px;
            max-width: 500px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
            text-align: center;
            position: relative;
            animation: slideUp 0.5s ease, shake 0.5s ease 0.5s;
        }
        
        .lw-trial-expired-icon {
            position: absolute;
            top: -40px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            box-shadow: 0 6px 20px rgba(231, 76, 60, 0.4);
            animation: fadeToGray 2s ease forwards;
        }
        
        .lw-trial-expired-icon::after {
            content: '⏱️';
        }
        
        .lw-trial-popup h2 {
            margin: 30px 0 20px;
            color: #e74c3c;
            font-size: 28px;
            font-weight: bold;
        }
        
        .lw-trial-popup p {
            margin: 0 0 30px;
            color: #7f8c8d;
            font-size: 16px;
            line-height: 1.6;
        }
        
        .lw-trial-expired-features {
            background: #f8f9fa;
            border: 2px dashed #e74c3c;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            filter: grayscale(100%);
            opacity: 0.7;
        }
        
        .lw-trial-expired-features h4 {
            margin: 0 0 10px;
            color: #95a5a6;
            font-size: 16px;
        }
        
        .lw-trial-expired-features ul {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: left;
        }
        
        .lw-trial-expired-features li {
            padding: 5px 0;
            color: #bdc3c7;
            text-decoration: line-through;
        }
        
        .lw-trial-btn-expired {
            background: linear-gradient(135deg, #95a5a6, #7f8c8d);
            color: #fff;
            padding: 18px 40px;
            border: none;
            border-radius: 50px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 6px 20px rgba(149, 165, 166, 0.4);
        }
        
        .lw-trial-btn-expired:hover {
            background: linear-gradient(135deg, #7f8c8d, #5a6c7d);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(149, 165, 166, 0.5);
        }
        
        .lw-trial-next-info {
            margin-top: 20px;
            margin-bottom: 20px;
            padding: 15px;
            background: #ecf0f1;
            border-radius: 10px;
            font-size: 14px;
            color: #7f8c8d;
        }
    </style>
    
    <div class="lw-trial-overlay" id="lwTrialExpiredOverlay">
        <div class="lw-trial-popup">
            <div class="lw-trial-expired-icon"></div>
            
            <h2>試用期間が終了しました</h2>
            
            <p>LiteWordプレミアムの2週間無料試用期間が終了しました。<br>
            ご利用いただき、ありがとうございました！</p>
            
            <div class="lw-trial-expired-features">
                <h4>利用できなくなったデザインパーツ：</h4>
                <ul>
                    <li>❌ セクション・レイアウトパーツ</li>
                    <li>❌ ボタン・CTA要素</li>
                    <li>❌ ギャラリー・スライダー</li>
                    <li>❌ SEO機能</li>
                    <li>❌ フォントの利用数制限</li>
                    <li style="color: #95a5a6; font-size: 14px;">他、様々な機能が制限されます</li>
                </ul>
            </div>
            
            <div class="lw-trial-next-info">
                💡 60日後に再度無料試用期間をご利用いただけます
            </div>
            
            <div class="lw-trial-buttons">
                <button class="lw-trial-btn-expired" id="lwTrialExpiredOk">確認しました</button>
            </div>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('#lwTrialExpiredOk').on('click', function() {
            $('#lwTrialExpiredOverlay').fadeOut(400, function() {
                $(this).remove(); // DOM要素を削除
            });
        });
    });
    </script>
    <?php
}

// Ajax処理：試用期間の有効化
add_action('wp_ajax_lw_activate_trial', 'lw_activate_trial_callback');
function lw_activate_trial_callback() {
    // nonceチェック
    if (!wp_verify_nonce($_POST['nonce'], 'lw_trial_nonce')) {
        wp_die('Security check failed');
    }
    
    // 管理者権限チェック
    if (!current_user_can('administrator')) {
        wp_send_json_error('権限がありません');
        return;
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'lw_template_setting';
    
    // trial_periodが既に存在するかチェック
    $exists = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table_name} WHERE template_id = %s",
            'trial_period'
        )
    );
    
    if ($exists) {
        // 既存のレコードを更新（タイムスタンプを現在時刻に更新）
        $result = $wpdb->update(
            $table_name,
            array(
                'timestamp' => current_time('mysql'),
                'active_flag' => 1
            ),
            array('template_id' => 'trial_period'),
            array('%s', '%d'),
            array('%s')
        );
    } else {
        // 新規レコードを挿入
        $result = $wpdb->insert(
            $table_name,
            array(
                'template_id' => 'trial_period',
                'timestamp' => current_time('mysql'),
                'active_flag' => 1
            ),
            array('%s', '%s', '%d')
        );
    }
    
    if ($result !== false) {
        wp_send_json_success('試用期間が有効になりました');
    } else {
        wp_send_json_error('データベースエラーが発生しました');
    }
}

// Ajax処理：60日間試用をスキップ
add_action('wp_ajax_lw_skip_trial_for_60days', 'lw_skip_trial_for_60days_callback');
function lw_skip_trial_for_60days_callback() {
    // nonceチェック
    if (!wp_verify_nonce($_POST['nonce'], 'lw_skip_trial_nonce')) {
        wp_die('Security check failed');
    }
    
    // 管理者権限チェック
    if (!current_user_can('administrator')) {
        wp_send_json_error('権限がありません');
        return;
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'lw_template_setting';
    
    // trial_periodが既に存在するかチェック
    $exists = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table_name} WHERE template_id = %s",
            'trial_period'
        )
    );
    
    if ($exists) {
        // 既存のレコードを更新（タイムスタンプを現在時刻に更新、active_flagを0に）
        $result = $wpdb->update(
            $table_name,
            array(
                'timestamp' => current_time('mysql'),
                'active_flag' => 0
            ),
            array('template_id' => 'trial_period'),
            array('%s', '%d'),
            array('%s')
        );
    } else {
        // 新規レコードを挿入（active_flag = 0で作成）
        $result = $wpdb->insert(
            $table_name,
            array(
                'template_id' => 'trial_period',
                'timestamp' => current_time('mysql'),
                'active_flag' => 0
            ),
            array('%s', '%s', '%d')
        );
    }
    
    if ($result !== false) {
        wp_send_json_success('60日間スキップされました');
    } else {
        wp_send_json_error('データベースエラーが発生しました');
    }
}

// 試用期間の残り日数を取得する関数（active_flagを更新しないバージョン）
function lw_get_trial_days_remaining_without_update() {
    $templateSetting = new LwTemplateSetting();
    $trial_setting = $templateSetting->get_template_setting_by_id('trial_period');
    
    if (!$trial_setting || $trial_setting['active_flag'] == 0) {
        return 0;
    }
    
    $start_date = strtotime($trial_setting['timestamp']);
    $end_date = strtotime('+14 days', $start_date);
    $now = time();
    
    if ($now >= $end_date) {
        return 0;
    }
    
    $remaining_seconds = $end_date - $now;
    $remaining_days = ceil($remaining_seconds / (60 * 60 * 24));
    
    return $remaining_days;
}

// 試用期間の残り日数を取得する関数（期限切れ時に自動更新する）
function lw_get_trial_days_remaining() {
    $templateSetting = new LwTemplateSetting();
    $trial_setting = $templateSetting->get_template_setting_by_id('trial_period');
    
    if (!$trial_setting || $trial_setting['active_flag'] == 0) {
        return 0;
    }
    
    $start_date = strtotime($trial_setting['timestamp']);
    $end_date = strtotime('+14 days', $start_date);
    $now = time();
    
    if ($now >= $end_date) {
        return 0;
    }
    
    $remaining_seconds = $end_date - $now;
    $remaining_days = ceil($remaining_seconds / (60 * 60 * 24));
    
    return $remaining_days;
}

// 試用期間が実際に有効かどうかを確認する関数
function lw_is_trial_active() {
    $templateSetting = new LwTemplateSetting();
    
    // サブスクリプション契約者は常に有料機能を利用可能（ただし試用期間とは別扱い）
    $subscription_setting = $templateSetting->get_template_setting_by_id('paid-lw-parts-sub-hbjkjhkljh');
    if ($subscription_setting && $subscription_setting['active_flag'] == 1) {
        return false; // 試用期間ではないのでfalse
    }
    
    $trial_setting = $templateSetting->get_template_setting_by_id('trial_period');
    
    if (!$trial_setting || $trial_setting['active_flag'] == 0) {
        return false;
    }
    
    // 残り日数が0日の場合はfalseを返す（active_flagは更新しない）
    $days_remaining = lw_get_trial_days_remaining_without_update();
    
    return $days_remaining > 0;
}

// サブスクリプションが有効かどうかを確認する関数
function lw_is_subscription_active() {
    $templateSetting = new LwTemplateSetting();
    
    $paid_sub_setting = $templateSetting->get_template_setting_by_id('paid-lw-parts-sub-hbjkjhkljh');
    if ($paid_sub_setting && $paid_sub_setting['active_flag'] == 1) {
        return true;
    }
    
    $sub_pre_setting = $templateSetting->get_template_setting_by_id('sub_pre_set');
    if ($sub_pre_setting && $sub_pre_setting['active_flag'] == 1) {
        return true;
    }
    
    return false;
}


// 管理画面に試用期間の情報を表示（リッチバージョン）
add_action('admin_notices', 'lw_show_trial_notice');
function lw_show_trial_notice() {
    if (!current_user_can('administrator')) {
        return;
    }
    
    $templateSetting = new LwTemplateSetting();
    
    // サブスクリプション契約者は通知を表示しない（修正版）
    if (lw_is_subscription_active()) {
        return;
    }
    
    $trial_setting = $templateSetting->get_template_setting_by_id('trial_period');
    
    if (!$trial_setting) {
        return;
    }
    
    // 試用期間が有効かチェック
    $is_active = lw_is_trial_active();
    $days_remaining = lw_get_trial_days_remaining_without_update();
    
    if ($is_active && $days_remaining > 0 && $days_remaining <= 5) {
        // 残り5日以下の警告表示
        ?>
        <style>
            .lw-admin-notice-warning {
                background: linear-gradient(135deg, #fff9f5 0%, #fff5f0 100%);
                border-left: 4px solid #f39c12;
                box-shadow: 0 2px 10px rgba(243, 156, 18, 0.1);
            }
            .lw-admin-notice-warning p {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .lw-admin-notice-warning .lw-notice-icon {
                font-size: 24px;
            }
            .lw-admin-notice-warning .lw-notice-days {
                background: #f39c12;
                color: white;
                padding: 2px 8px;
                border-radius: 4px;
                font-weight: bold;
            }
        </style>
        <div class="notice lw-admin-notice-warning is-dismissible">
            <p>
                <span class="lw-notice-icon">⚠️</span>
                <strong>LiteWordプレミアム試用期間：</strong>
                残り<span class="lw-notice-days"><?php echo $days_remaining; ?>日</span>です。
                期間終了後はプレミアム機能が利用できなくなります。プレミアムへの切替は<a href="<?=lw_premium_info_link()?>" target="_blank">こちら</a>から。
            </p>
        </div>
        <?php
    } elseif ($is_active && $days_remaining > 5) {
        // 通常の試用期間表示
        ?>
        <style>
            .lw-admin-notice-info {
                background: linear-gradient(135deg, #f0f9ff 0%, #e6f7ff 100%);
                border-left: 4px solid #3498db;
                box-shadow: 0 2px 10px rgba(52, 152, 219, 0.1);
            }
            .lw-admin-notice-info p {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .lw-admin-notice-info .lw-notice-icon {
                font-size: 24px;
            }
        </style>
        <div class="notice lw-admin-notice-info is-dismissible">
            <p>
                <span class="lw-notice-icon">🎉</span>
                <strong>LiteWordプレミアム試用期間：</strong>
                残り<?php echo $days_remaining; ?>日です。
                フリーからプレミアムへ変更は<a href="<?=lw_premium_info_link()?>" target="_blank">こちら</a>から。
            </p>
        </div>
        <?php
    } elseif (!$is_active && $trial_setting['active_flag'] == 0) {
        // 試用期間終了後の日数を計算
        $last_timestamp = strtotime($trial_setting['timestamp']);
        $now = time();
        $days_since_start = floor(($now - $last_timestamp) / (60 * 60 * 24));
        $days_until_next_trial = 60 - $days_since_start;
        
        if ($days_until_next_trial > 0 && $days_until_next_trial <= 7) {
            // 次の試用期間まで7日以内の場合
            ?>
            <style>
                .lw-admin-notice-upcoming {
                    background: linear-gradient(135deg, #f5f3ff 0%, #ede7ff 100%);
                    border-left: 4px solid #9b59b6;
                    box-shadow: 0 2px 10px rgba(155, 89, 182, 0.1);
                }
                .lw-admin-notice-upcoming p {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                .lw-admin-notice-upcoming .lw-notice-icon {
                    font-size: 24px;
                }
            </style>
            <div class="notice lw-admin-notice-upcoming is-dismissible">
                <p>
                    <span class="lw-notice-icon">✨</span>
                    <strong>LiteWord：</strong>
                    あと<?php echo $days_until_next_trial; ?>日で再度2週間の無料試用期間をご利用いただけます。
                </p>
            </div>
            <?php
        }
    }
}

// 既存のlw_active_template_ids関数をオーバーライド（優先度を高く設定）
if (!function_exists('lw_active_template_ids_with_trial')) {
    function lw_active_template_ids_with_trial($page_template_url = "", $shop_url = "") {
        $templateSetting = new LwTemplateSetting();
        
        // サブスクリプション契約者の確認（修正版）
        $is_subscription_active = lw_is_subscription_active();
        
        // 試用期間が実際に有効かチェック
        $is_trial_active = lw_is_trial_active();
        
        $template_ids = [];
        
        if ($is_subscription_active || $is_trial_active) {
            // サブスクリプション契約中または試用期間中：すべての有料テンプレートを有効化
            $template_items = LwTemplateItems($page_template_url, $shop_url);
            
            foreach ($template_items as $item) {
                if (isset($item['item_detail']['paid']) && $item['item_detail']['paid'] === true) {
                    // テンプレートIDを追加
                    if (isset($item['item_detail']['template_id'])) {
                        $template_ids[] = $item['item_detail']['template_id'];
                    }
                    
                    // 関連ブロックも追加
                    if (isset($item['item_detail']['block_used']) && is_array($item['item_detail']['block_used'])) {
                        foreach ($item['item_detail']['block_used'] as $block_id) {
                            $template_ids[] = $block_id;
                        }
                    }
                }
            }
        } else {
            // 通常時：元の関数を呼び出す
            return lw_active_template_ids($page_template_url, $shop_url);
        }
        
        return array_values(array_unique($template_ids));
    }
}

// フィルターを使って既存関数の結果を変更
add_filter('init', 'lw_override_template_functions', 999);
function lw_override_template_functions() {
    // templateSettingCheck関数のラッパー
    if (!function_exists('templateSettingCheck_with_trial')) {
        function templateSettingCheck_with_trial($id) {
            $templateSetting = new LwTemplateSetting();
            
            // サブスクリプション契約者の確認（修正版）
            $is_subscription_active = lw_is_subscription_active();
            
            // サブスクリプション契約中または試用期間が実際に有効かチェック
            if ($is_subscription_active || lw_is_trial_active()) {
                // すべての有料テンプレートを有効とみなす
                $template_items = LwTemplateItems();
                foreach ($template_items as $item) {
                    if (isset($item['item_detail']['paid']) && 
                        $item['item_detail']['paid'] === true && 
                        isset($item['item_detail']['template_id']) &&
                        $item['item_detail']['template_id'] === $id) {
                        return true;
                    }
                    
                    // block_usedもチェック
                    if (isset($item['item_detail']['block_used']) && 
                        is_array($item['item_detail']['block_used']) &&
                        in_array($id, $item['item_detail']['block_used'])) {
                        return true;
                    }
                }
            }
            
            // 通常時：元の関数を呼び出す
            return templateSettingCheck($id);
        }
    }
}

// 関数の存在確認と上書き用のアクション
add_action('after_setup_theme', 'lw_setup_trial_override', 999);
function lw_setup_trial_override() {
    // 必要に応じて追加の設定
}