<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* ---------- CSS ---------- */
wp_enqueue_style(
	'lw_seo_bulk_edit',
	get_template_directory_uri() . '/functions/seo/css/lw_seo_bulk_edit.css',
	[],
	css_version(),
	'all'
);
?>

<div class="none_plugin_message"></div>

<!-- =======================================================
     6) OGP／SNS 全体設定
     ※ 投稿・カテゴリごとの個別 OGP とは別に、
       サイト全体の「初期値」を決めるフォームです
     ======================================================= -->
<div class="lw_seo_base_setting">
	<h1>アクセス解析</h1>
    <div class="lw_seo_base_setting_form_in">
        <form method="post">
            <h2>Google関係</h2>

            
            <h3>アナリティクス ID</h3>
            <?php Lw_theme_mod_text( 'seo_set_google_analytics_id' ); ?>
            <p class="description">例）G-XXXXXXXXX</p>
            <h3>タグマネージャー ID</h3>
            <?php Lw_theme_mod_text( 'seo_set_gtm_id' ); ?>
            <p class="description">例）GTM-XXXXXXX</p>
            <h3>ログインしている場合</h3>
            <p>管理者・編集者はアクセス解析を無効にしますか？</p>
            <?php Lw_theme_mod_select( 'seo_set_admin_switch', [
                "on" => '有効にする',
                "off" => '無効にする',
            ] ); ?>
    

            <br><br><input type="submit" value="保存" class="button">
        </form>
    </div>

</div>