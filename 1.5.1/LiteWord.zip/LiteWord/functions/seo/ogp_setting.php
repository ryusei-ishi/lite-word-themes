<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* ---------- CSS ---------- */
wp_enqueue_style(
	'lw_seo_bulk_edit',
	get_template_directory_uri() . '/functions/seo/css/lw_seo_bulk_edit.css',
	[],
	css_version(),
	'all'
);
?>

<div class="none_plugin_message"></div>

<!-- =======================================================
     6) OGP／SNS 全体設定
     ※ 投稿・カテゴリごとの個別 OGP とは別に、
       サイト全体の「初期値」を決めるフォームです
     ======================================================= -->
<div class="lw_seo_base_setting">
	<h1>OGP基本設定</h1>
    <div class="lw_seo_base_setting_form_in">
        <form method="post">
            <h2>OGP／SNS 共通設定</h2>

            <!-- 6-1) デフォルト OGP 画像 -->
            <h3>デフォルト OGP画像（全ページ共通フォールバック）</h3>
            <p class="description">
                投稿・カテゴリ・フロントなどで個別設定が無い場合に使用される画像です。<br>
                URL を直接入力するか、メディアライブラリの「添付ファイル ID（数値）」のみでも構いません。
            </p>
            <?php Lw_opt_text( 'lw_og_default_image', 'text',
                'https://example.com/default-og.jpg', 'large-text' ); ?>

            <!-- 6-2) フロントページ専用 OGP 画像 -->
            <h3>フロントページ専用 OGP画像</h3>
            <p class="description">
                トップページ<br>（<code>is_front_page()</code> が true の時）だけに使う画像を設定できます。
            </p>
            <?php Lw_opt_text( 'lw_front_og_image', 'text', '', 'large-text' ); ?>

            <!-- 6-3) og:type 既定値 -->
            <h3>og:type（既定値）</h3>
            <?php
                $og_types = [
                    'website' => 'website',
                    'article' => 'article',
                    'product' => 'product',
                    'profile' => 'profile',
                ];
                Lw_opt_select( 'lw_og_default_type', $og_types, '', '', 'website' );
            ?>

            <!-- 6-4) X（旧Twitter）Card -->
            <h3>X (旧Twitter) Card 設定</h3>
            <div class="flex">
                <?php
                    $tw_cards = [
                        'summary_large_image' => 'summary_large_image（大画像）',
                        'summary'             => 'summary（小画像）',
                        'app'                 => 'app',
                        'player'              => 'player',
                    ];
                    Lw_opt_select( 'lw_twitter_card', $tw_cards, '', '', 'summary_large_image' );
                ?>
                <?php Lw_opt_text( 'lw_twitter_site',    'text', '@LiteWord', 'regular-text' ); ?>
                <?php Lw_opt_text( 'lw_twitter_creator', 'text', '',          'regular-text' ); ?>
            </div>
            <p class="description">
                左：Card タイプ　中央：<code>x:site</code>（旧 <code>twitter:site</code>）　
                右：<code>x:creator</code>（旧 <code>twitter:creator</code>）
            </p>

            <!-- 6-5) Facebook App / Page -->
            <h3>Facebook App / Page ID</h3>
            <div class="flex">
                <?php Lw_opt_text( 'lw_fb_app_id',  'text', '', 'regular-text', 10 ); ?>
                <?php Lw_opt_text( 'lw_fb_page_id', 'text', '', 'regular-text', 10 ); ?>
            </div>
            <p class="description">
                左：<code>fb:app_id</code>　右：<code>fb:page_id</code>（不要なら空でOK）
            </p>

            <br><input type="submit" value="保存" class="button">
        </form>
    </div>

</div>