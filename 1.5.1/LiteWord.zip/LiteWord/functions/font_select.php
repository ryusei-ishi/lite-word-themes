<?php
if ( !defined( 'ABSPATH' ) ) exit;
function enqueue_custom_font_weight_script() {

}
add_action('enqueue_block_editor_assets', 'enqueue_custom_font_weight_script');


