<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* ─────────────────────────────
 * WordPress標準のサニタイズ関数
 * ─────────────────────────── */
if ( ! function_exists( 'sanitize_text_field' ) ) {
	function sanitize_text_field( $str ) { return filter_var( $str, FILTER_SANITIZE_STRING ); }
}

/* ─────────────────────────────
 * 1) フォームセットのIDを決定
 * ─────────────────────────── */
$form_set_no = sanitize_text_field( $args );

/* ─────────────────────────────
 * 2) 初期データ
 *    ★ shortcode キーを追加
 * ─────────────────────────── */
$default_data = [
	[
		'select_pattern' => 'name',
		'required'       => true,
		'label_text'     => 'お名前',
		'option'         => "オプションテキスト1\nオプションテキスト2\nオプションテキスト3",
		'supplement_text'=> '例）山田太郎',
		'placeholder'    => '',
		'shortcode'      => 'your_name',
	],
	[
		'select_pattern' => 'email',
		'required'       => true,
		'label_text'     => 'メールアドレス',
		'option'         => "オプションテキスト1\nオプションテキスト2\nオプションテキスト3",
		'supplement_text'=> '例）sample@gmail.com',
		'placeholder'    => '',
		'shortcode'      => 'your_mail',
	],
	[
		'select_pattern' => 'textarea',
		'required'       => false,
		'label_text'     => 'お問合せ内容',
		'option'         => "オプションテキスト1\nオプションテキスト2\nオプションテキスト3",
		'supplement_text'=> '',
		'placeholder'    => '',
		'shortcode'      => 'your_message',
	],
];

/* ─────────────────────────────
 * 3) POSTされていれば保存
 * ─────────────────────────── */
if (
	isset( $_POST['form_set_no'] )       && $_POST['form_set_no']       !== '' &&
	isset( $_POST['form_set_item_arr'] ) && $_POST['form_set_item_arr'] !== ''
) {
	$form_set_item_arr = wp_unslash( $_POST['form_set_item_arr'] );
	update_option( "lw_mail_form_set_" . $form_set_no, $form_set_item_arr );
}

/* ─────────────────────────────
 * 4) DBに保存してあるJSON文字列を取得
 *    未保存の場合は $default_data を利用
 * ─────────────────────────── */
$saved_data = get_option( "lw_mail_form_set_" . $form_set_no, false );
if ( $saved_data ) {
	$saved_data = json_decode( $saved_data, true );
}
if ( ! is_array( $saved_data ) ) {
	$saved_data = $default_data;
}
?>
<div class="none_plugin_message"></div>
<div class="lw_mail_form_wrap reset">
	<?= lw_mail_set_header( "問合せフォーム $form_set_no 「入力項目の設定」","submit" , "変更内容を保存する" , "" ,"1" ); ?>
	<?= lw_mail_set_tab_menu( $form_set_no ); ?>
	<div class="lw_mail_form_set_wrap bg_color">
		<form class="mail_form_set" id="lw_mail_form_set" action="" method="post">
			<div class="items"></div>

			<div class="add_item_btn">項目の追加 +</div>

			<!-- フォームセット番号 -->
			<input type="hidden" name="form_set_no" value="<?php echo esc_attr( $form_set_no ); ?>">

			<!-- DBまたは初期値から得た配列を JSON にして hidden に埋め込む -->
			<input
				type="hidden"
				name="form_set_item_arr"
				value="<?php echo esc_attr( json_encode( $saved_data ) ); ?>"
			>

			<input type="submit" value="変更内容を保存する" class="Lw_mail_setting_form_submit">
		</form>
	</div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {

	/* ─────────────────────────────
	 * 要素取得
	 * ─────────────────────────── */
	const lw_mail_form_set    = document.getElementById('lw_mail_form_set');
	if (!lw_mail_form_set) return;

	const itemsContainer      = lw_mail_form_set.querySelector('.items');
	const formSetItemArrInput = lw_mail_form_set.querySelector('input[name="form_set_item_arr"]');
	const addItemBtn          = lw_mail_form_set.querySelector('.add_item_btn');

	/* ─────────────────────────────
	 * hidden の JSON をパース
	 * ─────────────────────────── */
	let item_arr_data = [];
	try { item_arr_data = JSON.parse(formSetItemArrInput.value) || []; } catch(e) {}

	/* ─────────────────────────────
	 * select_pattern 選択肢
	 * ─────────────────────────── */
	const options = [
		{ value:'',         label:'未選択' },
		{ value:'name',     label:'お名前' },
		{ value:'phone',    label:'電話番号' },
		{ value:'email',    label:'メールアドレス' },
		{ value:'text',     label:'１行テキスト' },
		{ value:'textarea', label:'テキストエリア' },
		{ value:'radio',    label:'ラジオボタン' },
		{ value:'checkbox', label:'チェックボックス' },
		{ value:'select',   label:'セレクトボックス' },
		{ value:'image',    label:'画像アップロード' },
		{ value:'date',     label:'日付' },
		{ value:'time',     label:'時間' },
	];

	/* ─────────────────────────────
	 * 既存ショートコード一覧を取得
	 * ─────────────────────────── */
	const collectShortcodes = () =>
		[...itemsContainer.querySelectorAll('input[name="shortcode"]')]
			.map(el => el.value);

	/* ─────────────────────────────
	 * ユニークなショートコード生成
	 * ─────────────────────────── */
	const generateUniqueShortcode = () => {
		let code;
		const existing = collectShortcodes();
		do {
			code = 'sc_' + Math.random().toString(36).slice(2, 8);
		} while (existing.includes(code));
		return code;
	};

	/* ─────────────────────────────
	 * hidden 更新
	 * ─────────────────────────── */
	const updateItemArray = () => {
		const formItems = itemsContainer.querySelectorAll('.form_item');
		const newArr    = [];

		formItems.forEach(item => {
			newArr.push({
				select_pattern : item.querySelector('[name="select_pattern"]')?.value || '',
				required       : item.querySelector('[name="required"]')?.checked || false,
				label_text     : item.querySelector('[name="label_text"]')?.value || '',
				option         : item.querySelector('[name="option_text"]')?.value || '',
				supplement_text: item.querySelector('[name="supplement_text"]')?.value || '',
				placeholder    : item.querySelector('[name="placeholder"]')?.value || '',
				shortcode      : item.querySelector('[name="shortcode"]')?.value || '',
			});
		});
		formSetItemArrInput.value = JSON.stringify(newArr);
	};

	/* ─────────────────────────────
	 * option_section の表示切替
	 * ─────────────────────────── */
	const toggleOptionSection = formItemEl => {
		const selectEl       = formItemEl.querySelector('[name="select_pattern"]');
		const optionSections = formItemEl.querySelectorAll('.option_section');
		if (!selectEl) return;
		if (['radio','checkbox','select'].includes(selectEl.value)) {
			optionSections.forEach(el => el.style.display = 'block');
		} else {
			optionSections.forEach(el => el.style.display = 'none');
		}
	};

	/* ─────────────────────────────
	 * 項目追加
	 * ─────────────────────────── */
	const addItem = (data = {}) => {

		const optionsHTML = options.map(o =>
			`<option value="${o.value}">${o.label}</option>`
		).join('');

		const newItem = document.createElement('div');
		newItem.classList.add('form_item');
		newItem.innerHTML = `
			<dl class="in">
				<div class="ctrl_btns_wrap">
					<div class="move_btn_wrap">
						<div class="move_btn move_up"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M182.6 137.4c-12.5-12.5-32.8-12.5-45.3 0l-128 128c-9.2 9.2-11.9 22.9-6.9 34.9s16.6 19.8 29.6 19.8h256c12.9 0 24.6-7.8 29.6-19.8s2.2-25.7-6.9-34.9l-128-128z"/></svg></div>
						<div class="move_btn move_down"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M137.4 374.6c12.5 12.5 32.8 12.5 45.3 0l128-128c9.2 9.2 11.9 22.9 6.9 34.9s-16.6-19.8-29.6-19.8H32c-12.9 0-24.6 7.8-29.6 19.8S-4.8 263.4 4.4 272.6l128 128z"/></svg></div>
					</div>
					<div class="delete_btn">この項目を削除</div>
				</div>

				<dt>項目タイトル</dt>
				<dd><textarea name="label_text" rows="2"></textarea></dd>

				<dt>タイプの選択</dt>
				<dd><select name="select_pattern">${optionsHTML}</select></dd>

				<dt>必須項目</dt>
				<dd><input type="checkbox" name="required"></dd>

				<dt class="option_section" style="display:none;">選択肢 (改行区切り)</dt>
				<dd class="option_section" style="display:none;"><textarea name="option_text" rows="5"></textarea></dd>

				<dt>補足テキスト</dt>
				<dd><textarea name="supplement_text" rows="2"></textarea></dd>

				<dt>プレースホルダ</dt>
				<dd><input type="text" name="placeholder" value=""></dd>

				<!-- ★ ショートコード -->
				<dt>ショートコード</dt>
				<dd><input type="text" name="shortcode" value=""></dd>
			</dl>
		`;
		itemsContainer.appendChild(newItem);

		/* 初期値セット */
		newItem.querySelector('[name="select_pattern"]').value =
			data.select_pattern || '';

		newItem.querySelector('[name="required"]').checked =
			!!data.required;

		newItem.querySelector('[name="label_text"]').value =
			data.label_text || '';

		newItem.querySelector('[name="option_text"]').value =
			data.option || '';

		newItem.querySelector('[name="supplement_text"]').value =
			data.supplement_text || '';

		newItem.querySelector('[name="placeholder"]').value =
			data.placeholder || '';

		const scInput = newItem.querySelector('[name="shortcode"]');
		scInput.value = data.shortcode || generateUniqueShortcode();

		/* select に応じた表示切替 */
		toggleOptionSection(newItem);

		updateItemArray();
	};

	/* ─────────────────────────────
	 * 初期描画
	 * ─────────────────────────── */
	item_arr_data.forEach(obj => addItem(obj));

	/* ─────────────────────────────
	 * select_pattern 変更
	 * ─────────────────────────── */
	itemsContainer.addEventListener('change', e => {
		if (e.target.name === 'select_pattern') {
			toggleOptionSection(e.target.closest('.form_item'));
			updateItemArray();
		}
	});

	/* ─────────────────────────────
	 * 削除／上下移動
	 * ─────────────────────────── */
	itemsContainer.addEventListener('click', e => {

		/* 削除 */
		if (e.target.closest('.delete_btn')) {
			if (confirm('削除しますがよろしいですか？')) {
				e.target.closest('.form_item').remove();
				updateItemArray();
			}
		}

		/* 上へ */
		if (e.target.closest('.move_up')) {
			const cur  = e.target.closest('.form_item');
			const prev = cur.previousElementSibling;
			if (prev) itemsContainer.insertBefore(cur, prev);
			updateItemArray();
		}

		/* 下へ */
		if (e.target.closest('.move_down')) {
			const cur  = e.target.closest('.form_item');
			const next = cur.nextElementSibling;
			if (next) itemsContainer.insertBefore(next, cur);
			updateItemArray();
		}
	});

	/* ─────────────────────────────
	 * 入力反映
	 * ─────────────────────────── */
	itemsContainer.addEventListener('input', updateItemArray);

	/* ─────────────────────────────
	 * 追加ボタン
	 * ─────────────────────────── */
	addItemBtn?.addEventListener('click', () => addItem({}));

});
</script>
