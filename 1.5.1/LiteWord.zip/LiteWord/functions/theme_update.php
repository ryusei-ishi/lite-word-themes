<?php
/**
 * LiteWord ─ テーマ自動アップデート処理
 * ---------------------------------------
 * 1) pre_set_site_transient_update_themes で独自の更新情報を流し込む
 * 2) admin_notices で更新通知＋2種類のボタンを表示
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // 直接アクセス禁止
}

/*====================================
 * 1) 更新情報を流し込む
 *===================================*/
add_filter( 'pre_set_site_transient_update_themes', 'lw_check_for_theme_update' );
function lw_check_for_theme_update( $transient ) {

	if ( ! is_object( $transient ) ) {
		$transient = new stdClass();
	}
	if ( empty( $transient->checked ) ) {
		return $transient; // テーマ一覧をまだ取得していない
	}

	// ─ 現在のテーマ情報（子テーマなら親に切り替え）
	$current_theme = wp_get_theme();
	if ( is_child_theme() ) {
		$current_theme = $current_theme->parent();
	}
	$current_version = $current_theme->get( 'Version' );
	$theme_slug      = $current_theme->get_stylesheet(); // = ディレクトリ名

	// ─ 更新情報（JSON）を取得
    $update_url = 'https://lite-word.com/theme-files/theme-update.json';
	$response   = wp_remote_get( $update_url );
	if ( is_wp_error( $response ) ) {
		return $transient; // 失敗したら何もしない
	}
	$update_data = json_decode( wp_remote_retrieve_body( $response ) );
	if ( ! is_object( $update_data ) || ! isset( $update_data->version, $update_data->download_url ) ) {
		return $transient; // 想定外のフォーマット
	}

	// ─ バージョン比較
	if ( version_compare( $current_version, $update_data->version, '<' ) ) {
		$transient->response[ $theme_slug ] = array(
			'theme'       => $theme_slug,
			'new_version' => $update_data->version,
			'url'         => 'https://lite-word.com',  // 任意の詳細ページ
			'package'     => $update_data->download_url,
		);
	}

	return $transient;
}

/*====================================
 * 2) 通知＋2種類のボタン
 *===================================*/
add_action( 'admin_notices', 'lw_theme_update_notice' );
function lw_theme_update_notice() {

	// ─ 権限チェック（編集者以下には出さない）
	if ( ! current_user_can( 'update_themes' ) ) {
		return;
	}

	// ─ 親テーマ情報
	$current_theme = wp_get_theme();
	if ( is_child_theme() ) {
		$current_theme = $current_theme->parent();
	}
	if ( ! $current_theme || ! $current_theme->exists() ) {
		return;
	}
	$current_version = $current_theme->get( 'Version' );
	$theme_slug      = $current_theme->get_stylesheet();

	// ─ 最新バージョン取得
    $update_url = 'https://lite-word.com/theme-files/theme-update.json';
	$response   = wp_remote_get( $update_url );
	if ( is_wp_error( $response ) ) {
		return;
	}
	$update_data = json_decode( wp_remote_retrieve_body( $response ) );
	if ( ! is_object( $update_data ) || ! isset( $update_data->version, $update_data->changelog ) ) {
		return;
	}

	// ─ 旧 → 新 なら通知
	if ( version_compare( $current_version, $update_data->version, '<' ) ) {

		/* ---------- ワンクリック更新リンク ---------- */
		$upgrade_url = wp_nonce_url(
			self_admin_url( 'update.php?action=upgrade-theme&theme=' . $theme_slug ),
			'upgrade-theme_' . $theme_slug
		);

		/* ---------- 更新ページ（update-core.php）へのリンク ---------- */
		$update_core_url = admin_url( 'update-core.php#themes' );

		echo '<div class="notice notice-warning is-dismissible lw_notice_style">';
		echo '<p><strong>LiteWord テーマの新バージョン (' . esc_html( $update_data->version ) . ')</strong> が利用可能です。</p>';
		echo '<p>変更内容: ' . esc_html( $update_data->changelog ) . '</p>';
		echo '<p style="margin-top:8px;">';
		echo '<a href="' . esc_url( $upgrade_url ) . '" class="button button-primary" style="margin-right:6px;">今すぐ更新</a>';
		echo '<a href="' . esc_url( $update_core_url ) . '" class="button">更新ページへ移動</a>';
		echo '</p>';
		echo '</div><div class="lw_notice_style_filter"></div>';
	}
}
