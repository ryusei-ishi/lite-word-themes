<?php
/**
 * LiteWord ページテンプレート挿入 - フロント用
 * REST API機能
 */

if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function() {
    register_rest_route('lw-template/v1', '/get-template', array(
        'methods' => 'POST',
        'callback' => 'lw_get_template_content',
        'permission_callback' => function() {
            return current_user_can('edit_pages');
        }
    ));
    
    register_rest_route('lw-template/v1', '/render-template', array(
        'methods' => 'POST',
        'callback' => 'lw_render_template_preview',
        'permission_callback' => function() {
            return current_user_can('edit_pages');
        }
    ));
});

function lw_get_template_content($request) {
    $template_path = $request->get_param('template_path');
    
    if (empty($template_path)) {
        return new WP_Error('missing_path', 'テンプレートパスが指定されていません', array('status' => 400));
    }
    
    $template_path = str_replace('..', '', $template_path);
    $file_path = get_template_directory() . '/' . $template_path;
    
    if (!file_exists($file_path)) {
        return new WP_Error('not_found', 'テンプレートファイルが見つかりません', array('status' => 404));
    }
    
    $content = file_get_contents($file_path);
    
    if ($content === false) {
        return new WP_Error('read_error', 'ファイルの読み込みに失敗しました', array('status' => 500));
    }
    
    $auto_recovery_script = '
<!-- wp:html -->
<script class="lw-auto-recovery-script">
(function() {
    setTimeout(function() {
        var recoverButtons = document.querySelectorAll(".block-editor-warning__action button");
        recoverButtons.forEach(function(button) {
            if (button.textContent.includes("復旧") || 
                button.textContent.includes("ブロックの復旧") ||
                button.textContent.includes("Attempt Block Recovery")) {
                button.click();
                console.log("ブロックを自動復旧しました");
            }
        });
        
        var selfScript = document.querySelector(".lw-auto-recovery-script");
        if (selfScript && selfScript.parentElement) {
            var blockId = selfScript.closest("[data-block]");
            if (blockId) {
                var clientId = blockId.getAttribute("data-block");
                if (wp && wp.data && clientId) {
                    wp.data.dispatch("core/block-editor").removeBlock(clientId);
                }
            }
        }
    }, 500);
})();
</script>
<!-- /wp:html -->';
    
    $content = $content . "\n\n" . $auto_recovery_script;
    
    return array(
        'success' => true,
        'content' => $content
    );
}

/**
 * テンプレートをレンダリングしてHTMLとして返す（プレビュー用）
 */
function lw_render_template_preview($request) {
    $template_path = $request->get_param('template_path');
    
    if (empty($template_path)) {
        return new WP_Error('missing_path', 'テンプレートパスが指定されていません', array('status' => 400));
    }
    
    $template_path = str_replace('..', '', $template_path);
    $file_path = get_template_directory() . '/' . $template_path;
    
    if (!file_exists($file_path)) {
        return new WP_Error('not_found', 'テンプレートファイルが見つかりません', array('status' => 404));
    }
    
    $content = file_get_contents($file_path);
    
    if ($content === false) {
        return new WP_Error('read_error', 'ファイルの読み込みに失敗しました', array('status' => 500));
    }
    
    global $lw_is_template_preview;
    $lw_is_template_preview = true;
    
    $rendered_content = do_blocks($content);
    
    $page_content_shadow = function_exists('Lw_put_text') ? Lw_put_text("page_content_shadow", "off") : "off";
    $page_content_shadow = ($page_content_shadow === "on") ? "shadow" : "";
    
    $color_page_bg_pc_opacity = function_exists('Lw_put_text') ? Lw_put_text("color_page_bg_pc_opacity", "100") : "100";
    $lw_custom_css = function_exists('Lw_put_text') ? Lw_put_text("lw_custom_css", "") : "";
    $head_set_before = function_exists('Lw_theme_mod_set') ? Lw_theme_mod_set("head_set_before") : "";
    $head_set_after = function_exists('Lw_theme_mod_set') ? Lw_theme_mod_set("head_set_after") : "";
    
    add_filter('wp_enqueue_scripts', function() {
        wp_dequeue_script('lw-analytics-tracker');
        wp_deregister_script('lw-analytics-tracker');
    }, 999);
    
    ob_start();
    ?>
<!DOCTYPE html>
<html lang="ja">
<head class="lw_head">
    <meta charset="UTF-8">
    <?php echo $head_set_before; ?>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <?php
    // すべてのブロックCSSを読み込み
    $blocks_dir = get_template_directory() . '/my-blocks/build';
    if (is_dir($blocks_dir)) {
        $block_dirs = glob($blocks_dir . '/*', GLOB_ONLYDIR);
        
        foreach ($block_dirs as $block_dir) {
            $block_name = basename($block_dir);
            $style_css_file = $block_dir . '/style.css';
            
            if (file_exists($style_css_file)) {
                $css_url = get_template_directory_uri() . "/my-blocks/build/{$block_name}/style.css";
                $version = filemtime($style_css_file);
                echo '<link rel="stylesheet" href="' . esc_url($css_url) . '?ver=' . $version . '">' . "\n";
            }
        }
    }
    ?>
    
    <?php wp_head(); ?>
    <?php echo $head_set_after; ?>
    <style>
        body:after{
            opacity: <?php echo esc_attr($color_page_bg_pc_opacity); ?>%;
        }
        <?php if (!empty($lw_custom_css)) { echo $lw_custom_css; } ?>
    </style>
</head>
<body <?php body_class('w-admin page'); ?> id="body">
    <?php wp_body_open(); ?>
    
    <main>
        <div class="lw_content_wrap page">
            <div class="main_content">
                <section class="post_content">
                    <div class="post_style page <?php echo esc_attr($page_content_shadow); ?>">
                        <div class="first_content"></div>
                        <?php echo $rendered_content; ?>
                        <div class="last_content"></div>
                    </div>
                </section>
            </div>
        </div>
    </main>
    
    <?php if ( is_active_sidebar( 'page_bottom' ) ) : ?>
        <aside class="page_bottom">
            <?php dynamic_sidebar( 'page_bottom' ); ?>
        </aside>
    <?php endif; ?>
    
    <?php get_template_part('templates/page_bg_image/index'); ?>
    
    <?php wp_footer(); ?>
</body>
</html>
    <?php
    
    $html = ob_get_clean();
    
    $lw_is_template_preview = false;
    
    return array(
        'success' => true,
        'html' => $html
    );
}