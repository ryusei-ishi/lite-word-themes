<?php
if ( !defined( 'ABSPATH' ) ) exit;
// ダッシュボードでウェルカムパネルの直前にマニュアルボタンを挿入
add_action('admin_footer', 'lw_manual_insert_before_welcome');
function lw_manual_insert_before_welcome() {
    $screen = get_current_screen();
    if ($screen->id !== 'dashboard') {
        return;
    }
    ?>
    <script>
    jQuery(document).ready(function($) {
        // マニュアルボタンのHTML
        var manualButton = `
            <div id="lw-manual-welcome-box" style="margin-top:8px; background: #f0f4ff; padding: 20px; border-radius: 8px; margin-bottom: 20px; border: 2px solid #0073aa;">
                <h2 style="margin-top: 0; display: flex; align-items: center; gap: 10px; line-height: 1.2;">
                    <span class="dashicons dashicons-book-alt" style="margin:-8px 5px 0 0; font-size: 30px; vertical-align: middle; color: #0073aa;"></span>
                    LiteWord操作マニュアル
                </h2>
                <p style="font-size: 16px; margin: 10px 0;">
                    LiteWordテーマをご利用いただきありがとうございます。<br>
                    まずは操作マニュアルで基本的な使い方をご確認ください。
                </p>
                <a href="<?php echo admin_url('admin.php?page=lw-manual-viewer'); ?>" 
                   class="button button-primary button-hero">
                    <span class="dashicons dashicons-arrow-right-alt" style="margin:-2px 0 0 0; vertical-align: middle;"></span>
                    マニュアルを開く
                </a>
            </div>
        `;
        
        // ウェルカムパネルの直前に挿入
        if ($('#welcome-panel').length > 0) {
            $('#welcome-panel').before(manualButton);
        } else {
            // ウェルカムパネルが非表示の場合は、ダッシュボードウィジェットの前に挿入
            $('#dashboard-widgets-wrap').before(manualButton);
        }
    });
    </script>
    <?php
}