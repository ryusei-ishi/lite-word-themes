<!-- wp:heading {"level":3,"className":"is-style-h_03"} -->
<h3 class="wp-block-heading is-style-h_03">初期設定</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul style="list-style-type:undefined" class="wp-block-list"><!-- wp:list-item -->
<li><a href="https://www.youtube.com/watch?v=Thco7Gty1RU" target="_blank" rel="noreferrer noopener">LiteWordテーマのインストール方法</a><!-- wp:list {"ordered":true} -->
<ol style="list-style-type:undefined" class="wp-block-list"><!-- wp:list-item -->
<li><a href="https://youtu.be/Thco7Gty1RU?si=f6zUGzifB2iAnalz&amp;t=134" target="_blank" rel="noreferrer noopener">テーマのダウンロード→インストール</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://www.youtube.com/watch?v=sYnHo9-Ax7Y" target="_blank" rel="noreferrer noopener">データ反映処理</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/qYqhuLPZxpw" target="_blank" rel="noreferrer noopener">パーマリンクの設定</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://lite-word.com/wordpress-noindex-guide/">noindex設定と重要性について</a></li>
<!-- /wp:list-item --></ol>
<!-- /wp:list --></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading {"level":3,"className":"is-style-h_03"} -->
<h3 class="wp-block-heading is-style-h_03">始めに知っておきたい事</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul style="list-style-type:undefined" class="wp-block-list"><!-- wp:list-item -->
<li><a href="https://www.youtube.com/watch?v=7yRnEEyb3Iw" target="_blank" rel="noreferrer noopener">バージョンの更新方法</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/a1PjTl1hvJ8" target="_blank" rel="noreferrer noopener">固定ページと投稿ページの違いについて</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->