<!-- wp:heading {"level":3,"className":"is-style-h_03"} -->
<h3 class="wp-block-heading is-style-h_03">基本編</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul style="list-style-type:undefined" class="wp-block-list"><!-- wp:list-item -->
<li><a href="https://youtu.be/ZSb7UNFFXOM" target="_blank" rel="noreferrer noopener">投稿レイアウトとは</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/1zba6boiQAg" target="_blank" rel="noreferrer noopener">カラム設定</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/mOfjEKyQ8aE" target="_blank" rel="noreferrer noopener">パンくずリスト</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>ファーストビュー（タイトル部分のレイアウト）<!-- wp:list -->
<ul style="list-style-type:undefined" class="wp-block-list"><!-- wp:list-item -->
<li><a href="https://youtu.be/-bhkguFyMjQ" target="_blank" rel="noreferrer noopener">アイキャッチ画像の設定方法</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/_-Ewbj4BkQI" target="_blank" rel="noreferrer noopener">パターンの変更方法</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/VazRJP8sqOM" target="_blank" rel="noreferrer noopener">カテゴリー、投稿日、更新日時を非表示にする方法</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/_Rf1B-RPaeY" target="_blank" rel="noreferrer noopener">見出しデザインの設定方法</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/ERf-hw90_AA" target="_blank" rel="noreferrer noopener">目次設定</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://youtu.be/X-jbW3Z5wtw" target="_blank" rel="noreferrer noopener">シェアボタン</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p class=""></p>
<!-- /wp:paragraph -->