<!-- wp:list -->
<ul style="list-style-type:undefined" class="wp-block-list"><!-- wp:list-item -->
<li><a href="https://lite-word.com/my-parts/" target="_blank" rel="noreferrer noopener">マイパーツ（ショートコード的な機能です）</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="https://www.youtube.com/watch?v=s4zL4VCzIFk&amp;t=1s" target="_blank" rel="noreferrer noopener">期限設定（カウントダウンタイマーなど）</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->