<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* =============================================================
 * ★追加 : 指定 template_id が active_flag = 1 か判定する関数
 * =========================================================== */
if ( ! function_exists( 'lw_template_is_active' ) ) :
	function lw_template_is_active( string $template_id_1 = "", string $template_id_2 = "" ) : bool {
		if ( ! class_exists( 'LwTemplateSetting' ) ) return false;
		
		// 両方とも空の場合は false を返す
		if ( empty( $template_id_1 ) && empty( $template_id_2 ) ) {
			return false;
		}
		
		$ts = new LwTemplateSetting();
		$is_active_1 = false;
		$is_active_2 = false;
		
		// 1つ目のテンプレートIDが空でない場合のみチェック
		if ( ! empty( $template_id_1 ) ) {
			$row_1 = $ts->get_template_setting_by_id( $template_id_1 );
			$is_active_1 = $row_1 && intval( $row_1['active_flag'] ) === 1;
		}
		
		// 2つ目のテンプレートIDが空でない場合のみチェック
		if ( ! empty( $template_id_2 ) ) {
			$row_2 = $ts->get_template_setting_by_id( $template_id_2 );
			$is_active_2 = $row_2 && intval( $row_2['active_flag'] ) === 1;
		}
		
		// どちらかがアクティブであれば true を返す
		return $is_active_1 || $is_active_2;
	}
endif;
?>

<!-- -------------------- メタボックス（固定） -------------------- -->
<div class="lw-block-meta-box">
	<button class="button button-primary" id="lw-insert-block">+ Lwブロックを挿入</button>
</div>

<!-- -------------------- ポップアップ本体 -------------------- -->
<div class="lw_popup_block_list reset">
	<div class="lw_list_popup_bg_filter lw_popup_block_list_close"></div>
	<div class="lw_popup_block_list__wrap">
		<div class="lw_close lw_popup_block_list_close"></div>
		<ul class="lw_list_ul">
			<div class="inner_head" style="grid-column: span 2; display: flex; align-items: center;">
				<div class="lw_space_block lw_space_block_insert">
					<div class="text">スペースを挿入する</div>
				</div>
				<div class="lw_space_block lw_container_block_insert">
					<div class="text">コンテナを挿入する</div>
				</div>
			</div>
			<div class="lw_block_head_in">
				<nav class="lw_block_category_nav">
					<ul>
						<li><a href="#lw-fv">固定ページタイトル</a></li>
						<li><a href="#lw-post-list">最新投稿・記事一覧</a></li>
						<li><a href="#lw-list">リスト・箇条書き系</a></li>
						<li><a href="#lw-step">ステップ系</a></li>
						<li><a href="#lw-banner-info">バナー系・画像系</a></li>
						<li><a href="#lw-button">リンク一覧系</a></li>
						<li><a href="#cta">CTA系</a></li>
						<li><a href="#contact-form">お問合わせフォーム</a></li>
						<li><a href="#lw-comment">コメント系</a></li>
						<li><a href="#lw-company">会社概要・沿革系</a></li>
						<li><a href="#lw-before-after">ビフォーアフター系</a></li>
						<li><a href="#lw-message">メッセージ・挨拶系</a></li>
						<li><a href="#lw-qa">Q&A系</a></li>
						<li><a href="#lw-voice">お客様の声系</a></li>
						<li><a href="#lw-profile">プロフィール系</a></li>
						<li><a href="#lw-content">その他のコンテンツ</a></li>
					</ul>
				</nav>
				
			</div>
		</ul>
	</div>
</div>
<script>
/* =============================================================
 *  1. PHP から JS へ渡すデータ
 * =========================================================== */
/* ★全解除フラグ：サブスクリプション契約者または試用期間中のとき true */
const paidAllUnlocked = <?php
	// サブスクリプション契約者の確認
	$is_subscription_active = lw_template_is_active( 'paid-lw-parts-sub-hbjkjhkljh','sub_pre_set' );
	
	// 試用期間の確認
	$is_trial_active = false;
	if ( function_exists( 'lw_is_trial_active' ) ) {
		$is_trial_active = lw_is_trial_active();
	}
	
	// どちらかがtrueならunlocked
	echo ( $is_subscription_active || $is_trial_active ) ? 'true' : 'false';
?>;

/* ★除外ブロックリスト */
const excludedBlocks = <?php
	$excluded = function_exists('block_Outright_purchase_only') ? block_Outright_purchase_only() : [];
	echo json_encode($excluded);
?>;

/* ブロックサンプル配列（PHP → JS） */
const blockSamples = <?php echo json_encode( lw_block_arr() ); ?>;

/* スペースブロックの HTML */
const LwSpaceBlock = `
	<!-- wp:wdl/lw-space-1 -->
	<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:80px"></div><div class="tb" style="height:64px"></div><div class="sp" style="height:40px"></div></div>
	<!-- /wp:wdl/lw-space-1 -->
`;
/* コンテナブロックの HTML */
const LwContainerBlock = `
	<!-- wp:wdl/lw-bg-1 {"minHeightPc":"min-h-pc-320px","minHeightTb":"min-h-tb-280px","minHeightSp":"min-h-sp-240px","innerPaddingTopPc":48,"innerPaddingBottomPc":48,"innerPaddingLeftPc":48,"innerPaddingRightPc":48,"innerPaddingTopTb":24,"innerPaddingBottomTb":24,"innerPaddingLeftTb":24,"innerPaddingRightTb":24} -->
	<div class="wp-block-wdl-lw-bg-1 lw-bg-1 min-h-pc-320px min-h-tb-280px min-h-sp-240px" style="--lw-bg-color-filter-pc:#000000;--lw-bg-opacity-pc:0.5;--lw-bg-color-filter-tb:#000000;--lw-bg-opacity-tb:0.5;--lw-bg-color-filter-sp:#000000;--lw-bg-opacity-sp:0.5;--lw-bg-position-pc:50% 50%;--lw-bg-position-sp:50% 50%;--lw-bg-wrap-centering-pc:center;--lw-bg-wrap-align-pc:center;--lw-bg-wrap-centering-tb:center;--lw-bg-wrap-align-tb:center;--lw-bg-wrap-centering-sp:center;--lw-bg-wrap-align-sp:center"><div class="lw-bg-1-wrap" style="--lw-bg-padding-top-pc:48px;--lw-bg-padding-bottom-pc:48px;--lw-bg-padding-left-pc:48px;--lw-bg-padding-right-pc:48px;--lw-bg-padding-top-tb:24px;--lw-bg-padding-bottom-tb:24px;--lw-bg-padding-left-tb:24px;--lw-bg-padding-right-tb:24px;--lw-bg-padding-top-sp:24px;--lw-bg-padding-bottom-sp:24px;--lw-bg-padding-left-sp:24px;--lw-bg-padding-right-sp:24px;--lw-bg-max-width:1120px"><!-- wp:paragraph -->
	<p class=""></p>
	<!-- /wp:paragraph --></div></div>
	<!-- /wp:wdl/lw-bg-1 -->
`;
/* =============================================================
 *  2. ユーティリティ：body.wp-admin 直下の先頭へ移動 ★追加
 * =========================================================== */
function moveToWpAdminTop(node) {
	const wpAdmin = document.querySelector('body.wp-admin');
	if (!wpAdmin || !node) return;
	/* 既に直下に無い場合のみ移動 */
	if (node.parentNode !== wpAdmin) {
		wpAdmin.insertBefore(node, wpAdmin.firstChild);
	}
}

/* =============================================================
 *  3. ブロック挿入と自動復旧の共通関数 ★追加
 * =========================================================== */
function insertBlockWithRecovery(html) {
	if (!wp || !wp.data) return;
	
	// エディタの状態を保存
	const editor = wp.data.select('core/block-editor');
	const insertionPoint = editor.getBlockInsertionPoint();
	
	// 現在のビューポート情報を保存
	const scrollContainer = document.querySelector('.interface-interface-skeleton__content');
	const initialScrollTop = scrollContainer ? scrollContainer.scrollTop : 0;
	
	// ブロックをパース
	const blocks = wp.blocks.parse(html);
	
	// ブロックを挿入
	const { insertBlocks } = wp.data.dispatch('core/block-editor');
	
	// カーソル位置に挿入
	insertBlocks(
		blocks,
		insertionPoint.index,
		insertionPoint.rootClientId
	).then(() => {
		// 挿入したブロックの自動復旧とスクロール
		setTimeout(() => {
			if (blocks.length > 0) {
				const insertedBlockId = blocks[0].clientId;
				
				// DOM上で復旧ボタンがあるか確認
				const blockElement = document.querySelector(`[data-block="${insertedBlockId}"]`);
				if (blockElement) {
					// 復旧ボタンを探す
					const recoverButtons = blockElement.querySelectorAll('button');
					for (let button of recoverButtons) {
						const buttonText = button.textContent;
						if (buttonText.includes('復旧') || 
							buttonText.includes('ブロックの復旧') ||
							buttonText.includes('Attempt Block Recovery')) {
							// 復旧ボタンをクリック
							button.click();
							console.log('ブロックを自動復旧しました');
							break;
						}
					}
					
					// ブロックを選択
					wp.data.dispatch('core/block-editor').selectBlock(insertedBlockId);
					
					// 挿入したブロックまでスクロール
					setTimeout(() => {
						blockElement.scrollIntoView({ 
							behavior: 'smooth', 
							block: 'center' 
						});
					}, 100);
				} else if (scrollContainer) {
					// フォールバック: 元のスクロール位置に戻す
					scrollContainer.scrollTop = initialScrollTop;
				}
			}
		}, 200); // DOMが更新されるのを待つ
	});
}

/* =============================================================
 *  4. DOMContentLoaded で初期セットアップ
 * =========================================================== */
document.addEventListener('DOMContentLoaded', () => {

	/* ---------- 要素取得 ---------- */
	const popupEl         = document.querySelector('.lw_popup_block_list');
	const insertBtn       = document.querySelector('#lw-insert-block');
	const listUl          = document.querySelector('.lw_list_ul');
	const popupCloseBtns  = document.querySelectorAll('.lw_popup_block_list_close');
	const spaceInsertBtn  = document.querySelector('.lw_space_block_insert');
	const containerInsertBtn  = document.querySelector('.lw_container_block_insert');

	/* ---------- まず初回に正しい場所へ移動 ★ ---------- */
	moveToWpAdminTop(popupEl);
	moveToWpAdminTop(insertBtn);

	/* =======================================================
	 * [+ Lwブロックを挿入] ボタンクリック
	 * ===================================================== */
	if (insertBtn) {
		insertBtn.addEventListener('click', () => {

			/* ★クリック毎に必ず位置を保証 */
			moveToWpAdminTop(popupEl);
			moveToWpAdminTop(insertBtn);

			popupEl.classList.add('active');

			/* リスト生成は 1 回だけ */
			if (!popupEl.dataset.loaded) {
				popupEl.dataset.loaded = '1';

				blockSamples.forEach(block => {

					/* ---------- 見出し (h2) ---------- */
					if (block.type === 'h2') {
						const title = document.createElement('div');
						title.id           = block.id;
						title.className    = 'lw_block_title';
						title.textContent  = block.title;
						listUl.appendChild(title);
						return;
					}

					/* ---------- 無料ブロック ---------- */
					if (block.type === 'block') {
						const li = document.createElement('li');
						li.dataset.blockKey = block.id;
						li.innerHTML = `
							<div class="lw-block-sample">
								<img src="${block.image}" alt="${block.title}" class="lw-block-preview-image">
								<h3 class="lw-block-title">${block.title}</h3>
								<p class="lw-block-description">${block.description}</p>
								<button class="button button-secondary lw-insert-block-btn" data-block-file="${block.file}">このブロックを使う</button>
							</div>`;
						listUl.appendChild(li);
						return;
					}

					/* ---------- 有料ブロック ---------- */
					if (block.type === 'paid_block') {

						// 除外リストに含まれているかチェック
						const isExcluded = excludedBlocks.includes(block.id);
						
						// 除外されていない場合のみ、全解除フラグまたは個別購入フラグをチェック
						const unlocked = !isExcluded && (paidAllUnlocked || block.switch === true);

						const li = document.createElement('li');
						li.dataset.blockKey = block.id;

						li.innerHTML = unlocked
							? `
							<div class="lw-block-sample">
								<img src="${block.image}" alt="${block.title}" class="lw-block-preview-image">
								<h3 class="lw-block-title"><span class="is_paid true"><span>利用可能</span></span>${block.title}</h3>
								<p class="lw-block-description">${block.description}</p>
								<button class="button button-secondary lw-insert-block-btn" data-block-file="${block.file}">このブロックを使う</button>
							</div>`
							: `
							<div class="lw-block-sample">
								<img src="${block.image}" alt="${block.title}" class="lw-block-preview-image">
								<h3 class="lw-block-title"><span class="is_paid"><span>有料</span></span>${block.title}</h3>
								<p class="lw-block-description">${block.description}</p>
								${isExcluded ? '<p style="color: #d63638; font-weight: bold; margin: 10px 0;">プレミアムプラン対象外</p>' : ''}
								<a href="${block.shop_url}" <?=new_tab()?> class="button" data-block-file="${block.file}">このブロックを使う</a>
							</div>`;

						listUl.appendChild(li);
					}
					/* ---------- プレミアム限定ブロック ---------- */
					if (block.type === 'pr_block') {
						
						// 除外リストに含まれているかチェック
						const isExcluded = excludedBlocks.includes(block.id);
						
						// 除外されていない場合のみ、全解除フラグまたは個別購入フラグをチェック
						const unlocked = !isExcluded && (paidAllUnlocked || block.switch === true);

						const li = document.createElement('li');
						li.dataset.blockKey = block.id;

						li.innerHTML = unlocked
							? `
							<div class="lw-block-sample">
								<img src="${block.image}" alt="${block.title}" class="lw-block-preview-image">
								<h3 class="lw-block-title"><span class="is_paid true"><span>利用可能</span></span>${block.title}</h3>
								<p class="lw-block-description">${block.description}</p>
								<button class="button button-secondary lw-insert-block-btn" data-block-file="${block.file}">このブロックを使う</button>
							</div>`
							: `
							<div class="lw-block-sample">
								<img src="${block.image}" alt="${block.title}" class="lw-block-preview-image">
								<h3 class="lw-block-title"><span class="is_paid is_premium"><span>プレミアム限定</span></span>${block.title}</h3>
								<p class="lw-block-description">${block.description}</p>
								<a href="<?php echo lw_premium_info_link(); ?>" <?=new_tab()?> class="button">プレミアムプランを見る</a>
							</div>`;

						listUl.appendChild(li);
						return;
					}
				});

				/* -------- リスト内クリックでブロックを挿入 -------- */
				listUl.addEventListener('click', e => {
					if (e.target && e.target.classList.contains('lw-insert-block-btn')) {
						const filePath = e.target.dataset.blockFile;
						if (filePath) {
							// ポップアップを先に閉じる
							popupEl.classList.remove('active');
							
							// ファイルを取得してブロックを挿入（改善版関数を使用）
							fetch(filePath)
								.then(res => res.text())
								.then(html => {
									insertBlockWithRecovery(html);
								})
								.catch(err => {
									console.error('ブロックの読み込みに失敗しました:', err);
									alert('ブロックの読み込みに失敗しました。');
								});
						}
					}
				});
			}
		});
	}

	/* =======================================================
	 * ポップアップ閉じる
	 * ===================================================== */
	popupCloseBtns.forEach(btn => {
		btn.addEventListener('click', () => popupEl.classList.remove('active'));
	});

	/* =======================================================
	 * スペースブロック挿入（改善版）
	 * ===================================================== */
	if (spaceInsertBtn) {
		spaceInsertBtn.addEventListener('click', () => {
			// ポップアップを先に閉じる
			popupEl.classList.remove('active');
			// 共通の挿入関数を使用
			insertBlockWithRecovery(LwSpaceBlock);
		});
	}
	/* =======================================================
	 * コンテナブロック挿入（改善版）
	 * ===================================================== */
	if (containerInsertBtn) {
		containerInsertBtn.addEventListener('click', () => {
			// ポップアップを先に閉じる
			popupEl.classList.remove('active');
			// 共通の挿入関数を使用
			insertBlockWithRecovery(LwContainerBlock);
		});
	}
});
</script>