<?php
/**
 * マイパーツ無料プラン制限機能（シンプル版）
 * 新規作成リンクを無効化してポップアップ表示
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* ===================================================================
 * 共通関数
 * ================================================================ */

if ( ! function_exists( 'lw_premium_info_link' ) ) {
    function lw_premium_info_link() {
        $custom_url = get_theme_mod( 'lw_premium_info_url', '' );
        if ( ! empty( $custom_url ) ) {
            return esc_url( $custom_url );
        }
        return 'https://lite-word.com/yuryo-plan/';
    }
}

function lw_get_my_parts_free_count() {
    return intval( get_option( 'lw_my_parts_free_count', 0 ) );
}

function lw_is_my_parts_limit_reached() {
    if ( defined( 'LW_HAS_SUBSCRIPTION' ) && LW_HAS_SUBSCRIPTION ) {
        return false;
    }
    
    if ( function_exists( 'lw_is_trial_active' ) && lw_is_trial_active() ) {
        return false;
    }
    
    return lw_get_my_parts_free_count() >= 5;
}

/* ===================================================================
 * カウント処理（保存成功時のみ）
 * ================================================================ */

add_action( 'save_post_lw_my_parts', function( $post_id, $post, $update ) {
    // 更新時はスキップ
    if ( $update ) {
        return;
    }
    
    // 自動保存等はスキップ
    if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
        return;
    }
    
    if ( in_array( $post->post_status, ['trash', 'auto-draft', 'inherit'] ) ) {
        return;
    }
    
    // 有料プランはスキップ
    if ( defined( 'LW_HAS_SUBSCRIPTION' ) && LW_HAS_SUBSCRIPTION ) {
        return;
    }
    
    // カウント済みチェック
    $is_counted = get_post_meta( $post_id, '_lw_my_parts_counted', true );
    
    if ( ! $is_counted ) {
        update_post_meta( $post_id, '_lw_my_parts_counted', '1' );
        $count = lw_get_my_parts_free_count();
        update_option( 'lw_my_parts_free_count', $count + 1 );
    }
}, 10, 3 );

/* ===================================================================
 * 管理画面でのリンク無効化とポップアップ
 * ================================================================ */

add_action( 'admin_footer', function() {
    global $typenow;
    
    // マイパーツ画面以外はスキップ
    if ( $typenow !== 'lw_my_parts' ) {
        return;
    }
    
    // 制限に達していない場合はスキップ
    if ( ! lw_is_my_parts_limit_reached() ) {
        return;
    }
    
    $premium_url = lw_premium_info_link();
    ?>
    <script>
    jQuery(document).ready(function($) {
        // 新規追加ボタン（一覧画面上部）
        $('.page-title-action').each(function() {
            if ($(this).text().indexOf('新規追加') !== -1) {
                var $link = $(this);
                
                // リンクを無効化してスタイル変更
                $link.removeAttr('href')
                    .css({
                        'opacity': '0.5',
                        'cursor': 'not-allowed',
                        'background': '#999',
                        'color': '#fff'
                    })
                    .click(function(e) {
                        e.preventDefault();
                        
                        // ポップアップ表示
                        if ($('#lw-my-parts-limit-popup').length === 0) {
                            var popup = `
                                <div id="lw-my-parts-limit-popup" style="
                                    position: fixed;
                                    top: 0;
                                    left: 0;
                                    width: 100%;
                                    height: 100%;
                                    background: rgba(0,0,0,0.7);
                                    z-index: 100000;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                ">
                                    <div style="
                                        background: #fff;
                                        padding: 40px;
                                        border-radius: 8px;
                                        max-width: 500px;
                                        text-align: center;
                                        box-shadow: 0 4px 20px rgba(0,0,0,0.2);
                                    ">
                                        <h2 style="color: #d63638; margin-bottom: 20px; font-size: 24px;">
                                            ⚠️ マイパーツ作成制限
                                        </h2>
                                        <p style="font-size: 16px; color: #333; margin-bottom: 25px; line-height: 1.6;">
                                            無料プランでは<strong>5個まで</strong>のマイパーツが作成可能です。<br>
                                            すでに上限に達しています。
                                        </p>
                                        <p style="font-size: 14px; color: #666; margin-bottom: 30px;">
                                            追加でマイパーツを作成するには<br>
                                            LiteWordプレミアムプランへの登録が必要です。
                                        </p>
                                        <div>
                                            <a href="<?php echo $premium_url; ?>" target="_blank" style="
                                                display: inline-block;
                                                padding: 15px 40px;
                                                background: #0073aa;
                                                color: #fff;
                                                text-decoration: none;
                                                border-radius: 4px;
                                                margin-right: 10px;
                                                font-size: 16px;
                                                font-weight: bold;
                                            ">プレミアムプランを見る</a>
                                            <button id="lw-popup-close" style="
                                                padding: 15px 40px;
                                                background: #666;
                                                color: #fff;
                                                border: none;
                                                border-radius: 4px;
                                                cursor: pointer;
                                                font-size: 16px;
                                            ">閉じる</button>
                                        </div>
                                    </div>
                                </div>
                            `;
                            $('body').append(popup);
                            
                            // 閉じるボタン
                            $('#lw-popup-close, #lw-my-parts-limit-popup').click(function(e) {
                                if (e.target.id === 'lw-popup-close' || e.target.id === 'lw-my-parts-limit-popup') {
                                    $('#lw-my-parts-limit-popup').fadeOut(200, function() {
                                        $(this).remove();
                                    });
                                }
                            });
                        }
                        
                        $('#lw-my-parts-limit-popup').fadeIn(200);
                        return false;
                    });
            }
        });
        
        // サイドメニューの新規追加リンクも無効化
        $('#menu-posts-lw_my_parts .wp-submenu a').each(function() {
            if ($(this).attr('href') && $(this).attr('href').indexOf('post-new.php') !== -1) {
                var $link = $(this);
                
                $link.removeAttr('href')
                    .css({
                        'opacity': '0.5',
                        'cursor': 'not-allowed',
                        'color': '#999'
                    })
                    .click(function(e) {
                        e.preventDefault();
                        
                        // 同じポップアップを表示
                        $('.page-title-action:contains("新規追加")').click();
                        return false;
                    });
                
                // リンクの横に「制限中」を追加
                if (!$link.find('.lw-limit-badge').length) {
                    $link.append('<span class="lw-limit-badge" style="background:#d63638; color:#fff; padding:2px 6px; border-radius:3px; font-size:10px; margin-left:5px;">制限中</span>');
                }
            }
        });
    });
    </script>
    <?php
});

/* ===================================================================
 * 一覧画面での使用状況表示
 * ================================================================ */

add_action( 'admin_notices', function() {
    $screen = get_current_screen();
    
    if ( ! $screen || $screen->post_type !== 'lw_my_parts' || $screen->base !== 'edit' ) {
        return;
    }
    
    if ( defined( 'LW_HAS_SUBSCRIPTION' ) && LW_HAS_SUBSCRIPTION ) {
        return;
    }
    
    $current_count = lw_get_my_parts_free_count();
    $remaining = 5 - $current_count;
    
    if ( $remaining > 0 ) {
        ?>
        <div class="notice notice-info is-dismissible">
            <p>
                📊 無料プランでのマイパーツ作成状況：
                <strong><?php echo $current_count; ?> / 5個</strong> 使用中
                （あと<strong style="color: #0073aa;"><?php echo $remaining; ?>個</strong>作成可能）
            </p>
        </div>
        <?php
    } else {
        ?>
        <div class="notice notice-warning">
            <p>
                ⚠️ マイパーツの作成上限（5個）に達しました。
                追加で作成するには<a href="<?php echo lw_premium_info_link(); ?>" target="_blank">プレミアムプラン</a>へのアップグレードが必要です。
            </p>
        </div>
        <?php
    }
});

/* ===================================================================
 * 直接URLアクセスもブロック
 * ================================================================ */

add_action( 'load-post-new.php', function() {
    global $typenow;
    
    if ( $typenow !== 'lw_my_parts' ) {
        return;
    }
    
    if ( lw_is_my_parts_limit_reached() ) {
        wp_die(
            '<div style="max-width: 600px; margin: 100px auto; padding: 40px; background: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center;">
                <h1 style="color: #d63638; margin-bottom: 20px;">アクセス制限</h1>
                <p style="font-size: 16px; color: #333; margin-bottom: 30px;">
                    無料プランでのマイパーツ作成上限（5個）に達しています。<br>
                    このページにはアクセスできません。
                </p>
                <p>
                    <a href="' . lw_premium_info_link() . '" target="_blank" style="display: inline-block; padding: 15px 30px; background: #0073aa; color: #fff; text-decoration: none; border-radius: 4px; margin-right: 10px;">プレミアムプランを見る</a>
                    <a href="' . admin_url( 'edit.php?post_type=lw_my_parts' ) . '" style="display: inline-block; padding: 15px 30px; background: #666; color: #fff; text-decoration: none; border-radius: 4px;">一覧に戻る</a>
                </p>
            </div>',
            'アクセス制限',
            array( 'response' => 403 )
        );
    }
});

/**
 * デバッグ用リセット関数
 */
function lw_reset_my_parts_free_count() {
    if ( ! current_user_can( 'administrator' ) ) {
        return false;
    }
    
    update_option( 'lw_my_parts_free_count', 0 );
    
    $posts = get_posts( array(
        'post_type' => 'lw_my_parts',
        'posts_per_page' => -1,
        'post_status' => 'any',
        'fields' => 'ids'
    ));
    
    foreach ( $posts as $post_id ) {
        delete_post_meta( $post_id, '_lw_my_parts_counted' );
    }
    
    return true;
}