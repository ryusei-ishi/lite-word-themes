<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * コードエディタ機能
 * マイパーツに HTML/CSS/JavaScript コードエディタを追加
 */

/* ==========================================================
 * 1. エディタモード切り替えメタボックス（サイドバー）
 * ======================================================= */
add_action( 'add_meta_boxes', 'lw_add_editor_mode_metabox' );
function lw_add_editor_mode_metabox() {
	add_meta_box(
		'lw_editor_mode_box',
		'✏️ 編集モード',
		'lw_render_editor_mode_metabox',
		'lw_my_parts',
		'side',
		'high'
	);
}

function lw_render_editor_mode_metabox( $post ) {
	wp_nonce_field( 'lw_save_editor_mode', 'lw_editor_mode_nonce' );
	
	$editor_mode = get_post_meta( $post->ID, '_lw_editor_mode', true );
	if ( empty( $editor_mode ) ) {
		$editor_mode = 'normal';
	}
	
	$full_width = get_post_meta( $post->ID, '_lw_full_width', true );
	$is_full_width = ( $full_width === 'on' );
	?>
	<div style="padding: 10px 0;">
		<!-- ★ コーディング特化モードボタン -->
		<?php if ( 'code' === $editor_mode ) : ?>
		<div style="margin-bottom: 15px;">
			<button type="button" id="lw-open-fullscreen-editor" class="button button-primary button-large" style="width: 100%; padding: 10px; font-size: 14px; font-weight: bold;">
				🚀 コーディング特化モード
			</button>
			<p style="margin: 8px 0 0 0; font-size: 11px; color: #666; text-align: center;">
				軽量なエディタで高速編集
			</p>
		</div>
		<?php endif; ?>
		
		<label style="display: block; margin-bottom: 10px;">
			<input type="radio" name="lw_editor_mode" value="normal" <?php checked( $editor_mode, 'normal' ); ?>>
			<strong>通常エディタ</strong>
			<span style="display: block; font-size: 12px; color: #666; margin-left: 24px;">
				Gutenbergエディタ
			</span>
		</label>
		
		<label style="display: block; margin-top: 15px;">
			<input type="radio" name="lw_editor_mode" value="code" <?php checked( $editor_mode, 'code' ); ?>>
			<strong>コードエディタ</strong>
			<span style="display: block; font-size: 12px; color: #666; margin-left: 24px;">
				HTML + CSS + JavaScript
			</span>
		</label>
		
		<div style="margin-top: 20px; padding-top: 15px; border-top: 1px solid #ddd;">
			<label style="display: flex; align-items: center; justify-content: space-between;">
				<span style="font-weight: bold;">全幅表示</span>
				<div class="lw-toggle-switch">
					<input 
						type="checkbox" 
						id="lw_full_width_toggle" 
						name="lw_full_width" 
						value="on" 
						<?php checked( $is_full_width, true ); ?>
						style="display: none;"
					>
					<label for="lw_full_width_toggle" class="lw-toggle-label">
						<span class="lw-toggle-inner"></span>
						<span class="lw-toggle-switch-slider"></span>
					</label>
				</div>
			</label>
			<p style="margin: 8px 0 0 0; font-size: 11px; color: #666;">
				ONにすると、コンテナ幅を無視して全幅表示になります
			</p>
		</div>
	</div>
	
	<!-- 保存中インジケーター -->
	<div id="lw-saving-indicator" style="display: none; margin-top: 15px; padding: 10px; background: #fff3cd; border-left: 3px solid #ffc107; font-size: 12px;">
		<strong>💾 保存中...</strong><br>
		しばらくお待ちください
	</div>
	
	<div style="margin-top: 15px; padding: 10px; background: #f0f6fc; border-left: 3px solid #0073aa; font-size: 12px;">
		<strong>💡 ヒント</strong><br>
		コードエディタモードでは、HTMLとCSSとJavaScriptを直接記述できます。<br>
		<span style="color: #d63638; font-weight: bold;">モード切り替え時は自動保存されます</span>
	</div>
	
	<script>
	jQuery(document).ready(function($) {
		// ★ コーディング特化モードボタン
		$('#lw-open-fullscreen-editor').on('click', function(e) {
			e.preventDefault();
			var postId = <?php echo $post->ID; ?>;
			var url = ajaxurl.replace('admin-ajax.php', 'admin.php') + 
			          '?action=lw_code_editor_fullscreen&post_id=' + postId +
			          '&_wpnonce=<?php echo wp_create_nonce('lw_fullscreen_editor_' . $post->ID); ?>';
			
			// 新しいウィンドウのサイズと位置
			var width = screen.width * 0.9;
			var height = screen.height * 0.9;
			var left = (screen.width - width) / 2;
			var top = (screen.height - height) / 2;
			
			// 新しいウィンドウで開く
			var editorWindow = window.open(
				url, 
				'lw_fullscreen_editor',
				'width=' + width + ',height=' + height + ',left=' + left + ',top=' + top + ',resizable=yes,scrollbars=yes'
			);
			
			// ウィンドウが正常に開いたら、現在のページを一覧に移動
			if (editorWindow) {
				// 少し待ってから一覧ページに移動（ウィンドウが開くのを確認）
				setTimeout(function() {
					window.location.href = 'edit.php?post_type=lw_my_parts';
				}, 500);
			} else {
				// ポップアップがブロックされた場合
				alert('ポップアップがブロックされました。\nブラウザの設定でポップアップを許可してください。');
			}
		});
	});
	</script>
	
	<style>
	.lw-toggle-switch {
		position: relative;
		display: inline-block;
		width: 50px;
		height: 24px;
	}
	
	.lw-toggle-label {
		position: absolute;
		cursor: pointer;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background-color: #ccc;
		transition: .4s;
		border-radius: 24px;
	}
	
	.lw-toggle-label:before {
		position: absolute;
		content: "";
		height: 18px;
		width: 18px;
		left: 3px;
		bottom: 3px;
		background-color: white;
		transition: .4s;
		border-radius: 50%;
	}
	
	input:checked + .lw-toggle-label {
		background-color: #0073aa;
	}
	
	input:checked + .lw-toggle-label:before {
		transform: translateX(26px);
	}
	
	.lw-toggle-label:hover {
		opacity: 0.8;
	}
	</style>
	<?php
}

/* ==========================================================
 * 2. ★ コードモード時のみGutenbergエディタを削除
 * ======================================================= */
add_action( 'admin_init', 'lw_remove_editor_for_code_mode' );
function lw_remove_editor_for_code_mode() {
	if ( ! is_admin() ) {
		return;
	}
	
	global $pagenow;
	if ( ! in_array( $pagenow, array( 'post.php', 'post-new.php' ) ) ) {
		return;
	}
	
	if ( isset( $_GET['post_type'] ) && $_GET['post_type'] !== 'lw_my_parts' ) {
		return;
	}
	
	if ( isset( $_GET['post'] ) ) {
		$post_id = intval( $_GET['post'] );
		$editor_mode = get_post_meta( $post_id, '_lw_editor_mode', true );
		
		if ( 'code' === $editor_mode ) {
			remove_post_type_support( 'lw_my_parts', 'editor' );
		}
	}
}

/* ==========================================================
 * 3. コードエディタメタボックス（メインエリア）
 * ======================================================= */
add_action( 'add_meta_boxes', 'lw_add_code_editor_metabox' );
function lw_add_code_editor_metabox() {
	add_meta_box(
		'lw_code_editor_box',
		'💻 コードエディタ（HTML + CSS + JavaScript）',
		'lw_render_code_editor_metabox',
		'lw_my_parts',
		'normal',
		'high'
	);
}

function lw_render_code_editor_metabox( $post ) {
	wp_nonce_field( 'lw_save_code_editor', 'lw_code_editor_nonce' );
	
	$editor_mode = get_post_meta( $post->ID, '_lw_editor_mode', true );
	$custom_html = get_post_meta( $post->ID, '_lw_custom_html', true );
	$custom_css = get_post_meta( $post->ID, '_lw_custom_css', true );
	$custom_js = get_post_meta( $post->ID, '_lw_custom_js', true ); // ★ JS変数追加
	
	$display = ( 'code' === $editor_mode ) ? 'block' : 'none';
	?>
	
	<div id="lw-code-editor-container" style="display: <?php echo esc_attr( $display ); ?>;">
		<!-- レイアウト切り替えボタン -->
		<div style="margin-bottom: 20px; padding: 15px; background: #f0f0f0; border-radius: 4px;">
			<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
				<strong style="font-size: 14px;">📐 レイアウト</strong>
				<div style="display: flex; align-items: center; gap: 10px;">
					<span id="lw-layout-status" style="font-size: 12px; color: #666; font-weight: bold;"></span>
					<button type="button" id="lw-theme-toggle" class="button" style="padding: 5px 12px;" title="ダークモード切り替え">
						<span id="lw-theme-icon">🌙</span> <span id="lw-theme-text">ダーク</span>
					</button>
				</div>
			</div>
			
			<div style="display: flex; gap: 8px; flex-wrap: wrap;">
				<!-- 基本レイアウト -->
				<button type="button" id="lw-layout-vertical" class="button" style="padding: 5px 12px;" title="HTMLとCSSとJSを縦に並べる">
					<span style="font-size: 14px;">⬇️</span> 縦並び
				</button>
				<button type="button" id="lw-layout-horizontal" class="button" style="padding: 5px 12px;" title="HTMLとCSSとJSを横に並べる">
					<span style="font-size: 14px;">↔️</span> 横並び
				</button>
				
				<span style="border-left: 2px solid #ccc; margin: 0 5px;"></span>
				
				<!-- 表示切り替え -->
				<button type="button" id="lw-layout-html-only" class="button" style="padding: 5px 12px;" title="HTMLエディタのみ表示">
					<span style="font-size: 14px;">📝</span> HTMLのみ
				</button>
				<button type="button" id="lw-layout-css-only" class="button" style="padding: 5px 12px;" title="CSSエディタのみ表示">
					<span style="font-size: 14px;">🎨</span> CSSのみ
				</button>
				<button type="button" id="lw-layout-js-only" class="button" style="padding: 5px 12px;" title="JavaScriptエディタのみ表示">
					<span style="font-size: 14px;">⚡</span> JSのみ
				</button>
				
				<span style="border-left: 2px solid #ccc; margin: 0 5px;"></span>
				
				<!-- 順序入れ替え -->
				<button type="button" id="lw-layout-reverse" class="button" style="padding: 5px 12px;" title="エディタの順序を入れ替える">
					<span style="font-size: 14px;">🔄</span> 順序入れ替え
				</button>
			</div>
		</div>
		
		<!-- エディタエリア -->
		<div id="lw-editors-wrapper" style="display: flex; flex-direction: column; gap: 20px;">
			<div id="lw-html-editor-wrapper" style="flex: 1; overflow-x: scroll;">
				<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
					<label for="lw_custom_html" style="font-weight: bold; margin: 0;">
						📝 HTML コード　　※注意：絵文字は利用できません。
					</label>
					<button type="button" id="lw-copy-html" class="button button-small" style="padding: 3px 10px; font-size: 12px;">
						📋 コピー
					</button>
				</div>
				<textarea 
					id="lw_custom_html" 
					name="lw_custom_html" 
					rows="15" 
					style="width:100%; font-family: monospace; font-size: 14px;"
				><?php echo esc_textarea( $custom_html ); ?></textarea>
			</div>
			
			<div id="lw-css-editor-wrapper" style="flex: 1; overflow-x: scroll;">
				<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
					<label for="lw_custom_css" style="font-weight: bold; margin: 0;">
						🎨 CSS コード
					</label>
					<button type="button" id="lw-copy-css" class="button button-small" style="padding: 3px 10px; font-size: 12px;">
						📋 コピー
					</button>
				</div>
				<textarea 
					id="lw_custom_css" 
					name="lw_custom_css" 
					rows="15" 
					style="width:100%; font-family: monospace; font-size: 14px;"
				><?php echo esc_textarea( $custom_css ); ?></textarea>
			</div>
			
			<div id="lw-js-editor-wrapper" style="flex: 1; overflow-x: scroll;">
				<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
					<label for="lw_custom_js" style="font-weight: bold; margin: 0;">
						⚡ JavaScript コード
					</label>
					<button type="button" id="lw-copy-js" class="button button-small" style="padding: 3px 10px; font-size: 12px;">
						📋 コピー
					</button>
				</div>
				<textarea 
					id="lw_custom_js" 
					name="lw_custom_js" 
					rows="15" 
					style="width:100%; font-family: monospace; font-size: 14px;"
				><?php echo esc_textarea( $custom_js ); ?></textarea>
			</div>
		</div>
		
		<div style="margin-top: 15px; padding: 12px; background: #fff3cd; border-left: 3px solid #ffc107;">
			<strong>⚠️ 注意</strong><br>
			<ul style="margin: 8px 0 0 20px; font-size: 13px;">
				<li>コードエディタモードでは、通常エディタの内容は使用されません</li>
				<li>HTML、CSS、JavaScriptが直接出力されます</li>
				<li>スタイルは &lt;style&gt; タグ、JavaScriptは &lt;script&gt; タグで自動的に囲まれます</li>
			</ul>
		</div>
	</div>
	
	<?php if ( 'code' !== $editor_mode ) : ?>
	<div id="lw-code-mode-notice" style="padding: 15px; background: #f0f6fc; border-left: 3px solid #0073aa;">
		<strong>💡 コードエディタを使用するには</strong><br>
		右サイドバーの「編集モード」で「コードエディタ」を選択してください。自動保存されます。
	</div>
	<?php endif; ?>
	
	<script>
	jQuery(document).ready(function($) {
		var htmlEditorInstance = null;
		var cssEditorInstance = null;
		var jsEditorInstance = null;
		var isAutoSaving = false;
		
		// ★ レイアウト設定を読み込み
		var currentLayout = localStorage.getItem('lw_code_editor_layout') || 'vertical';
		var isReversed = localStorage.getItem('lw_code_editor_reversed') === 'true';
		var isDarkMode = localStorage.getItem('lw_code_editor_dark_mode') === 'true';
		
		// ★ ダークモード切り替え関数
		function setTheme(dark) {
			isDarkMode = dark;
			
			if (dark) {
				// ダークモード
				$('#lw-theme-icon').text('☀️');
				$('#lw-theme-text').text('ライト');
				$('#lw-theme-toggle').addClass('button-primary');
				
				if (htmlEditorInstance) {
					htmlEditorInstance.setOption('theme', 'material-darker');
					setTimeout(function() {
						htmlEditorInstance.refresh();
					}, 50);
				}
				if (cssEditorInstance) {
					cssEditorInstance.setOption('theme', 'material-darker');
					setTimeout(function() {
						cssEditorInstance.refresh();
					}, 50);
				}
				// ★ JSエディタのテーマ変更を追加
				if (jsEditorInstance) {
					jsEditorInstance.setOption('theme', 'material-darker');
					setTimeout(function() {
						jsEditorInstance.refresh();
					}, 50);
				}
			} else {
				// ライトモード
				$('#lw-theme-icon').text('🌙');
				$('#lw-theme-text').text('ダーク');
				$('#lw-theme-toggle').removeClass('button-primary');
				
				if (htmlEditorInstance) {
					htmlEditorInstance.setOption('theme', 'default');
					setTimeout(function() {
						htmlEditorInstance.refresh();
					}, 50);
				}
				if (cssEditorInstance) {
					cssEditorInstance.setOption('theme', 'default');
					setTimeout(function() {
						cssEditorInstance.refresh();
					}, 50);
				}
				// ★ JSエディタのテーマ変更を追加
				if (jsEditorInstance) {
					jsEditorInstance.setOption('theme', 'default');
					setTimeout(function() {
						jsEditorInstance.refresh();
					}, 50);
				}
			}
			
			localStorage.setItem('lw_code_editor_dark_mode', dark ? 'true' : 'false');
		}
		
		// ★ レイアウト切り替え関数
		function setLayout(layout, reversed) {
			var $wrapper = $('#lw-editors-wrapper');
			var $htmlWrapper = $('#lw-html-editor-wrapper');
			var $cssWrapper = $('#lw-css-editor-wrapper');
			var $jsWrapper = $('#lw-js-editor-wrapper'); // ★ JS追加
			
			// すべてのボタンからbutton-primaryを削除
			$('.button[id^="lw-layout-"]').removeClass('button-primary');
			
			// 表示リセット
			$htmlWrapper.show();
			$cssWrapper.show();
			$jsWrapper.show(); // ★ JS追加
			
			// レイアウト適用
			if (layout === 'html-only') {
				// HTMLのみ表示
				$wrapper.css({
					'flex-direction': 'column',
					'gap': '20px'
				});
				$cssWrapper.hide();
				$jsWrapper.hide(); // ★ JS追加
				$htmlWrapper.css('flex', '1');
				
				$('#lw-layout-html-only').addClass('button-primary');
				$('#lw-layout-status').text('📝 HTMLエディタのみ表示');
				
			} else if (layout === 'css-only') {
				// CSSのみ表示
				$wrapper.css({
					'flex-direction': 'column',
					'gap': '20px'
				});
				$htmlWrapper.hide();
				$jsWrapper.hide(); // ★ JS追加
				$cssWrapper.css('flex', '1');
				
				$('#lw-layout-css-only').addClass('button-primary');
				$('#lw-layout-status').text('🎨 CSSエディタのみ表示');
				
			} else if (layout === 'js-only') {
				// ★ JSのみ表示を追加
				$wrapper.css({
					'flex-direction': 'column',
					'gap': '20px'
				});
				$htmlWrapper.hide();
				$cssWrapper.hide();
				$jsWrapper.css('flex', '1');
				
				$('#lw-layout-js-only').addClass('button-primary');
				$('#lw-layout-status').text('⚡ JavaScriptエディタのみ表示');
				
			} else if (layout === 'horizontal') {
				// 横並び
				$wrapper.css({
					'flex-direction': 'row',
					'gap': '20px'
				});
				$htmlWrapper.css('flex', '1');
				$cssWrapper.css('flex', '1');
				$jsWrapper.css('flex', '1'); // ★ JS追加
				
				$('#lw-layout-horizontal').addClass('button-primary');
				$('#lw-layout-status').text('↔️ 横並びモード');
				
			} else {
				// 縦並び（デフォルト）
				$wrapper.css({
					'flex-direction': 'column',
					'gap': '20px'
				});
				$htmlWrapper.css('flex', '1');
				$cssWrapper.css('flex', '1');
				$jsWrapper.css('flex', '1'); // ★ JS追加
				
				$('#lw-layout-vertical').addClass('button-primary');
				$('#lw-layout-status').text('⬇️ 縦並びモード');
			}
			
			// ★ 順序入れ替え（HTML -> CSS -> JS の順番を変更）
			if (reversed) {
				$wrapper.prepend($jsWrapper);
				$wrapper.prepend($cssWrapper);
				$wrapper.prepend($htmlWrapper);
				$('#lw-layout-reverse').addClass('button-primary');
			} else {
				$wrapper.prepend($jsWrapper);
				$wrapper.prepend($cssWrapper);
				$wrapper.prepend($htmlWrapper);
				$('#lw-layout-reverse').removeClass('button-primary');
			}
			
			// ★ CodeMirrorのリフレッシュ（JS追加）
			setTimeout(function() {
				if (htmlEditorInstance && $htmlWrapper.is(':visible')) {
					htmlEditorInstance.refresh();
				}
				if (cssEditorInstance && $cssWrapper.is(':visible')) {
					cssEditorInstance.refresh();
				}
				if (jsEditorInstance && $jsWrapper.is(':visible')) {
					jsEditorInstance.refresh();
				}
			}, 100);
			
			// 設定を保存
			localStorage.setItem('lw_code_editor_layout', layout);
			localStorage.setItem('lw_code_editor_reversed', reversed ? 'true' : 'false');
			currentLayout = layout;
			isReversed = reversed;
		}
		
		// ★ 初期レイアウトを適用
		setLayout(currentLayout, isReversed);
		
		// ★ コピーボタンの機能
		function copyToClipboard(text, buttonId) {
			if (!text) {
				alert('コピーする内容がありません');
				return;
			}
			
			// クリップボードにコピー
			if (navigator.clipboard && navigator.clipboard.writeText) {
				navigator.clipboard.writeText(text).then(function() {
					// 成功時のフィードバック
					var $button = $(buttonId);
					var originalText = $button.text();
					$button.text('✅ コピーしました!')
						.css('background', '#46b450')
						.css('color', '#fff')
						.css('border-color', '#46b450');
					
					setTimeout(function() {
						$button.text(originalText)
							.css('background', '')
							.css('color', '')
							.css('border-color', '');
					}, 2000);
				}).catch(function(err) {
					alert('コピーに失敗しました: ' + err);
				});
			} else {
				// フォールバック（古いブラウザ対応）
				var $temp = $('<textarea>');
				$('body').append($temp);
				$temp.val(text).select();
				document.execCommand('copy');
				$temp.remove();
				
				var $button = $(buttonId);
				var originalText = $button.text();
				$button.text('✅ コピーしました!')
					.css('background', '#46b450')
					.css('color', '#fff')
					.css('border-color', '#46b450');
				
				setTimeout(function() {
					$button.text(originalText)
						.css('background', '')
						.css('color', '')
						.css('border-color', '');
				}, 2000);
			}
		}
		
		// HTMLコピーボタン
		$('#lw-copy-html').on('click', function(e) {
			e.preventDefault();
			var content = '';
			if (htmlEditorInstance) {
				content = htmlEditorInstance.getValue();
			} else {
				content = $('#lw_custom_html').val();
			}
			copyToClipboard(content, '#lw-copy-html');
		});
		
		// CSSコピーボタン
		$('#lw-copy-css').on('click', function(e) {
			e.preventDefault();
			var content = '';
			if (cssEditorInstance) {
				content = cssEditorInstance.getValue();
			} else {
				content = $('#lw_custom_css').val();
			}
			copyToClipboard(content, '#lw-copy-css');
		});
		
		// ★ JSコピーボタンを追加
		$('#lw-copy-js').on('click', function(e) {
			e.preventDefault();
			var content = '';
			if (jsEditorInstance) {
				content = jsEditorInstance.getValue();
			} else {
				content = $('#lw_custom_js').val();
			}
			copyToClipboard(content, '#lw-copy-js');
		});
		
		// ★ レイアウト切り替えボタン
		$('#lw-layout-vertical').on('click', function(e) {
			e.preventDefault();
			setLayout('vertical', isReversed);
		});
		
		$('#lw-layout-horizontal').on('click', function(e) {
			e.preventDefault();
			setLayout('horizontal', isReversed);
		});
		
		$('#lw-layout-html-only').on('click', function(e) {
			e.preventDefault();
			setLayout('html-only', false);
		});
		
		$('#lw-layout-css-only').on('click', function(e) {
			e.preventDefault();
			setLayout('css-only', false);
		});
		
		// ★ JSのみボタンを追加
		$('#lw-layout-js-only').on('click', function(e) {
			e.preventDefault();
			setLayout('js-only', false);
		});
		
		$('#lw-layout-reverse').on('click', function(e) {
			e.preventDefault();
			setLayout(currentLayout, !isReversed);
		});
		
		// ★ ダークモード切り替えボタン
		$('#lw-theme-toggle').on('click', function(e) {
			e.preventDefault();
			var newDarkMode = !isDarkMode;
			
			// デバッグ用（オプション）
			console.log('Theme toggle clicked. Current:', isDarkMode, 'New:', newDarkMode);
			console.log('HTML instance:', htmlEditorInstance ? 'exists' : 'null');
			console.log('CSS instance:', cssEditorInstance ? 'exists' : 'null');
			console.log('JS instance:', jsEditorInstance ? 'exists' : 'null');
			
			setTheme(newDarkMode);
		});
		
		// ★ エディタモード切り替え時の自動保存＆リロード
		$('input[name="lw_editor_mode"]').on('change', function() {
			if (isAutoSaving) return;
			
			var newMode = $(this).val();
			var currentMode = '<?php echo esc_js( $editor_mode ); ?>';
			
			if (newMode === currentMode) return;
			
			isAutoSaving = true;
			
			// 保存インジケーター表示
			$('#lw-saving-indicator').fadeIn();
			
			// CodeMirrorの内容を保存
			if (htmlEditorInstance) htmlEditorInstance.save();
			if (cssEditorInstance) cssEditorInstance.save();
			if (jsEditorInstance) jsEditorInstance.save(); // ★ JS追加
			
			// Ajax保存
			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action: 'lw_save_editor_mode',
					post_id: <?php echo $post->ID; ?>,
					editor_mode: newMode,
					full_width: $('#lw_full_width_toggle').is(':checked') ? 'on' : '',
					nonce: '<?php echo wp_create_nonce( 'lw_auto_save_editor_mode' ); ?>'
				},
				success: function(response) {
					if (response.success) {
						// 保存成功 → リロード
						window.location.reload();
					} else {
						alert('保存に失敗しました: ' + (response.data || '不明なエラー'));
						$('#lw-saving-indicator').fadeOut();
						isAutoSaving = false;
					}
				},
				error: function() {
					alert('通信エラーが発生しました。');
					$('#lw-saving-indicator').fadeOut();
					isAutoSaving = false;
				}
			});
		});
		
		// ★ 全幅表示切り替え時の自動保存（リロードなし）
		$('#lw_full_width_toggle').on('change', function() {
			var fullWidth = $(this).is(':checked') ? 'on' : '';
			
			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action: 'lw_save_full_width',
					post_id: <?php echo $post->ID; ?>,
					full_width: fullWidth,
					nonce: '<?php echo wp_create_nonce( 'lw_auto_save_full_width' ); ?>'
				},
				success: function(response) {
					if (response.success) {
						// 保存成功の通知（オプション）
						console.log('全幅設定を保存しました');
					}
				}
			});
		});
		
		// CodeMirrorの初期化
		if (typeof wp.codeEditor !== 'undefined' && $('#lw_custom_html').length) {
			var htmlSettings = wp.codeEditor.defaultSettings ? _.clone(wp.codeEditor.defaultSettings) : {};
			htmlSettings.codemirror = _.extend(
				{},
				htmlSettings.codemirror,
				{
					mode: 'htmlmixed',
					lineNumbers: true,
					lineWrapping: false,  // ★ 折り返しをOFF（横スクロール）
					indentUnit: 2,
					tabSize: 2,
					theme: isDarkMode ? 'material-darker' : 'default',  // ★ テーマ適用
					inputStyle: 'textarea',  // ★★ 日本語入力（IME）対応
					autoCloseTags: true,
					autoCloseBrackets: true,
					matchBrackets: true,
					styleActiveLine: true,
					lint: false,  // ★ リント（構文チェック）を無効化
					gutters: ['CodeMirror-linenumbers']  // ★ ガターはライン番号のみ
				}
			);
			
			var htmlEditor = wp.codeEditor.initialize($('#lw_custom_html'), htmlSettings);
			if (htmlEditor && htmlEditor.codemirror) {
				htmlEditorInstance = htmlEditor.codemirror;
			}
			
			var cssSettings = wp.codeEditor.defaultSettings ? _.clone(wp.codeEditor.defaultSettings) : {};
			cssSettings.codemirror = _.extend(
				{},
				cssSettings.codemirror,
				{
					mode: 'css',
					lineNumbers: true,
					lineWrapping: false,  // ★ 折り返しをOFF（横スクロール）
					indentUnit: 2,
					tabSize: 2,
					theme: isDarkMode ? 'material-darker' : 'default',  // ★ テーマ適用
					inputStyle: 'textarea',  // ★★ 日本語入力（IME）対応
					autoCloseBrackets: true,
					matchBrackets: true,
					styleActiveLine: true,
					lint: false,  // ★ リント（構文チェック）を無効化
					gutters: ['CodeMirror-linenumbers']  // ★ ガターはライン番号のみ
				}
			);
			
			var cssEditor = wp.codeEditor.initialize($('#lw_custom_css'), cssSettings);
			if (cssEditor && cssEditor.codemirror) {
				cssEditorInstance = cssEditor.codemirror;
			}
			
			// ★ JavaScriptエディタの初期化
			var jsSettings = wp.codeEditor.defaultSettings ? _.clone(wp.codeEditor.defaultSettings) : {};
			jsSettings.codemirror = _.extend(
				{},
				jsSettings.codemirror,
				{
					mode: 'javascript',
					lineNumbers: true,
					lineWrapping: false,
					indentUnit: 2,
					tabSize: 2,
					theme: isDarkMode ? 'material-darker' : 'default',
					inputStyle: 'textarea',  // ★★ 日本語入力（IME）対応
					autoCloseBrackets: true,
					matchBrackets: true,
					styleActiveLine: true,
					lint: false,  // ★ リント（構文チェック）を無効化
					gutters: ['CodeMirror-linenumbers']  // ★ ガターはライン番号のみ
				}
			);
			
			var jsEditor = wp.codeEditor.initialize($('#lw_custom_js'), jsSettings);
			if (jsEditor && jsEditor.codemirror) {
				jsEditorInstance = jsEditor.codemirror;
			}
			
			// ★ CodeMirror初期化後にレイアウトとテーマを再適用
			setTimeout(function() {
				setLayout(currentLayout, isReversed);
				// テーマ適用を少し遅らせて確実に反映させる
				setTimeout(function() {
					setTheme(isDarkMode);
				}, 200);
			}, 500);
		}
		
		// ★ 通常の保存時（JS追加）
		$('#post').on('submit', function() {
			if (htmlEditorInstance) {
				htmlEditorInstance.save();
			}
			if (cssEditorInstance) {
				cssEditorInstance.save();
			}
			if (jsEditorInstance) {
				jsEditorInstance.save();
			}
		});
		
		// ★ オートセーブ時（JS追加）
		$(document).on('heartbeat-tick.autosave', function() {
			if (htmlEditorInstance) {
				htmlEditorInstance.save();
			}
			if (cssEditorInstance) {
				cssEditorInstance.save();
			}
			if (jsEditorInstance) {
				jsEditorInstance.save();
			}
		});
	});
	</script>
	
	<style>
    <?php if ( 'code' === $editor_mode ) : ?>
    /* ★ コードエディタモードの時だけ適用 */
    #lw-insert-block {
        display: none !important;
    }
    <?php endif; ?>
    .css-1n451hs {
        height: auto;
    }
	
	/* ★ CodeMirrorのベーススタイル（シンタックスハイライトを妨げないように調整） */
	.CodeMirror {
		border: 1px solid #ddd !important;
		border-radius: 4px;
		font-size: 14px;
		height: auto;
		min-height: 300px;
		font-family: 'Consolas', 'Monaco', 'Courier New', monospace !important;
	}
	
	.CodeMirror-scroll{
		min-height: 400px;
		overflow-x: auto !important;  /* ★ 横スクロール有効 */
		overflow-y: auto !important;
	}
	
	/* ★ 横スクロール用の設定 */
	.CodeMirror pre {
		white-space: pre !important;  /* 折り返しなし */
	}
	
	.CodeMirror-hscrollbar {
		display: block !important;  /* 横スクロールバー表示 */
	}
	
	/* 行番号エリア */
	.CodeMirror-gutters {
		border-right: 1px solid #ddd !important;
	}
	
	/* アクティブ行のハイライト */
	.CodeMirror-activeline-background {
		background: rgba(0, 115, 170, 0.1) !important;
	}
	
	/* 選択範囲 */
	.CodeMirror-selected {
		background: rgba(0, 115, 170, 0.2) !important;
	}
	
	/* カーソル */
	.CodeMirror-cursor {
		border-left: 2px solid #000 !important;
	}
	
	/* ★ レイアウト切り替えボタンのスタイル */
	.button[id^="lw-layout-"] {
		transition: all 0.3s ease;
		border: 1px solid #ddd;
		background: #fff;
		font-size: 13px;
	}
	
	.button[id^="lw-layout-"]:hover {
		background: #f0f0f0;
		border-color: #999;
	}
	
	.button[id^="lw-layout-"].button-primary {
		background: #0073aa !important;
		color: #fff !important;
		border-color: #0073aa !important;
	}
	
	.button[id^="lw-layout-"].button-primary:hover {
		background: #005a87 !important;
		border-color: #005a87 !important;
	}
	
	/* ★ コピーボタンのスタイル */
	#lw-copy-html,
	#lw-copy-css,
	#lw-copy-js {
		transition: all 0.3s ease;
		border: 1px solid #0073aa;
		background: #fff;
		color: #0073aa;
		cursor: pointer;
		font-weight: bold;
	}
	
	#lw-copy-html:hover,
	#lw-copy-css:hover,
	#lw-copy-js:hover {
		background: #0073aa;
		color: #fff;
		border-color: #0073aa;
	}
	
	#lw-copy-html:active,
	#lw-copy-css:active,
	#lw-copy-js:active {
		transform: scale(0.95);
	}
	
	/* ★ ダークモード切り替えボタン */
	#lw-theme-toggle {
		transition: all 0.3s ease;
		border: 1px solid #ddd;
		background: #fff;
		font-size: 13px;
	}
	
	#lw-theme-toggle:hover {
		background: #f0f0f0;
		border-color: #999;
	}
	
	#lw-theme-toggle.button-primary {
		background: #0073aa !important;
		color: #fff !important;
		border-color: #0073aa !important;
	}
	
	#lw-theme-toggle.button-primary:hover {
		background: #005a87 !important;
		border-color: #005a87 !important;
	}
	</style>
	<?php
}

/* ==========================================================
 * 4. エディタモード自動保存（AJAX）
 * ======================================================= */
add_action( 'wp_ajax_lw_save_editor_mode', 'lw_save_editor_mode_ajax' );
function lw_save_editor_mode_ajax() {
	// Nonceチェック
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'lw_auto_save_editor_mode' ) ) {
		wp_send_json_error( 'Nonce verification failed' );
	}
	
	$post_id = intval( $_POST['post_id'] );
	$editor_mode = sanitize_text_field( $_POST['editor_mode'] );
	$full_width = isset( $_POST['full_width'] ) ? sanitize_text_field( $_POST['full_width'] ) : '';
	
	// 権限チェック
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		wp_send_json_error( '編集権限がありません' );
	}
	
	// エディタモードを保存
	update_post_meta( $post_id, '_lw_editor_mode', $editor_mode );
	
	// 全幅設定を保存
	if ( $full_width === 'on' ) {
		update_post_meta( $post_id, '_lw_full_width', 'on' );
	} else {
		delete_post_meta( $post_id, '_lw_full_width' );
	}
	
	wp_send_json_success( 'エディタモードを保存しました' );
}

/* ==========================================================
 * 5. 全幅表示設定自動保存（AJAX）
 * ======================================================= */
add_action( 'wp_ajax_lw_save_full_width', 'lw_save_full_width_ajax' );
function lw_save_full_width_ajax() {
	// Nonceチェック
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'lw_auto_save_full_width' ) ) {
		wp_send_json_error( 'Nonce verification failed' );
	}
	
	$post_id = intval( $_POST['post_id'] );
	$full_width = isset( $_POST['full_width'] ) ? sanitize_text_field( $_POST['full_width'] ) : '';
	
	// 権限チェック
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		wp_send_json_error( '編集権限がありません' );
	}
	
	// 全幅設定を保存
	if ( $full_width === 'on' ) {
		update_post_meta( $post_id, '_lw_full_width', 'on' );
	} else {
		delete_post_meta( $post_id, '_lw_full_width' );
	}
	
	wp_send_json_success( '全幅設定を保存しました' );
}

/* ==========================================================
 * 6. ★ メタデータ保存（HTML + CSS + JavaScript）
 * ======================================================= */
add_action( 'save_post_lw_my_parts', 'lw_save_code_editor_meta', 10, 2 );
function lw_save_code_editor_meta( $post_id, $post ) {
	// 自動保存時はスキップ
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	
	// リビジョンはスキップ
	if ( wp_is_post_revision( $post_id ) ) {
		return;
	}
	
	// 権限チェック
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	
	// エディタモード保存
	if ( isset( $_POST['lw_editor_mode_nonce'] ) && 
	     wp_verify_nonce( $_POST['lw_editor_mode_nonce'], 'lw_save_editor_mode' ) ) {
		
		if ( isset( $_POST['lw_editor_mode'] ) ) {
			$editor_mode = sanitize_text_field( $_POST['lw_editor_mode'] );
			update_post_meta( $post_id, '_lw_editor_mode', $editor_mode );
		}
		
		// 全幅表示設定
		if ( isset( $_POST['lw_full_width'] ) && $_POST['lw_full_width'] === 'on' ) {
			update_post_meta( $post_id, '_lw_full_width', 'on' );
		} else {
			delete_post_meta( $post_id, '_lw_full_width' );
		}
	}
	
	// コードエディタの内容を保存
	if ( isset( $_POST['lw_code_editor_nonce'] ) && 
	     wp_verify_nonce( $_POST['lw_code_editor_nonce'], 'lw_save_code_editor' ) ) {
		
		if ( isset( $_POST['lw_custom_html'] ) ) {
			update_post_meta( $post_id, '_lw_custom_html', wp_unslash( $_POST['lw_custom_html'] ) );
		}
		
		if ( isset( $_POST['lw_custom_css'] ) ) {
			update_post_meta( $post_id, '_lw_custom_css', wp_unslash( $_POST['lw_custom_css'] ) );
		}
		
		// ★ JavaScript保存を追加
		if ( isset( $_POST['lw_custom_js'] ) ) {
			update_post_meta( $post_id, '_lw_custom_js', wp_unslash( $_POST['lw_custom_js'] ) );
		}
	}
}

/* ==========================================================
 * 7. CodeMirror アセット読み込み
 * ======================================================= */
add_action( 'admin_enqueue_scripts', 'lw_enqueue_code_editor_assets' );
function lw_enqueue_code_editor_assets( $hook ) {
	global $post_type;
	
	if ( $post_type !== 'lw_my_parts' || ( $hook !== 'post.php' && $hook !== 'post-new.php' ) ) {
		return;
	}
	
	// ★ WordPressのコードエディタを読み込み（これで必要なファイルはすべて自動で読み込まれる）
	// lint機能を無効化する設定を渡す
	$editor_settings = array(
		'codemirror' => array(
			'lint' => false,
			'gutters' => array( 'CodeMirror-linenumbers' )
		)
	);
	
	wp_enqueue_code_editor( array( 
		'type' => 'text/html',
		'codemirror' => $editor_settings['codemirror']
	) );
	wp_enqueue_code_editor( array( 
		'type' => 'text/css',
		'codemirror' => $editor_settings['codemirror']
	) );
	wp_enqueue_code_editor( array( 
		'type' => 'text/javascript',
		'codemirror' => $editor_settings['codemirror']
	) );
	
	// CodeMirror本体（念のため）
	wp_enqueue_style( 'wp-codemirror' );
	wp_enqueue_script( 'wp-codemirror' );
	
	// ★ ダークモード用のカスタムCSS（インラインで追加）
	wp_add_inline_style( 'wp-codemirror', '
		/* Material Darker テーマのカスタム定義（見やすさ重視） */
		.cm-s-material-darker.CodeMirror {
			background-color: #1e1e1e !important;
			color: #d4d4d4 !important;
			border: 1px solid #333 !important;
		}
		.cm-s-material-darker .CodeMirror-gutters {
			background: #1e1e1e !important;
			color: #858585 !important;
			border-right: 1px solid #333 !important;
		}
		.cm-s-material-darker .CodeMirror-cursor {
			border-left: 2px solid #ffffff !important;
		}
		.cm-s-material-darker .CodeMirror-activeline-background {
			background: rgba(255, 255, 255, 0.08) !important;
		}
		.cm-s-material-darker .CodeMirror-selected {
			background: rgba(38, 79, 120, 0.6) !important;
		}
		.cm-s-material-darker .CodeMirror-linenumber {
			color: #858585 !important;
		}
		.cm-s-material-darker .CodeMirror-scroll {
			background-color: #1e1e1e !important;
		}
		
		/* HTML/XML タグ */
		.cm-s-material-darker .cm-tag {
			color: #569cd6 !important;  /* 明るい青 */
		}
		
		/* HTML属性名 */
		.cm-s-material-darker .cm-attribute {
			color: #9cdcfe !important;  /* 明るいシアン */
		}
		
		/* 文字列 */
		.cm-s-material-darker .cm-string {
			color: #ce9178 !important;  /* オレンジベージュ */
		}
		
		/* キーワード */
		.cm-s-material-darker .cm-keyword {
			color: #c586c0 !important;  /* 明るい紫 */
		}
		
		/* CSSプロパティ名 */
		.cm-s-material-darker .cm-property {
			color: #9cdcfe !important;  /* 明るいシアン */
		}
		
		/* CSS値・カラー */
		.cm-s-material-darker .cm-atom {
			color: #ce9178 !important;  /* オレンジベージュ */
		}
		
		/* 数値 */
		.cm-s-material-darker .cm-number {
			color: #b5cea8 !important;  /* 明るい緑 */
		}
		
		/* コメント */
		.cm-s-material-darker .cm-comment {
			color: #6a9955 !important;  /* 緑がかったグレー */
		}
		
		/* CSSセレクタ・クラス名 */
		.cm-s-material-darker .cm-qualifier {
			color: #d7ba7d !important;  /* ゴールド */
		}
		
		/* メタ情報 */
		.cm-s-material-darker .cm-meta {
			color: #d7ba7d !important;  /* ゴールド */
		}
		
		/* 変数 */
		.cm-s-material-darker .cm-variable {
			color: #9cdcfe !important;  /* 明るいシアン */
		}
		
		/* 関数名・定義 */
		.cm-s-material-darker .cm-def {
			color: #dcdcaa !important;  /* 明るい黄色 */
		}
		
		/* 演算子 */
		.cm-s-material-darker .cm-operator {
			color: #d4d4d4 !important;  /* グレー */
		}
		
		/* ブラケット（括弧） */
		.cm-s-material-darker .cm-bracket {
			color: #d4d4d4 !important;  /* グレー */
		}
		
		/* ID セレクタ */
		.cm-s-material-darker .cm-builtin {
			color: #4ec9b0 !important;  /* ティール */
		}
		
		/* 疑似クラス */
		.cm-s-material-darker .cm-variable-2 {
			color: #4ec9b0 !important;  /* ティール */
		}
		
		/* タイプセレクタ */
		.cm-s-material-darker .cm-type {
			color: #4ec9b0 !important;  /* ティール */
		}
	' );
}

/* ==========================================================
 * 8. 一覧画面でモード表示
 * ======================================================= */
add_filter( 'manage_lw_my_parts_posts_columns', 'lw_add_editor_mode_column' );
function lw_add_editor_mode_column( $columns ) {
	$new_columns = array();
	foreach ( $columns as $key => $value ) {
		$new_columns[ $key ] = $value;
		if ( $key === 'title' ) {
			$new_columns['editor_mode'] = '編集モード';
		}
	}
	return $new_columns;
}

add_action( 'manage_lw_my_parts_posts_custom_column', 'lw_display_editor_mode_column', 10, 2 );
function lw_display_editor_mode_column( $column, $post_id ) {
	if ( $column === 'editor_mode' ) {
		$editor_mode = get_post_meta( $post_id, '_lw_editor_mode', true );
		
		if ( 'code' === $editor_mode ) {
			echo '<span style="background: #0073aa; color: #fff; padding: 3px 8px; border-radius: 3px; font-size: 11px;">💻 コード</span>';
		} else {
			echo '<span style="background: #ddd; color: #333; padding: 3px 8px; border-radius: 3px; font-size: 11px;">✏️ 通常</span>';
		}
	}
}

/* ==========================================================
 * 9. 全幅表示設定保存（AJAX）- レガシー対応
 * ======================================================= */
add_action( 'wp_ajax_lw_save_fullwidth', 'lw_save_fullwidth_ajax' );
function lw_save_fullwidth_ajax() {
	// Nonceチェック
	if ( ! isset( $_POST['nonce'] ) || ! isset( $_POST['post_id'] ) ) {
		wp_send_json_error( 'Invalid request' );
	}
	
	$post_id = intval( $_POST['post_id'] );
	
	if ( ! wp_verify_nonce( $_POST['nonce'], 'lw_save_fullwidth_' . $post_id ) ) {
		wp_send_json_error( 'Nonce verification failed' );
	}
	
	// 権限チェック
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		wp_send_json_error( '編集権限がありません' );
	}
	
	// 全幅設定を保存
	$full_width = isset( $_POST['full_width'] ) ? sanitize_text_field( $_POST['full_width'] ) : 'off';
	
	if ( $full_width === 'on' ) {
		update_post_meta( $post_id, '_lw_full_width', 'on' );
	} else {
		delete_post_meta( $post_id, '_lw_full_width' );
	}
	
	wp_send_json_success( '全幅表示設定を保存しました' );
}