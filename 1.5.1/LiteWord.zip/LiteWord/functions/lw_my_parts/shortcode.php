<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * LWマイパーツ本文を呼び出すショートコード
 * 使い方: [my_parts_content id="123" show_draft="true"]
 */

// ★ JS出力用のグローバル配列
global $lw_my_parts_scripts;
if ( ! isset( $lw_my_parts_scripts ) ) {
	$lw_my_parts_scripts = array();
}

function lw_shortcode_my_parts_content( $atts ) {
	global $lw_my_parts_scripts;

	$atts = shortcode_atts(
		[
			'id'         => 0,        // 取得したい投稿の ID
			'show_draft' => 'true',   // ドラフトも表示するとき true
		],
		$atts,
		'my_parts_content'
	);

	$post_id = absint( $atts['id'] );
	if ( ! $post_id ) {
		return '';                 // ID 未指定
	}

	$post = get_post( $post_id );
	if ( ! $post || 'lw_my_parts' !== $post->post_type ) {
		return '';                 // 投稿タイプ違い
	}

	// ドラフトを一般公開したくない場合はここで制御
	if ( 'draft' === $post->post_status && 'true' !== $atts['show_draft'] ) {
		return '';
	}

	// エディタモードを確認
	$editor_mode = get_post_meta( $post_id, '_lw_editor_mode', true );
	
	// 全幅設定を確認
	$full_width = get_post_meta( $post_id, '_lw_full_width', true );
	$is_full_width = ( $full_width === 'on' );
	
	// コードエディタモードの場合
	if ( 'code' === $editor_mode ) {
		$custom_html = get_post_meta( $post_id, '_lw_custom_html', true );
		$custom_css = get_post_meta( $post_id, '_lw_custom_css', true );
		$custom_js = get_post_meta( $post_id, '_lw_custom_js', true ); // ★ JS取得
		
		$output = '';
		
		// CSSがある場合はstyleタグで出力
		if ( ! empty( $custom_css ) ) {
			$output .= '<style>' . $custom_css . '</style>';
		}
		
		// HTMLを出力
		if ( ! empty( $custom_html ) ) {
			// ★ 全幅ONの時だけdivで囲む
			if ( $is_full_width ) {
				$output .= '<div class="lw_width_full_on">' . $custom_html . '</div>';
			} else {
				// ★ 全幅OFFの時はそのまま出力（divで囲まない）
				$output .= $custom_html;
			}
		}
		
		// ★ JavaScriptがある場合は、フッターで出力するために保存
		if ( ! empty( $custom_js ) ) {
			// 重複チェック（同じpost_idのJSは1回だけ出力）
			if ( ! isset( $lw_my_parts_scripts[ $post_id ] ) ) {
				$lw_my_parts_scripts[ $post_id ] = $custom_js;
			}
		}
		
		return $output;
	}
	
	// 通常モード: Gutenberg ブロック等のフィルターも通す
	$content = apply_filters( 'the_content', $post->post_content );
	
	// ★ 通常モードでも全幅ONの時だけdivで囲む
	if ( $is_full_width && ! empty( $content ) ) {
		$content = '<div class="lw_width_full_on">' . $content . '</div>';
	}
	// ★ 全幅OFFの時は $content をそのまま返す（divで囲まない）
	
	return $content;
}
add_shortcode( 'my_parts_content', 'lw_shortcode_my_parts_content' );

/**
 * ★ wp_footerでJavaScriptを</body>直前に出力
 */
add_action( 'wp_footer', 'lw_output_my_parts_scripts', 999 );
function lw_output_my_parts_scripts() {
	global $lw_my_parts_scripts;
	
	// JavaScriptが1つも登録されていない場合は何もしない
	if ( empty( $lw_my_parts_scripts ) || ! is_array( $lw_my_parts_scripts ) ) {
		return;
	}
	
	// 登録されているすべてのJavaScriptを出力
	foreach ( $lw_my_parts_scripts as $post_id => $js_code ) {
		if ( ! empty( $js_code ) ) {
			echo "\n<!-- LW MyParts JS (ID: " . esc_html( $post_id ) . ") -->\n";
			echo '<script>' . "\n";
			// JSコードをそのまま出力（エスケープしない）
			echo $js_code . "\n";
			echo '</script>' . "\n";
		}
	}
}