<?php
if ( !defined( 'ABSPATH' ) ) exit;
// CSSの読み込み
wp_enqueue_style('Lw_setting_form', get_template_directory_uri() . '/functions/lw_setting/style.css', array(), css_version(), 'all');
?>
<div class="none_plugin_message"></div>
<form action="" method="post">
    <div class="Lw_setting_form reset" data-lw_font_set="Noto Sans JP">
        <div class="intro_wrap">
            <h1><span data-lw_font_set="sora">LiteWord</span> クイック初期設定</h1>
            <div class="intro">
                <p>
                    「クリック初期設定」では、LiteWordテーマを使う際に、最初に設定しておきたい基本的な内容をまとめています。この設定を行うことで、サイトのデザインをスムーズに整えることができます。<br>
                    まずは以下の手順に沿って設定を進めてみましょう。
                </p>
            </div>
        </div>
        <dl>
            <dt>データ反映処理</dt>
            <dd>
                <p>下記のボタンをクリックし、説明動画を見ながら<a style="text-decoration: underline;" <?=new_tab()?> href="<?=admin_url()?>/admin.php?page=lw_template_management">データ反映処理</a>を行ってください。</p>
                <a class="link_btn" href="https://youtu.be/A6yBGHkwAVI" <?=new_tab()?>>説明動画はこちら</a>
            </dd>
        </dl>
   <?php
        // 試用期間セクションの表示判定
        if (!lw_is_subscription_active()) { // サブスクリプション契約者でない場合
            $templateSetting = new LwTemplateSetting();
            $trial_setting = $templateSetting->get_template_setting_by_id('trial_period');
            $show_trial_section = false;
            
            if (!$trial_setting) {
                // 初回（trial_periodが存在しない）
                $show_trial_section = true;
            } else {
                // 試用期間の状態を確認
                if ($trial_setting['active_flag'] == 0) {
                    // 試用期間終了後の経過日数を計算
                    $last_timestamp = strtotime($trial_setting['timestamp']);
                    $now = time();
                    $days_elapsed = floor(($now - $last_timestamp) / (60 * 60 * 24));
                    
                    if ($days_elapsed >= 60) {
                        // 60日経過したら再表示
                        $show_trial_section = true;
                    }
                } else {
                    // 試用期間中の場合
                    $days_remaining = lw_get_trial_days_remaining_without_update();
                    if ($days_remaining <= 0) {
                        // 期限切れで、まだactive_flagが1の場合は表示しない
                        $show_trial_section = false;
                    }
                }
            }
            
            if ($show_trial_section):
        ?>
        <dl>
            <dt>無料お試し（14日間）</dt>
            <dd>
                <style>
                    .lw-trial-section {
                        padding: 20px !important;
                        background: linear-gradient(135deg, #f0f9ff 0%, #e6f7ff 100%);
                        border-radius: 10px;
                        margin-bottom: 20px;
                    }
                    .lw-trial-section h3 {
                        color: #3498db;
                        margin: 0 0 15px 0;
                        font-size: 18px;
                    }
                    .lw-trial-features {
                        list-style: none;
                        padding: 0;
                        margin: 15px 0;
                    }
                    .lw-trial-features li {
                        padding: 5px 0;
                        color: #5a6c7d;
                    }
                    .lw-trial-features li:before {
                        content: "✓ ";
                        color: #2ecc71;
                        font-weight: bold;
                        margin-right: 5px;
                    }
                    .lw-trial-start-btn {
                        margin: 20px 0;
                        background: linear-gradient(135deg, #3498db, #2980b9);
                        color: white !important;
                        padding: 12px 30px;
                        border: none;
                        border-radius: 5px;
                        cursor: pointer;
                        font-size: 16px;
                        font-weight: bold;
                        transition: all 0.3s ease;
                        text-decoration: none !important;
                        display: inline-block;
                    }
                    .lw-trial-start-btn:hover {
                        transform: translateY(-2px);
                        box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
                        background: linear-gradient(135deg, #2980b9, #3498db);
                    }
                    .lw-trial-start-btn:disabled {
                        background: #95a5a6;
                        cursor: not-allowed;
                        transform: none;
                    }
                    .lw-trial-note {
                        font-size: 13px;
                        color: #7f8c8d;
                        margin-top: 15px;
                    }
                </style>
                
                <div class="lw-trial-section">
                    <h3>🎉 LiteWordプレミアムを無料でお試し！</h3>
                    <ul class="lw-trial-features">
                        <li>14日間プレミアム機能が利用可能</li>
                        <li>クレジットカード登録不要</li>
                        <li>自動課金なし・安心してお試しできます</li>
                    </ul>
                    
                    <button type="button" class="lw-trial-start-btn" id="lwTrialStartBtn">
                        🚀 今すぐ無料で試してみる
                    </button>
                    
                    <p class="lw-trial-note">
                        ※ボタンをクリックすると、14日間の試用期間が開始されます。<br>
                        ※試用期間中は、設定画面上部に残り日数が表示されます。
                    </p>
                </div>
                
                <script>
                jQuery(document).ready(function($) {
                    $('#lwTrialStartBtn').on('click', function() {
                        const $btn = $(this);
                        
                        if (confirm('14日間の無料試用期間を開始しますか？\n\n✨ 40以上のデザインパーツがすぐに利用可能になります！')) {
                            $btn.prop('disabled', true).text('⏳ 処理中...');
                            
                            $.ajax({
                                url: ajaxurl,
                                type: 'POST',
                                data: {
                                    action: 'lw_activate_trial',
                                    nonce: '<?php echo wp_create_nonce('lw_trial_nonce'); ?>'
                                },
                                success: function(response) {
                                    if (response.success) {
                                        $btn.text('✅ 試用期間を開始しました！');
                                        
                                        // 成功メッセージ
                                        const successMsg = $('<div style="margin-top: 15px; padding: 15px; background: #d4edda; color: #155724; border-radius: 5px; font-weight: bold;">🎊 試用期間が開始されました！ページを再読み込みしています...</div>');
                                        $btn.after(successMsg);
                                        
                                        // 2秒後にページリロード
                                        setTimeout(function() {
                                            location.reload();
                                        }, 2000);
                                    } else {
                                        alert('エラーが発生しました。もう一度お試しください。');
                                        $btn.prop('disabled', false).text('🚀 今すぐ無料で試してみる');
                                    }
                                },
                                error: function() {
                                    alert('通信エラーが発生しました。もう一度お試しください。');
                                    $btn.prop('disabled', false).text('🚀 今すぐ無料で試してみる');
                                }
                            });
                        }
                    });
                });
                </script>
            </dd>
        </dl>
        <?php 
            endif; // $show_trial_section
        } else {
            // サブスクリプション契約者の場合、お礼メッセージを表示
            ?>
            <dl>
                <dt>プレミアム機能</dt>
                <dd>
                    <div style="padding: 15px; background: linear-gradient(135deg, #f5f3ff 0%, #ede7ff 100%); border-radius: 10px;">
                        <p style="color: #9b59b6; margin: 0;">
                            <strong>✨ プレミアムプランをご利用いただきありがとうございます！</strong><br>
                            すべてのデザインパーツがご利用いただけます。
                        </p>
                    </div>
                </dd>
            </dl>
            <?php
        }
        ?>
        <dl>
            <dt>共通カラーの指定</dt>
            <dd>
                <label for="">メインカラー（※見出しの色など、サイトのイメージを決める色）</label>
                <?=Lw_theme_mod_text("color_main","color","#1a72ad")?>
                <label for="">アクセントカラー（※ボタンなど、目立つ部分）</label>
                <?=Lw_theme_mod_text("color_accent","color","#d34a4a")?>
            </dd>
            <dt>共通デフォルトフォント</dt>
            <dd>
                <?=Lw_theme_mod_select("font_body",ctm_font_family_arr(),"gothic")?>
                <p>※日本語を綺麗に表示させるには「Noto Sans JP」がおススメ！</p>
                <input type="submit" value="変更内容を保存する" class="Lw_setting_form_submit">
            </dd>
        </dl>
        <dl>
            <dt>サイトロゴ</dt>
            <dd>
                <h3>ロゴテキスト</h3>
                <?=Lw_opt_text("blogname","text","","logo_text")?>
                <p>※サイトタイトルとなりますのでロゴ画像を利用する場合でも必ずご入力ください</p>
                <br>
                <h3>ロゴ画像</h3>
                <a class="link_btn" href="<?=admin_url()?>customize.php?autofocus[control]=custom_logo" <?=new_tab()?>>画像の場合はこちら</a>
                <p>デフォルトのロゴ画像を設定するには、「ロゴ画像はこちら」と書いてある上記のボタンから設定をお願いいたします。<br>また、svgデータとして設置する場合は、<a href="https://wordpress.org/plugins/svg-support/" <?=new_tab()?>>svgデータを許可するためのプラグイン</a>を導入してください。</p>
                <input type="submit" value="変更内容を保存する" class="Lw_setting_form_submit">
            </dd>
        </dl>
        <dl>
            <dt>ヘッダーパターン</dt>
            <dd>
                <div class="Lw_setting_image_switch">
                    <div class="images_wrap header">
                        <div class="ptn_1 true df">
                            <div class="inner">
                                <img src="<?=get_template_directory_uri()?>/assets/image/lw_header_sample/ptn_1.webp">
                            </div>
                            <a class="link_btn" href="<?=admin_url()?>customize.php?autofocus[control]=header_ptn_1_set_logo_switch" <?=new_tab()?>>このヘッダーの詳細設定はこちら</a>
                        </div>
                        <div class="ptn_2">
                            <div class="inner">
                                <img src="<?=get_template_directory_uri()?>/assets/image/lw_header_sample/ptn_2.webp">
                            </div>
                            <a class="link_btn" href="<?=admin_url()?>customize.php?autofocus[control]=header_ptn_2_set_logo_switch" <?=new_tab()?>>このヘッダーの詳細設定はこちら</a>
                        </div>
                        <div class="ptn_3">
                            <div class="inner">
                                <img src="<?=get_template_directory_uri()?>/assets/image/lw_header_sample/ptn_3.webp">
                            </div>
                            <a class="link_btn" href="<?=admin_url()?>customize.php?autofocus[control]=header_ptn_3_set_logo_switch" <?=new_tab()?>>このヘッダーの詳細設定はこちら</a>
                        </div>
                        <div class="ptn_4">
                            <div class="inner">
                                <img src="<?=get_template_directory_uri()?>/assets/image/lw_header_sample/ptn_4.webp">
                            </div>
                            <a class="link_btn" href="<?=admin_url()?>customize.php?autofocus[control]=header_ptn_4_set_logo_switch" <?=new_tab()?>>このヘッダーの詳細設定はこちら</a>
                        </div>
                        <div class="ptn_5">
                            <div class="inner">
                                <img src="<?=get_template_directory_uri()?>/assets/image/lw_header_sample/ptn_5.webp">
                            </div>
                            <a class="link_btn" href="<?=admin_url()?>customize.php?autofocus[control]=header_ptn_5_set_logo_switch" <?=new_tab()?>>このヘッダーの詳細設定はこちら</a>
                        </div>
                        <div class="ptn_6">
                            <div class="inner">
                                <img src="<?=get_template_directory_uri()?>/assets/image/lw_header_sample/ptn_6.webp">
                            </div>
                            <a class="link_btn" href="<?=admin_url()?>customize.php?autofocus[control]=header_ptn_6_set_logo_switch" <?=new_tab()?>>このヘッダーの詳細設定はこちら</a>
                        </div>
                        <div class="none"></div>
                    </div>
                    <?=Lw_theme_mod_radio("header_set_ptn_df",header_ptn_arr(),"","switch_radio")?>
                </div>
                <input type="submit" value="変更内容を保存する" class="Lw_setting_form_submit">
        </dd>
        </dl>
            <dl>
            <dt>フッターパターン</dt>
            <dd>
                <div class="Lw_setting_image_switch">
                    <div class="images_wrap footer">
                        <!-- ptn_1 -->
                        <div class="ptn_1 true df">
                            <div class="inner">
                                <img src="<?=get_template_directory_uri()?>/assets/image/lw_footer_sample/ptn_1.webp">
                            </div>
                            <a class="link_btn" href="<?=admin_url()?>customize.php?autofocus[control]=footer_ptn_1_set_widget_switch" <?=new_tab()?>>このフッターの詳細設定はこちら</a>
                        </div>
                        <!-- ptn_2 -->
                        <div class="ptn_2">
                            <div class="inner">
                                <img src="<?=get_template_directory_uri()?>/assets/image/lw_footer_sample/ptn_2.webp">
                            </div>
                            <a class="link_btn" href="<?=admin_url()?>customize.php?autofocus[control]=footer_ptn_2_set_widget_switch" <?=new_tab()?>>このフッターの詳細設定はこちら</a>
                        </div>
                        <!-- ptn_3 -->
                        <div class="ptn_3">
                            <div class="inner">
                                <img src="<?=get_template_directory_uri()?>/assets/image/lw_footer_sample/ptn_3.webp">
                            </div>
                            <a class="link_btn" href="<?=admin_url()?>customize.php?autofocus[control]=footer_ptn_3_set_widget_switch" <?=new_tab()?>>このフッターの詳細設定はこちら</a>
                        </div>
                        <!-- ptn_4 -->
                        <div class="ptn_4">
                            <div class="inner">
                                <img src="<?=get_template_directory_uri()?>/assets/image/lw_footer_sample/ptn_4.webp">
                            </div>
                            <a class="link_btn" href="<?=admin_url()?>customize.php?autofocus[control]=footer_ptn_4_set_widget_switch" <?=new_tab()?>>このフッターの詳細設定はこちら</a>
                        </div>
                        <div class="none"></div>
                    </div>
                    <?=Lw_theme_mod_radio("footer_set_ptn_df",footer_ptn_arr(),"","switch_radio")?>
                </div>
                <input type="submit" value="変更内容を保存する" class="Lw_setting_form_submit">
            </dd>
        </dl>
        <!-- <dl>
            <dt>アーカイブページの<br>FVイメージ画像</dt>
            <dd>
                <input type="submit" value="変更内容を保存する" class="Lw_setting_form_submit">
            </dd>
        </dl> -->
    </div>
</form>

<script>
    //ヘッダーなどのイメージの切り替え ------------------------------------------------
    document.querySelectorAll(".Lw_setting_image_switch").forEach(element => {
        const switchRadios = element.querySelectorAll(".switch_radio input[type='radio']"); // ラジオボタンを取得
        const targetDivs = element.querySelectorAll(".images_wrap > div"); // 対象の<div>要素を取得

        // ページ読み込み時の初期設定
        const initializeSwitch = () => {
            const selectedRadio = element.querySelector(".switch_radio input[type='radio']:checked"); // 選択されているラジオボタン
            const selectedValue = selectedRadio ? selectedRadio.value : "";

            // すべてのターゲットから "true" クラスを削除
            targetDivs.forEach(tar => tar.classList.remove("true"));

            if (selectedValue) {
                // 選択されている値に一致する<div>に "true" を付与
                targetDivs.forEach(tar => {
                    if (tar.classList.contains(selectedValue)) {
                        tar.classList.add("true");
                    }
                });
            } else {
                // 未選択の場合は .df クラスに "true" を付与
                targetDivs.forEach(tar => {
                    if (tar.classList.contains("df")) {
                        tar.classList.add("true");
                    }
                });
            }
        };

        // ページ読み込み時に初期化処理を実行
        initializeSwitch();

        // ラジオボタンの変更イベント
        switchRadios.forEach(radio => {
            radio.addEventListener("change", () => {
                const selectedValue = radio.value;

                // すべてのターゲットから "true" クラスを削除
                targetDivs.forEach(tar => tar.classList.remove("true"));

                if (selectedValue) {
                    // 選択されている値に一致する<div>に "true" を付与
                    targetDivs.forEach(tar => {
                        if (tar.classList.contains(selectedValue)) {
                            tar.classList.add("true");
                        }
                    });
                } else {
                    // 未選択の場合は .df クラスに "true" を付与
                    targetDivs.forEach(tar => {
                        if (tar.classList.contains("df")) {
                            tar.classList.add("true");
                        }
                    });
                }
            });
        });
    });
</script>
