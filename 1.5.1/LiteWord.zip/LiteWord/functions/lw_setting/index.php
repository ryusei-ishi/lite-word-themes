<?php
if ( !defined( 'ABSPATH' ) ) exit;
// メニュー追加
add_action('admin_menu', 'lw_setting');
function lw_setting() {
    add_menu_page('Lwクイック設定', 'Lwクイック設定', 'manage_options', 'lw_setting_page', 'lw_setting_page_content', 'dashicons-admin-generic', 24);
}
function lw_setting_page_content() {
    get_template_part('./functions/lw_setting/lw_setting_page_content');
}