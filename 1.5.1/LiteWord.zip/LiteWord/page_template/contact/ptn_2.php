<!-- wp:wdl/paid-block-contact-2 {"descriptionAlignSP":"sp_left"} -->
<div class="wp-block-wdl-paid-block-contact-2 paid-block-contact-2"><div class="this_wrap" style="max-width:800px"><h1 class="title"><span class="main">CONTACT</span><span class="sub">お問合わせフォーム</span></h1><p class="description pc_center sp_left">ご不明な点やご相談がございましたら、下記のお問い合わせフォームよりお気軽にご連絡ください。</p>[lw_mail_form_select id='1']<div class="bg_filter"><div class="bg_filter_inner" style="background-color:#03294C;opacity:0.5"></div><picture><source srcset="" media="(max-width: 800px)"/><source srcset="https://lite-word.com/sample_img/background/6.webp" media="(min-width: 801px)"/><img src="https://lite-word.com/sample_img/background/6.webp" alt="背景画像" style="display:block"/></picture></div></div><style>
					.submit_wrap button   { background-color: #EE3131 !important; }
					.required.is-required { background-color: #da3838 !important; }
				</style></div>
<!-- /wp:wdl/paid-block-contact-2 -->

<!-- wp:paragraph -->
<p class=""></p>
<!-- /wp:paragraph -->