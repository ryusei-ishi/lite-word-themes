<!-- wp:wdl/fv-1 {"backgroundImage":"https://lite-word.com/wp-content/uploads/2025/06/LiteWord_reform1.png","mainTitle":"\u003cspan class=\u0022custom-font-settings custom-font-settings\u0022 data-lw_font_set=\u0022M PLUS Rounded 1c\u0022\u003e\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#3399cc\u0022 class=\u0022has-inline-color\u0022\u003e匠\u003c/mark\u003e\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e和建設\u003c/mark\u003e\u003c/span\u003e","subTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003eまかせて安心、住まいのプロ\u003c/mark\u003e","description":"\u003cstrong\u003e\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003eひとつひとつの施工に、まごころと技術を。\u003c/mark\u003e\u003c/strong\u003e\u003cspan class=\u0022lw-br on_600px\u0022\u003e\u003c/span\u003e\u003cstrong\u003e\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e地域密着で、暮らしの安心を支えます。\u003c/mark\u003e\u003c/strong\u003e","buttonText":"\u003cstrong\u003e\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#3399cc\u0022 class=\u0022has-inline-color\u0022\u003e施工実績を見る\u003c/mark\u003e\u003c/strong\u003e","filterBackgroundColor":"#ffffff","filterOpacity":0.36999999999999999555910790149937383830547332763671875} -->
<div class="wp-block-wdl-fv-1 fv-1 min-h-pc-500px min-h-tb-480px min-h-sp-440px"><h1><span class="main"><span class="custom-font-settings custom-font-settings" data-lw_font_set="M PLUS Rounded 1c"><mark style="background-color:rgba(0, 0, 0, 0);color:#3399cc" class="has-inline-color">匠</mark><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color">和建設</mark></span></span><span class="sub"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color">まかせて安心、住まいのプロ</mark></span></h1><p><strong><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color">ひとつひとつの施工に、まごころと技術を。</mark></strong><span class="lw-br on_600px"></span><strong><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color">地域密着で、暮らしの安心を支えます。</mark></strong></p><a href="#" class="button" style="color:#111;border-color:#000;border-width:0px;border-radius:200px;border-style:solid"><span><strong><mark style="background-color:rgba(0, 0, 0, 0);color:#3399cc" class="has-inline-color">施工実績を見る</mark></strong></span><div class="btn_bg" style="background-color:#fff;opacity:1"></div></a><div class="filter" style="background-color:#ffffff;opacity:0.37"></div><picture class="bg_image"><source srcset="" media="(max-width: 800px)"/><source srcset="https://lite-word.com/wp-content/uploads/2025/06/LiteWord_reform1.png" media="(min-width: 801px)"/><img src="https://lite-word.com/wp-content/uploads/2025/06/LiteWord_reform1.png" alt="背景画像" loading="eager" fetchpriority="high"/></picture></div>
<!-- /wp:wdl/fv-1 -->

<!-- wp:wdl/lw-space-1 {"pcHeight":40,"tbHeight":10,"spHeight":5} -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:40px"></div><div class="tb" style="height:10px"></div><div class="sp" style="height:5px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:wdl/custom-title-2 {"mainTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan data-lw_font_set=\u0022\u0022 class=\u0022custom-font-settings custom-font-settings fs-0-8 lh-2-4\u0022\u003eこのようなお悩みありま\u003c/span\u003e\u003cspan class=\u0022custom-font-settings custom-font-settings fs-0-8\u0022 data-lw_font_set=\u0022\u0022\u003eせんか？\u003c/span\u003e\u003c/mark\u003e","subTitle":"\u003cspan class=\u0022custom-font-settings custom-font-settings fs-1-2 lh-1-9\u0022 data-lw_font_set=\u0022\u0022\u003e\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#3399cc\u0022 class=\u0022has-inline-color\u0022\u003e匠\u003c/mark\u003e\u003c/span\u003e\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan class=\u0022custom-font-settings custom-font-settings fs-1-2 lh-1-9\u0022 data-lw_font_set=\u0022\u0022\u003e和建設が、あなたの不安に丁寧に寄り添います。\u003c/span\u003e\u003c/mark\u003e","textAlignment":"center","className":"lw_pc_only","trigger":"lw_anime lw_scroll","animationClass":"lw-fade-up","animationDurationClass":"dur-1-0s"} -->
<h2 class="wp-block-wdl-custom-title-2 custom-title-2 center lw_pc_only lw_anime lw_scroll lw-fade-up dur-1-0s"><span class="main"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span data-lw_font_set="" class="custom-font-settings custom-font-settings fs-0-8 lh-2-4">このようなお悩みありま</span><span class="custom-font-settings custom-font-settings fs-0-8" data-lw_font_set="">せんか？</span></mark></span><span class="sub"><span class="custom-font-settings custom-font-settings fs-1-2 lh-1-9" data-lw_font_set=""><mark style="background-color:rgba(0, 0, 0, 0);color:#3399cc" class="has-inline-color">匠</mark></span><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span class="custom-font-settings custom-font-settings fs-1-2 lh-1-9" data-lw_font_set="">和建設が、あなたの不安に丁寧に寄り添います。</span></mark></span></h2>
<!-- /wp:wdl/custom-title-2 -->

<!-- wp:wdl/custom-title-2 {"mainTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan data-lw_font_set=\u0022\u0022 class=\u0022custom-font-settings custom-font-settings fs-0-5 ls-0-05\u0022\u003eこのようなお悩みありませんか？\u003c/span\u003e\u003c/mark\u003e","subTitle":"\u003cspan class=\u0022custom-font-settings custom-font-settings fs-1 lh-1 ls-0\u0022 data-lw_font_set=\u0022\u0022\u003e\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#3399cc\u0022 class=\u0022has-inline-color\u0022\u003e匠\u003c/mark\u003e\u003c/span\u003e\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan class=\u0022custom-font-settings custom-font-settings fs-1 lh-1 ls-0\u0022 data-lw_font_set=\u0022\u0022\u003e和建設が、あなたの不安に丁寧に寄り添います。\u003c/span\u003e\u003c/mark\u003e","textAlignment":"center","className":"lw_sp_only","trigger":"lw_anime lw_scroll","animationClass":"lw-fade-up","animationDurationClass":"dur-1-0s"} -->
<h2 class="wp-block-wdl-custom-title-2 custom-title-2 center lw_sp_only lw_anime lw_scroll lw-fade-up dur-1-0s"><span class="main"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span data-lw_font_set="" class="custom-font-settings custom-font-settings fs-0-5 ls-0-05">このようなお悩みありませんか？</span></mark></span><span class="sub"><span class="custom-font-settings custom-font-settings fs-1 lh-1 ls-0" data-lw_font_set=""><mark style="background-color:rgba(0, 0, 0, 0);color:#3399cc" class="has-inline-color">匠</mark></span><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span class="custom-font-settings custom-font-settings fs-1 lh-1 ls-0" data-lw_font_set="">和建設が、あなたの不安に丁寧に寄り添います。</span></mark></span></h2>
<!-- /wp:wdl/custom-title-2 -->

<!-- wp:wdl/paid-block-lw-step-6 {"showNumber":false,"trigger":"lw_anime lw_scroll","animationClass":"lw-fade-up","animationDurationClass":"dur-1-0s"} -->
<div class="wp-block-wdl-paid-block-lw-step-6 paid-block-lw-step-6 lw_anime lw_scroll lw-fade-up dur-1-0s"><ul class="paid-block-lw-step-6__inner"><li class="paid-block-lw-step-6__li" style="border-color:#ccc;border-width:1px;border-style:solid;border-radius:0px"><a href="https://lite-word.com/page-sample-list/sample_page_top_10/" class="link"><div class="image" style="border-radius:0px;border-color:var(--color-main);border-width:0;border-style:none;aspect-ratio:400 / 300"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon6.png" alt="" style="object-fit:cover"/></div><h3 class="ttl font_size_m" data-lw_font_set="" style="font-weight:600;color:;border-bottom-color:var(--color-main);border-bottom-width:2px;border-bottom-style:solid">外壁の傷み</h3><p class="paid-block-lw-step-6__text font_size_m" data-lw_font_set="" style="font-weight:400;color:var(--color-black)">ひび割れや塗装のはがれが目立ってきたけれど、信頼できる業者がわからずそのままにしていませんか？まずはお気軽にご相談ください。</p></a></li><li class="paid-block-lw-step-6__li" style="border-color:#ccc;border-width:1px;border-style:solid;border-radius:0px"><a href="https://lite-word.com/page-sample-list/sample_page_top_10/" class="link"><div class="image" style="border-radius:0px;border-color:var(--color-main);border-width:0;border-style:none;aspect-ratio:400 / 300"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon7.png" alt="" style="object-fit:cover"/></div><h3 class="ttl font_size_m" data-lw_font_set="" style="font-weight:600;color:;border-bottom-color:var(--color-main);border-bottom-width:2px;border-bottom-style:solid">費用が不安</h3><p class="paid-block-lw-step-6__text font_size_m" data-lw_font_set="" style="font-weight:400;color:var(--color-black)">費用が不透明で相談しづらい…そんなお悩みにも、匠和建設では事前にわかりやすくご説明いたします。納得の上で進められるので安心です。</p></a></li><li class="paid-block-lw-step-6__li" style="border-color:#ccc;border-width:1px;border-style:solid;border-radius:0px"><a href="https://lite-word.com/page-sample-list/sample_page_top_10/" class="link"><div class="image" style="border-radius:0px;border-color:var(--color-main);border-width:0;border-style:none;aspect-ratio:400 / 300"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon5.png" alt="" style="object-fit:cover"/></div><h3 class="ttl font_size_m" data-lw_font_set="" style="font-weight:600;color:;border-bottom-color:var(--color-main);border-bottom-width:2px;border-bottom-style:solid">雨漏り対応</h3><p class="paid-block-lw-step-6__text font_size_m" data-lw_font_set="" style="font-weight:400;color:var(--color-black)">突然の雨漏りでお困りの方も安心してください。原因の特定から修理まで、スピーディーに対応いたします。</p></a></li></ul></div>
<!-- /wp:wdl/paid-block-lw-step-6 -->

<!-- wp:wdl/lw-space-1 -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:80px"></div><div class="tb" style="height:64px"></div><div class="sp" style="height:40px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:cover {"url":"https://lite-word.com/wp-content/uploads/2025/06/reform_icon8-1024x633.png","id":4167,"hasParallax":true,"dimRatio":70,"overlayColor":"white","isUserOverlayColor":true,"isDark":false,"sizeSlug":"large","className":"lw_pc_only","layout":{"type":"constrained"},"marginTopPc":"lw_margin_top_pc_0","paddingLeftPc":"lw_padding_left_pc_80","paddingRightPc":"lw_padding_right_pc_80","maxWidthType":"100vw"} -->
<div class="wp-block-cover is-light has-parallax lw_pc_only lw_margin_top_pc_0 lw_padding_left_pc_80 lw_padding_right_pc_80 lw_max_width_100vw" style="min-height:undefined"><div class="wp-block-cover__image-background wp-image-4167 size-large has-parallax" style="background-position:50% 50%;background-image:url(https://lite-word.com/wp-content/uploads/2025/06/reform_icon8-1024x633.png)"></div><span aria-hidden="true" class="wp-block-cover__background has-white-background-color has-background-dim-70 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:wdl/custom-title-2 {"mainTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan data-lw_font_set=\u0022\u0022 class=\u0022custom-font-settings custom-font-settings fs-0-8\u0022\u003e私たちが大切にしていること\u003c/span\u003e\u003c/mark\u003e","subTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan data-lw_font_set=\u0022\u0022 class=\u0022custom-font-settings custom-font-settings fs-1-2 lh-1-9\u0022\u003e大切な住まいに関わることだからこそ、わかりやすく、納得のいくご提案を心がけています。\u003cbr\u003e小さなことでもお気軽にご相談ください。\u003c/span\u003e\u003c/mark\u003e","textAlignment":"center","trigger":"lw_anime lw_scroll","animationClass":"lw-fade-up","animationDurationClass":"dur-1-0s","paddingTopPc":"lw_padding_top_pc_20"} -->
<h2 class="wp-block-wdl-custom-title-2 custom-title-2 center lw_anime lw_scroll lw-fade-up dur-1-0s lw_padding_top_pc_20"><span class="main"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span data-lw_font_set="" class="custom-font-settings custom-font-settings fs-0-8">私たちが大切にしていること</span></mark></span><span class="sub"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span data-lw_font_set="" class="custom-font-settings custom-font-settings fs-1-2 lh-1-9">大切な住まいに関わることだからこそ、わかりやすく、納得のいくご提案を心がけています。<br>小さなことでもお気軽にご相談ください。</span></mark></span></h2>
<!-- /wp:wdl/custom-title-2 -->

<!-- wp:wdl/lw-space-1 {"pcHeight":60,"tbHeight":44,"spHeight":20} -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:60px"></div><div class="tb" style="height:44px"></div><div class="sp" style="height:20px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"className":"is-style-column_bd_color_1","style":{"color":{"background":"#ffffffd1"}},"paddingLeftPc":"lw_padding_left_pc_12","paddingRightPc":"lw_padding_right_pc_12"} -->
<div class="wp-block-column is-style-column_bd_color_1 has-background lw_padding_left_pc_12 lw_padding_right_pc_12" style="background-color:#ffffffd1"><!-- wp:heading {"textAlign":"left","level":3,"className":"is-style-h_03"} -->
<h3 class="wp-block-heading has-text-align-left is-style-h_03">地域密着、迅速対応</h3>
<!-- /wp:heading -->

<!-- wp:image {"id":4219,"sizeSlug":"large","linkDestination":"none","className":"is-style-rounded"} -->
<figure class="wp-block-image size-large is-style-rounded"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon15-1024x633.png" alt="" class="wp-image-4219"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p class="">地元のお客様に長年選ばれてきた信頼と実績。緊急時にも迅速な対応が可能です。</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"is-style-column_bd_color_1","style":{"color":{"background":"#ffffffd1"}},"paddingLeftPc":"lw_padding_left_pc_12","paddingRightPc":"lw_padding_right_pc_12"} -->
<div class="wp-block-column is-style-column_bd_color_1 has-background lw_padding_left_pc_12 lw_padding_right_pc_12" style="background-color:#ffffffd1"><!-- wp:heading {"textAlign":"left","level":3,"className":"is-style-h_03"} -->
<h3 class="wp-block-heading has-text-align-left is-style-h_03">お一人ずつ寄り添う</h3>
<!-- /wp:heading -->

<!-- wp:image {"id":4220,"sizeSlug":"large","linkDestination":"none","className":"is-style-rounded"} -->
<figure class="wp-block-image size-large is-style-rounded"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon14-1024x633.png" alt="" class="wp-image-4220"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p class="">しっかりとヒアリングし、お客様のご希望・ご予算に合わせた最適なプランをご提案します。</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"is-style-column_bd_color_1","style":{"color":{"background":"#ffffffd1"}},"paddingLeftPc":"lw_padding_left_pc_12","paddingRightPc":"lw_padding_right_pc_12"} -->
<div class="wp-block-column is-style-column_bd_color_1 has-background lw_padding_left_pc_12 lw_padding_right_pc_12" style="background-color:#ffffffd1"><!-- wp:heading {"textAlign":"left","level":3,"className":"is-style-h_03"} -->
<h3 class="wp-block-heading has-text-align-left is-style-h_03">確かな職人技</h3>
<!-- /wp:heading -->

<!-- wp:image {"id":4221,"sizeSlug":"large","linkDestination":"none","className":"is-style-rounded"} -->
<figure class="wp-block-image size-large is-style-rounded"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon13-1024x633.png" alt="" class="wp-image-4221"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p class="">経験豊富な職人が、一つひとつ丁寧に施工。仕上がりの美しさと耐久性を大切にしています。 </p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:wdl/lw-space-1 -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:80px"></div><div class="tb" style="height:64px"></div><div class="sp" style="height:40px"></div></div>
<!-- /wp:wdl/lw-space-1 --></div></div>
<!-- /wp:cover -->

<!-- wp:cover {"url":"https://lite-word.com/wp-content/uploads/2025/06/reform_icon8-1024x633.png","id":4167,"hasParallax":true,"dimRatio":70,"overlayColor":"white","isUserOverlayColor":true,"isDark":false,"sizeSlug":"large","className":"lw_sp_only","layout":{"type":"constrained"},"marginTopPc":"lw_margin_top_pc_0","maxWidthType":"100vw"} -->
<div class="wp-block-cover is-light has-parallax lw_sp_only lw_margin_top_pc_0 lw_max_width_100vw" style="min-height:undefined"><div class="wp-block-cover__image-background wp-image-4167 size-large has-parallax" style="background-position:50% 50%;background-image:url(https://lite-word.com/wp-content/uploads/2025/06/reform_icon8-1024x633.png)"></div><span aria-hidden="true" class="wp-block-cover__background has-white-background-color has-background-dim-70 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:wdl/custom-title-2 {"mainTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan class=\u0022custom-font-settings custom-font-settings fs-0-5 ls-0-05\u0022 data-lw_font_set=\u0022\u0022\u003e私たちが大切にしていること\u003c/span\u003e\u003c/mark\u003e","subTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan class=\u0022custom-font-settings custom-font-settings fs-1 lh-1 ls-0\u0022 data-lw_font_set=\u0022\u0022\u003e大切な住まいに関わることだからこそ、わかりやすく、\u003c/span\u003e\u003c/mark\u003e\u003cbr\u003e\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan class=\u0022custom-font-settings custom-font-settings fs-1 lh-1 ls-0\u0022 data-lw_font_set=\u0022\u0022\u003e納得のいくご提案を心がけています。\u003c/span\u003e\u003c/mark\u003e","className":"lw_sp_only","trigger":"lw_anime lw_scroll","animationClass":"lw-fade-up","animationDurationClass":"dur-1-0s"} -->
<h2 class="wp-block-wdl-custom-title-2 custom-title-2 left lw_sp_only lw_anime lw_scroll lw-fade-up dur-1-0s"><span class="main"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span class="custom-font-settings custom-font-settings fs-0-5 ls-0-05" data-lw_font_set="">私たちが大切にしていること</span></mark></span><span class="sub"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span class="custom-font-settings custom-font-settings fs-1 lh-1 ls-0" data-lw_font_set="">大切な住まいに関わることだからこそ、わかりやすく、</span></mark><br><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span class="custom-font-settings custom-font-settings fs-1 lh-1 ls-0" data-lw_font_set="">納得のいくご提案を心がけています。</span></mark></span></h2>
<!-- /wp:wdl/custom-title-2 -->

<!-- wp:wdl/lw-space-1 {"pcHeight":60,"tbHeight":44,"spHeight":20} -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:60px"></div><div class="tb" style="height:44px"></div><div class="sp" style="height:20px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"className":"is-style-column_bd_color_1","style":{"color":{"background":"#ffffffd1"}},"paddingLeftPc":"lw_padding_left_pc_12","paddingRightPc":"lw_padding_right_pc_12"} -->
<div class="wp-block-column is-style-column_bd_color_1 has-background lw_padding_left_pc_12 lw_padding_right_pc_12" style="background-color:#ffffffd1"><!-- wp:heading {"textAlign":"left","level":3,"className":"is-style-h_03"} -->
<h3 class="wp-block-heading has-text-align-left is-style-h_03">地域密着、迅速対応</h3>
<!-- /wp:heading -->

<!-- wp:image {"id":4219,"sizeSlug":"large","linkDestination":"none","className":"is-style-rounded"} -->
<figure class="wp-block-image size-large is-style-rounded"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon15-1024x633.png" alt="" class="wp-image-4219"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p class="">地元のお客様に長年選ばれてきた信頼と実績。緊急時にも迅速な対応が可能です。</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"is-style-column_bd_color_1","style":{"color":{"background":"#ffffffd1"}},"paddingLeftPc":"lw_padding_left_pc_12","paddingRightPc":"lw_padding_right_pc_12"} -->
<div class="wp-block-column is-style-column_bd_color_1 has-background lw_padding_left_pc_12 lw_padding_right_pc_12" style="background-color:#ffffffd1"><!-- wp:heading {"textAlign":"left","level":3,"className":"is-style-h_03"} -->
<h3 class="wp-block-heading has-text-align-left is-style-h_03">お一人ずつ寄り添う</h3>
<!-- /wp:heading -->

<!-- wp:image {"id":4220,"sizeSlug":"large","linkDestination":"none","className":"is-style-rounded"} -->
<figure class="wp-block-image size-large is-style-rounded"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon14-1024x633.png" alt="" class="wp-image-4220"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p class="">しっかりとヒアリングし、お客様のご希望・ご予算に合わせた最適なプランをご提案します。</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"is-style-column_bd_color_1","style":{"color":{"background":"#ffffffd1"}},"paddingLeftPc":"lw_padding_left_pc_12","paddingRightPc":"lw_padding_right_pc_12"} -->
<div class="wp-block-column is-style-column_bd_color_1 has-background lw_padding_left_pc_12 lw_padding_right_pc_12" style="background-color:#ffffffd1"><!-- wp:heading {"textAlign":"left","level":3,"className":"is-style-h_03"} -->
<h3 class="wp-block-heading has-text-align-left is-style-h_03">確かな職人技</h3>
<!-- /wp:heading -->

<!-- wp:image {"id":4221,"sizeSlug":"large","linkDestination":"none","className":"is-style-rounded"} -->
<figure class="wp-block-image size-large is-style-rounded"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon13-1024x633.png" alt="" class="wp-image-4221"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p class="">経験豊富な職人が、一つひとつ丁寧に施工。仕上がりの美しさと耐久性を大切にしています。 </p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:wdl/lw-space-1 -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:80px"></div><div class="tb" style="height:64px"></div><div class="sp" style="height:40px"></div></div>
<!-- /wp:wdl/lw-space-1 --></div></div>
<!-- /wp:cover -->

<!-- wp:wdl/lw-space-1 {"pcHeight":40,"tbHeight":10,"spHeight":0} -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:40px"></div><div class="tb" style="height:10px"></div><div class="sp" style="height:0px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:wdl/custom-title-2 {"mainTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan data-lw_font_set=\u0022\u0022 class=\u0022custom-font-settings custom-font-settings fs-0-8\u0022\u003e施工実績のご紹介\u003c/span\u003e\u003c/mark\u003e","subTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan data-lw_font_set=\u0022\u0022 class=\u0022custom-font-settings custom-font-settings fs-1-2\u0022\u003e豊富な施工実績の中から、お客様のご要望に合わせた事例をご紹介しています。\u003c/span\u003e\u003c/mark\u003e","textAlignment":"center","className":"lw_pc_only","trigger":"lw_anime lw_scroll","animationClass":"lw-fade-up","animationDurationClass":"dur-1-0s"} -->
<h2 class="wp-block-wdl-custom-title-2 custom-title-2 center lw_pc_only lw_anime lw_scroll lw-fade-up dur-1-0s"><span class="main"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span data-lw_font_set="" class="custom-font-settings custom-font-settings fs-0-8">施工実績のご紹介</span></mark></span><span class="sub"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span data-lw_font_set="" class="custom-font-settings custom-font-settings fs-1-2">豊富な施工実績の中から、お客様のご要望に合わせた事例をご紹介しています。</span></mark></span></h2>
<!-- /wp:wdl/custom-title-2 -->

<!-- wp:wdl/custom-title-2 {"mainTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan class=\u0022custom-font-settings custom-font-settings fs-0-5 ls-0-05\u0022 data-lw_font_set=\u0022\u0022\u003e施工実績のご紹介\u003c/span\u003e\u003c/mark\u003e","subTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan class=\u0022custom-font-settings custom-font-settings fs-1 lh-1 ls-0\u0022 data-lw_font_set=\u0022\u0022\u003e豊富な施工実績の中から、お客様のご要望に合わせた事例をご紹介しています。\u003c/span\u003e\u003c/mark\u003e","className":"lw_sp_only","trigger":"lw_anime lw_scroll","animationClass":"lw-fade-up","animationDurationClass":"dur-1-0s"} -->
<h2 class="wp-block-wdl-custom-title-2 custom-title-2 left lw_sp_only lw_anime lw_scroll lw-fade-up dur-1-0s"><span class="main"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span class="custom-font-settings custom-font-settings fs-0-5 ls-0-05" data-lw_font_set="">施工実績のご紹介</span></mark></span><span class="sub"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span class="custom-font-settings custom-font-settings fs-1 lh-1 ls-0" data-lw_font_set="">豊富な施工実績の中から、お客様のご要望に合わせた事例をご紹介しています。</span></mark></span></h2>
<!-- /wp:wdl/custom-title-2 -->

<!-- wp:wdl/lw-space-1 {"pcHeight":50,"tbHeight":34,"spHeight":10} -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:50px"></div><div class="tb" style="height:34px"></div><div class="sp" style="height:10px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:wdl/paid-block-custom-title-8 {"subTitle":"事例１","mainTitle":"\u003cspan class=\u0022custom-font-settings custom-font-settings\u0022 data-lw_font_set=\u0022\u0022\u003e水漏れ被害から再生。清潔感あふれる洗面所リフォーム面所に\u003c/span\u003e","className":"lw_pc_only"} -->
<div class="wp-block-wdl-paid-block-custom-title-8 paid-block-custom-title-8 size_m  position_left lw_pc_only"><h2 class="ttl"><span class="sub" style="color:var(--color-main)">事例１</span><span class="main"><span class="custom-font-settings custom-font-settings" data-lw_font_set="">水漏れ被害から再生。清潔感あふれる洗面所リフォーム面所に</span></span><span class="border_wrap"><span class="border_inner" style="border-radius:10px"><span class="border left" style="background-color:var(--color-main);opacity:1"></span><span class="border right" style="background-color:var(--color-main);opacity:0.2"></span></span></span></h2></div>
<!-- /wp:wdl/paid-block-custom-title-8 -->

<!-- wp:wdl/paid-block-custom-title-8 {"subTitle":"事例１","mainTitle":"\u003cspan data-lw_font_set=\u0022\u0022 class=\u0022custom-font-settings custom-font-settings fs-0-8\u0022\u003e水漏れ被害から再生。\u003cbr\u003e清潔感あふれる洗面所リフォーム面所に\u003c/span\u003e","className":"lw_sp_only"} -->
<div class="wp-block-wdl-paid-block-custom-title-8 paid-block-custom-title-8 size_m  position_left lw_sp_only"><h2 class="ttl"><span class="sub" style="color:var(--color-main)">事例１</span><span class="main"><span data-lw_font_set="" class="custom-font-settings custom-font-settings fs-0-8">水漏れ被害から再生。<br>清潔感あふれる洗面所リフォーム面所に</span></span><span class="border_wrap"><span class="border_inner" style="border-radius:10px"><span class="border left" style="background-color:var(--color-main);opacity:1"></span><span class="border right" style="background-color:var(--color-main);opacity:0.2"></span></span></span></h2></div>
<!-- /wp:wdl/paid-block-custom-title-8 -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:wdl/paid-block-before-after-1 {"beforeImageUrl":"https://lite-word.com/wp-content/uploads/2025/06/reform_icon9.png","afterImageUrl":"https://lite-word.com/wp-content/uploads/2025/06/reform_icon10.png","beforeTextBgColor":"#4a4949","afterTextBgColor":"#3399cc","arrowBgColor":"#3399cc"} -->
<div class="wp-block-wdl-paid-block-before-after-1 paid-block-before-after-1"><div class="this_wrap" style="max-width:800px"><div class="image " style="aspect-ratio:800 / 800"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon9.png" alt=""/><div class="text" style="background-color:#4a4949" data-lw_font_set="Montserrat">Before</div></div><div class="arrow-right" style="border-left:20px solid #3399cc"></div><div class="image " style="aspect-ratio:800 / 800"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon10.png" alt=""/><div class="text" style="background-color:#3399cc" data-lw_font_set="Montserrat">After</div></div></div></div>
<!-- /wp:wdl/paid-block-before-after-1 --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:table {"hasFixedLayout":false} -->
<figure class="wp-block-table"><table><tbody><tr><td>施工内容</td><td>・壁紙補修<br>・洗面所リフォーム</td></tr><tr><td>エリア</td><td>○○市○○町</td></tr><tr><td>工期</td><td>約3日間</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph -->
<p class="">「水漏れにより剥がれてしまった壁紙の補修をご依頼いただきました。防水処理を施したうえで、デザイン性の高い壁紙に張り替え、清潔感と温かみのある洗面空間に仕上げました。」</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:wdl/lw-space-1 {"pcHeight":60,"tbHeight":44,"spHeight":20} -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:60px"></div><div class="tb" style="height:44px"></div><div class="sp" style="height:20px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:wdl/paid-block-custom-title-8 {"subTitle":"事例2","mainTitle":"\u003cspan class=\u0022custom-font-settings custom-font-settings\u0022 data-lw_font_set=\u0022\u0022\u003e壁紙リフォームで実現。開放感ある上質な暮らしへ\u003c/span\u003e","className":"lw_pc_only"} -->
<div class="wp-block-wdl-paid-block-custom-title-8 paid-block-custom-title-8 size_m  position_left lw_pc_only"><h2 class="ttl"><span class="sub" style="color:var(--color-main)">事例2</span><span class="main"><span class="custom-font-settings custom-font-settings" data-lw_font_set="">壁紙リフォームで実現。開放感ある上質な暮らしへ</span></span><span class="border_wrap"><span class="border_inner" style="border-radius:10px"><span class="border left" style="background-color:var(--color-main);opacity:1"></span><span class="border right" style="background-color:var(--color-main);opacity:0.2"></span></span></span></h2></div>
<!-- /wp:wdl/paid-block-custom-title-8 -->

<!-- wp:wdl/paid-block-custom-title-8 {"subTitle":"事例2","mainTitle":"\u003cspan class=\u0022custom-font-settings custom-font-settings fs-0-8\u0022 data-lw_font_set=\u0022\u0022\u003e壁紙リフォームで実現。\u003cbr\u003e開放感のある上質な暮らしへ\u003c/span\u003e","className":"lw_sp_only"} -->
<div class="wp-block-wdl-paid-block-custom-title-8 paid-block-custom-title-8 size_m  position_left lw_sp_only"><h2 class="ttl"><span class="sub" style="color:var(--color-main)">事例2</span><span class="main"><span class="custom-font-settings custom-font-settings fs-0-8" data-lw_font_set="">壁紙リフォームで実現。<br>開放感のある上質な暮らしへ</span></span><span class="border_wrap"><span class="border_inner" style="border-radius:10px"><span class="border left" style="background-color:var(--color-main);opacity:1"></span><span class="border right" style="background-color:var(--color-main);opacity:0.2"></span></span></span></h2></div>
<!-- /wp:wdl/paid-block-custom-title-8 -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:wdl/paid-block-before-after-1 {"beforeImageUrl":"https://lite-word.com/wp-content/uploads/2025/06/reform_icon11.png","afterImageUrl":"https://lite-word.com/wp-content/uploads/2025/06/reform_icon12.png","beforeTextBgColor":"#4a4949","afterTextBgColor":"#3399cc","arrowBgColor":"#3399cc"} -->
<div class="wp-block-wdl-paid-block-before-after-1 paid-block-before-after-1"><div class="this_wrap" style="max-width:800px"><div class="image " style="aspect-ratio:800 / 800"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon11.png" alt=""/><div class="text" style="background-color:#4a4949" data-lw_font_set="Montserrat">Before</div></div><div class="arrow-right" style="border-left:20px solid #3399cc"></div><div class="image " style="aspect-ratio:800 / 800"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon12.png" alt=""/><div class="text" style="background-color:#3399cc" data-lw_font_set="Montserrat">After</div></div></div></div>
<!-- /wp:wdl/paid-block-before-after-1 --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:table {"hasFixedLayout":false} -->
<figure class="wp-block-table"><table><tbody><tr><td>施工内容</td><td>・室内壁紙全張替え<br>・内装リフレッシュ</td></tr><tr><td>エリア</td><td>△△市△△町</td></tr><tr><td>工期</td><td>約5日間</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph -->
<p class="">「長年使用していた壁紙の汚れと色あせが気になるとのことで、全室の壁紙を張り替えました。明るい色味と質感を選ぶことで、お部屋全体が広く感じられる、洗練された印象に生まれ変わりました。」</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:wdl/lw-space-1 {"pcHeight":40,"tbHeight":32,"spHeight":20} -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:40px"></div><div class="tb" style="height:32px"></div><div class="sp" style="height:20px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:wdl/paid-block-lw-button-5 {"blockId":"lwbtn-1dbb023e","fontWeight":"500","buttons":[{"enabled":true,"btnText":"LINE 申込・相談","subText":"24時間受付","bgColor":"#00b900","textColor":"#ffffff","btnUrl":"","openNewTab":false,"selectedIcon":"\u003csvg xmlns=\u0022http://www.w3.org/2000/svg\u0022 viewBox=\u00220 0 512 512\u0022\u003e\u003c!\u002d\u002d!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.\u002d\u002d\u003e\u003cpath d=\u0022M311 196.8v81.3c0 2.1-1.6 3.7-3.7 3.7h-13c-1.3 0-2.4-.7-3-1.5l-37.3-50.3v48.2c0 2.1-1.6 3.7-3.7 3.7h-13c-2.1 0-3.7-1.6-3.7-3.7V196.9c0-2.1 1.6-3.7 3.7-3.7h12.9c1.1 0 2.4 .6 3 1.6l37.3 50.3V196.9c0-2.1 1.6-3.7 3.7-3.7h13c2.1-.1 3.8 1.6 3.8 3.5zm-93.7-3.7h-13c-2.1 0-3.7 1.6-3.7 3.7v81.3c0 2.1 1.6 3.7 3.7 3.7h13c2.1 0 3.7-1.6 3.7-3.7V196.8c0-1.9-1.6-3.7-3.7-3.7zm-31.4 68.1H150.3V196.8c0-2.1-1.6-3.7-3.7-3.7h-13c-2.1 0-3.7 1.6-3.7 3.7v81.3c0 1 .3 1.8 1 2.5c.7 .6 1.5 1 2.5 1h52.2c2.1 0 3.7-1.6 3.7-3.7v-13c0-1.9-1.6-3.7-3.5-3.7zm193.7-68.1H327.3c-1.9 0-3.7 1.6-3.7 3.7v81.3c0 1.9 1.6 3.7 3.7 3.7h52.2c2.1 0 3.7-1.6 3.7-3.7V265c0-2.1-1.6-3.7-3.7-3.7H344V247.7h35.5c2.1 0 3.7-1.6 3.7-3.7V230.9c0-2.1-1.6-3.7-3.7-3.7H344V213.5h35.5c2.1 0 3.7-1.6 3.7-3.7v-13c-.1-1.9-1.7-3.7-3.7-3.7zM512 93.4V419.4c-.1 51.2-42.1 92.7-93.4 92.6H92.6C41.4 511.9-.1 469.8 0 418.6V92.6C.1 41.4 42.2-.1 93.4 0H419.4c51.2 .1 92.7 42.1 92.6 93.4zM441.6 233.5c0-83.4-83.7-151.3-186.4-151.3s-186.4 67.9-186.4 151.3c0 74.7 66.3 137.4 155.9 149.3c21.8 4.7 19.3 12.7 14.4 42.1c-.8 4.7-3.8 18.4 16.1 10.1s107.3-63.2 146.5-108.2c27-29.7 39.9-59.8 39.9-93.1z\u0022/\u003e\u003c/svg\u003e","iconVisible":true,"iconWidth":44,"iconColor":"#ffffff","outerBorderWidth":0,"outerBorderColor":"var(\u002d\u002dcolor-main)","borderWidth":1,"borderColor":"#ffffff"},{"enabled":true,"btnText":"\u003cspan data-lw_font_set=\u0022Murecho\u0022 class=\u0022custom-font-settings custom-font-settings fs-1-1\u0022\u003e03-0000-0000\u003c/span\u003e","subText":"受付時間 10:00～17:00","bgColor":"#297bc3","textColor":"#ffffff","btnUrl":"","openNewTab":false,"selectedIcon":"\u003csvg xmlns=\u0022http://www.w3.org/2000/svg\u0022 viewBox=\u00220 0 512 512\u0022\u003e\u003cpath d=\u0022M280 0C408.1 0 512 103.9 512 232c0 13.3-10.7 24-24 24s-24-10.7-24-24c0-101.6-82.4-184-184-184c-13.3 0-24-10.7-24-24s10.7-24 24-24zm8 192a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm-32-72c0-13.3 10.7-24 24-24c75.1 0 136 60.9 136 136c0 13.3-10.7 24-24 24s-24-10.7-24-24c0-48.6-39.4-88-88-88c-13.3 0-24-10.7-24-24zM117.5 1.4c19.4-5.3 39.7 4.6 47.4 23.2l40 96c6.8 16.3 2.1 35.2-11.6 46.3L144 207.3c33.3 70.4 90.3 127.4 160.7 160.7L345 318.7c11.2-13.7 30-18.4 46.3-11.6l96 40c18.6 7.7 28.5 28 23.2 47.4l-24 88C481.8 499.9 466 512 448 512C200.6 512 0 311.4 0 64C0 46 12.1 30.2 29.5 25.4l88-24z\u0022/\u003e\u003c/svg\u003e","iconVisible":true,"iconWidth":34,"iconColor":"#ffffff","outerBorderWidth":0,"outerBorderColor":"var(\u002d\u002dcolor-main)","borderWidth":1,"borderColor":"#ffffff"},{"enabled":true,"btnText":"資料請求","subText":"PDFデータダウンロード","bgColor":"#f17594","textColor":"#ffffff","btnUrl":"","openNewTab":false,"selectedIcon":"\u003csvg xmlns=\u0022http://www.w3.org/2000/svg\u0022 width=\u002230.272\u0022 height=\u002237.206\u0022 viewBox=\u00220 0 30.272 37.206\u0022\u003e\u003cg  transform=\u0022translate(-47.706)\u0022\u003e\u003cpath data-name=\u0022パス 17\u0022 d=\u0022M71.738,0H58.418l-.677.677-9.358,9.359-.677.677V30.964a6.249,6.249,0,0,0,6.242,6.242h17.79a6.249,6.249,0,0,0,6.241-6.242V6.242A6.248,6.248,0,0,0,71.738,0Zm3.93,30.964a3.93,3.93,0,0,1-3.93,3.931H53.948a3.93,3.93,0,0,1-3.931-3.931V11.67H56.1a3.276,3.276,0,0,0,3.276-3.275V2.311H71.738a3.93,3.93,0,0,1,3.93,3.931Z\u0022 /\u003e\u003cpath data-name=\u0022パス 18\u0022 d=\u0022M137.436,252.785h-2.073a.593.593,0,0,0-.631.641v5.36a.726.726,0,1,0,1.45,0v-1.628a.053.053,0,0,1,.06-.059h1.194a2.164,2.164,0,1,0,0-4.313Zm-.089,3.06h-1.105a.053.053,0,0,1-.06-.059V254.1a.053.053,0,0,1,.06-.059h1.105a.906.906,0,1,1,0,1.806Z\u0022 transform=\u0022translate(-80.702 -234.416)\u0022 /\u003e\u003cpath data-name=\u0022パス 19\u0022 d=\u0022M221.857,252.785h-1.589a.593.593,0,0,0-.631.641v5.439a.585.585,0,0,0,.631.632h1.589c1.431,0,2.32-.454,2.675-1.55a8.344,8.344,0,0,0,0-3.613C224.177,253.239,223.288,252.785,221.857,252.785Zm1.284,4.659c-.168.533-.651.76-1.323.76h-.671a.053.053,0,0,1-.06-.059v-4.007a.053.053,0,0,1,.06-.059h.671c.672,0,1.155.227,1.323.76a7.268,7.268,0,0,1,0,2.606Z\u0022 transform=\u0022translate(-159.438 -234.416)\u0022 /\u003e\u003cpath data-name=\u0022パス 20\u0022 d=\u0022M311.544,252.785h-3.256a.594.594,0,0,0-.632.641v5.36a.727.727,0,1,0,1.451,0v-1.915a.052.052,0,0,1,.059-.059h1.9a.624.624,0,1,0,0-1.244h-1.9a.052.052,0,0,1-.059-.059V254.1a.052.052,0,0,1,.059-.059h2.379a.628.628,0,1,0,0-1.253Z\u0022 transform=\u0022translate(-241.06 -234.416)\u0022 /\u003e\u003c/g\u003e\u003c/svg\u003e","iconVisible":true,"iconWidth":34,"iconColor":"#ffffff","outerBorderWidth":0,"outerBorderColor":"var(\u002d\u002dcolor-main)","borderWidth":1,"borderColor":"#ffffff"}]} -->
<div class="wp-block-wdl-paid-block-lw-button-5 paid-block-lw-button-5 position_center" style="column-gap:12px;row-gap:12px"><div id="lwbtn-1dbb023e-1" class="a_inner" style="border:0px solid var(--color-main);border-radius:12px"><a class="a" href="#" style="color:#ffffff;font-weight:500" data-lw_font_set=""><span class="icon-svg"><span class="icon-svg-inner" style="width:44%"><svg style="fill:#ffffff;color:#ffffff;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M311 196.8v81.3c0 2.1-1.6 3.7-3.7 3.7h-13c-1.3 0-2.4-.7-3-1.5l-37.3-50.3v48.2c0 2.1-1.6 3.7-3.7 3.7h-13c-2.1 0-3.7-1.6-3.7-3.7V196.9c0-2.1 1.6-3.7 3.7-3.7h12.9c1.1 0 2.4 .6 3 1.6l37.3 50.3V196.9c0-2.1 1.6-3.7 3.7-3.7h13c2.1-.1 3.8 1.6 3.8 3.5zm-93.7-3.7h-13c-2.1 0-3.7 1.6-3.7 3.7v81.3c0 2.1 1.6 3.7 3.7 3.7h13c2.1 0 3.7-1.6 3.7-3.7V196.8c0-1.9-1.6-3.7-3.7-3.7zm-31.4 68.1H150.3V196.8c0-2.1-1.6-3.7-3.7-3.7h-13c-2.1 0-3.7 1.6-3.7 3.7v81.3c0 1 .3 1.8 1 2.5c.7 .6 1.5 1 2.5 1h52.2c2.1 0 3.7-1.6 3.7-3.7v-13c0-1.9-1.6-3.7-3.5-3.7zm193.7-68.1H327.3c-1.9 0-3.7 1.6-3.7 3.7v81.3c0 1.9 1.6 3.7 3.7 3.7h52.2c2.1 0 3.7-1.6 3.7-3.7V265c0-2.1-1.6-3.7-3.7-3.7H344V247.7h35.5c2.1 0 3.7-1.6 3.7-3.7V230.9c0-2.1-1.6-3.7-3.7-3.7H344V213.5h35.5c2.1 0 3.7-1.6 3.7-3.7v-13c-.1-1.9-1.7-3.7-3.7-3.7zM512 93.4V419.4c-.1 51.2-42.1 92.7-93.4 92.6H92.6C41.4 511.9-.1 469.8 0 418.6V92.6C.1 41.4 42.2-.1 93.4 0H419.4c51.2 .1 92.7 42.1 92.6 93.4zM441.6 233.5c0-83.4-83.7-151.3-186.4-151.3s-186.4 67.9-186.4 151.3c0 74.7 66.3 137.4 155.9 149.3c21.8 4.7 19.3 12.7 14.4 42.1c-.8 4.7-3.8 18.4 16.1 10.1s107.3-63.2 146.5-108.2c27-29.7 39.9-59.8 39.9-93.1z"/></svg></span></span><span class="text_in"><span class="text_main">LINE 申込・相談</span><span class="text_sub">24時間受付</span></span></a><div class="a_background" style="background:#00b900"></div><div class="a_in_border" style="border:1px solid #ffffff;border-radius:12px"></div></div><div id="lwbtn-1dbb023e-2" class="a_inner" style="border:0px solid var(--color-main);border-radius:12px"><a class="a" href="#" style="color:#ffffff;font-weight:500" data-lw_font_set=""><span class="icon-svg"><span class="icon-svg-inner" style="width:34%"><svg style="fill:#ffffff;color:#ffffff;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M280 0C408.1 0 512 103.9 512 232c0 13.3-10.7 24-24 24s-24-10.7-24-24c0-101.6-82.4-184-184-184c-13.3 0-24-10.7-24-24s10.7-24 24-24zm8 192a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm-32-72c0-13.3 10.7-24 24-24c75.1 0 136 60.9 136 136c0 13.3-10.7 24-24 24s-24-10.7-24-24c0-48.6-39.4-88-88-88c-13.3 0-24-10.7-24-24zM117.5 1.4c19.4-5.3 39.7 4.6 47.4 23.2l40 96c6.8 16.3 2.1 35.2-11.6 46.3L144 207.3c33.3 70.4 90.3 127.4 160.7 160.7L345 318.7c11.2-13.7 30-18.4 46.3-11.6l96 40c18.6 7.7 28.5 28 23.2 47.4l-24 88C481.8 499.9 466 512 448 512C200.6 512 0 311.4 0 64C0 46 12.1 30.2 29.5 25.4l88-24z"/></svg></span></span><span class="text_in"><span class="text_main"><span data-lw_font_set="Murecho" class="custom-font-settings custom-font-settings fs-1-1">03-0000-0000</span></span><span class="text_sub">受付時間 10:00～17:00</span></span></a><div class="a_background" style="background:#297bc3"></div><div class="a_in_border" style="border:1px solid #ffffff;border-radius:12px"></div></div><div id="lwbtn-1dbb023e-3" class="a_inner" style="border:0px solid var(--color-main);border-radius:12px"><a class="a" href="#" style="color:#ffffff;font-weight:500" data-lw_font_set=""><span class="icon-svg"><span class="icon-svg-inner" style="width:34%"><svg style="fill:#ffffff;color:#ffffff;" xmlns="http://www.w3.org/2000/svg" width="30.272" height="37.206" viewBox="0 0 30.272 37.206"><g  transform="translate(-47.706)"><path data-name="パス 17" d="M71.738,0H58.418l-.677.677-9.358,9.359-.677.677V30.964a6.249,6.249,0,0,0,6.242,6.242h17.79a6.249,6.249,0,0,0,6.241-6.242V6.242A6.248,6.248,0,0,0,71.738,0Zm3.93,30.964a3.93,3.93,0,0,1-3.93,3.931H53.948a3.93,3.93,0,0,1-3.931-3.931V11.67H56.1a3.276,3.276,0,0,0,3.276-3.275V2.311H71.738a3.93,3.93,0,0,1,3.93,3.931Z" /><path data-name="パス 18" d="M137.436,252.785h-2.073a.593.593,0,0,0-.631.641v5.36a.726.726,0,1,0,1.45,0v-1.628a.053.053,0,0,1,.06-.059h1.194a2.164,2.164,0,1,0,0-4.313Zm-.089,3.06h-1.105a.053.053,0,0,1-.06-.059V254.1a.053.053,0,0,1,.06-.059h1.105a.906.906,0,1,1,0,1.806Z" transform="translate(-80.702 -234.416)" /><path data-name="パス 19" d="M221.857,252.785h-1.589a.593.593,0,0,0-.631.641v5.439a.585.585,0,0,0,.631.632h1.589c1.431,0,2.32-.454,2.675-1.55a8.344,8.344,0,0,0,0-3.613C224.177,253.239,223.288,252.785,221.857,252.785Zm1.284,4.659c-.168.533-.651.76-1.323.76h-.671a.053.053,0,0,1-.06-.059v-4.007a.053.053,0,0,1,.06-.059h.671c.672,0,1.155.227,1.323.76a7.268,7.268,0,0,1,0,2.606Z" transform="translate(-159.438 -234.416)" /><path data-name="パス 20" d="M311.544,252.785h-3.256a.594.594,0,0,0-.632.641v5.36a.727.727,0,1,0,1.451,0v-1.915a.052.052,0,0,1,.059-.059h1.9a.624.624,0,1,0,0-1.244h-1.9a.052.052,0,0,1-.059-.059V254.1a.052.052,0,0,1,.059-.059h2.379a.628.628,0,1,0,0-1.253Z" transform="translate(-241.06 -234.416)" /></g></svg></span></span><span class="text_in"><span class="text_main">資料請求</span><span class="text_sub">PDFデータダウンロード</span></span></a><div class="a_background" style="background:#f17594"></div><div class="a_in_border" style="border:1px solid #ffffff;border-radius:12px"></div></div></div>
<!-- /wp:wdl/paid-block-lw-button-5 -->

<!-- wp:wdl/lw-space-1 -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:80px"></div><div class="tb" style="height:64px"></div><div class="sp" style="height:40px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:wdl/custom-title-2 {"mainTitle":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan data-lw_font_set=\u0022\u0022 class=\u0022custom-font-settings custom-font-settings fs-0-6\u0022\u003eお知らせ\u003c/span\u003e\u003c/mark\u003e","subTitle":"","textAlignment":"center","trigger":"lw_anime lw_scroll","animationClass":"lw-fade-up","animationDurationClass":"dur-1-0s"} -->
<h2 class="wp-block-wdl-custom-title-2 custom-title-2 center lw_anime lw_scroll lw-fade-up dur-1-0s"><span class="main"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span data-lw_font_set="" class="custom-font-settings custom-font-settings fs-0-6">お知らせ</span></mark></span><span class="sub"></span></h2>
<!-- /wp:wdl/custom-title-2 -->

<!-- wp:wdl/lw-news-list-1 {"numberOfPosts":3} -->
<div class="wp-block-wdl-lw-news-list-1"><div class="news-list-1" data-number="3" data-category="" data-type="post" data-date-font="Noto Sans JP" data-date-font-weight="400" data-cat-font="Noto Sans JP" data-cat-font-weight="400" data-cat-bg-color="var(--color-main)" data-title-font="Noto Sans JP" data-title-font-weight="400"><ul class="news-list-1__wrap"></ul></div><script>
                        document.addEventListener('DOMContentLoaded', () => {
                            const newsList1Container = document.querySelector('.news-list-1');
                            
                            if (newsList1Container) {
                                const newsList1NumberOfPosts = newsList1Container.getAttribute('data-number') || 4;
                                const newsList1CategoryId = newsList1Container.getAttribute('data-category');
                                const newsList1PostType = newsList1Container.getAttribute('data-type') || 'post';

                                const newsList1DateFont = newsList1Container.getAttribute('data-date-font');
                                const newsList1DateFontWeight = newsList1Container.getAttribute('data-date-font-weight');
                                const newsList1CatFont = newsList1Container.getAttribute('data-cat-font');
                                const newsList1CatFontWeight = newsList1Container.getAttribute('data-cat-font-weight');
                                const newsList1CatBgColor = newsList1Container.getAttribute('data-cat-bg-color');
                                const newsList1TitleFont = newsList1Container.getAttribute('data-title-font');
                                const newsList1TitleFontWeight = newsList1Container.getAttribute('data-title-font-weight');

                                let newsList1ApiUrl = `${MyThemeSettings.home_Url}/wp-json/wp/v2/${newsList1PostType === 'post' ? 'posts' : newsList1PostType}?per_page=${newsList1NumberOfPosts}&orderby=date&order=desc&_embed`;
                                if (newsList1CategoryId) {
                                    newsList1ApiUrl += `&categories=${newsList1CategoryId}`;
                                }

                                fetch(newsList1ApiUrl)
                                    .then(response => {
                                        if (!response.ok) {
                                            throw new Error('投稿の取得に失敗しました');
                                        }
                                        return response.json();
                                    })
                                    .then(posts => {
                                        let newsList1Html = '<ul class="news-list-1__wrap">';

                                        posts.forEach(post => {
                                            const newsList1Date = new Date(post.date).toLocaleDateString();
                                            const newsList1Title = post.title.rendered;
                                            const newsList1Link = post.link;
                                            const newsList1Category = post._embedded && post._embedded['wp:term'] && post._embedded['wp:term'][0]
                                                ? post._embedded['wp:term'][0][0].name
                                                : 'カテゴリーなし';

                                            newsList1Html += `
                                                <li>
                                                    <a href="${newsList1Link}">
                                                        <div class="data">
                                                            <div class="date" style="font-weight: ${newsList1DateFontWeight};" data-lw_font_set="${newsList1DateFont}">
                                                                <span>${newsList1Date}</span>
                                                            </div>
                                                            <div class="cat" style="background-color: ${newsList1CatBgColor}; font-weight: ${newsList1CatFontWeight};" data-lw_font_set="${newsList1CatFont}">
                                                                <span>${newsList1Category}</span>
                                                            </div>
                                                        </div>
                                                        <div class="post_title">
                                                            <h3 style="font-weight: ${newsList1TitleFontWeight};" data-lw_font_set="${newsList1TitleFont}">${newsList1Title}</h3>
                                                        </div>
                                                    </a>
                                                </li>
                                            `;
                                        });

                                        newsList1Html += '</ul>';
                                        newsList1Container.innerHTML = newsList1Html;
                                    })
                                    .catch(error => {
                                        console.error('投稿を取得できませんでした:', error);
                                        newsList1Container.innerHTML = '<p>投稿を読み込めませんでした。</p>';
                                    });
                            }
                        });
                        </script></div>
<!-- /wp:wdl/lw-news-list-1 -->

<!-- wp:wdl/lw-space-1 -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:80px"></div><div class="tb" style="height:64px"></div><div class="sp" style="height:40px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:wdl/lw-voice-1 {"h2Title":"\u003cmark style=\u0022background-color:rgba(0, 0, 0, 0);color:#003366\u0022 class=\u0022has-inline-color\u0022\u003e\u003cspan data-lw_font_set=\u0022\u0022 class=\u0022custom-font-settings custom-font-settings fs-0-9\u0022\u003eお客様の声\u003c/span\u003e\u003c/mark\u003e"} -->
<div class="wp-block-wdl-lw-voice-1 lw-voice-1" style="background-color:#eeeeee"><h2 class="lw-voice-1__title" style="font-weight:600;color:#000000" data-lw_font_set="Noto Sans JP"><mark style="background-color:rgba(0, 0, 0, 0);color:#003366" class="has-inline-color"><span data-lw_font_set="" class="custom-font-settings custom-font-settings fs-0-9">お客様の声</span></mark></h2><ul class="lw-voice-1__ul"><li class="lw-voice-1__li"><div class="lw-voice-1__name" style="background-color:var(--color-main);color:#ffffff;font-weight:500" data-lw_font_set="Noto Sans JP">T様／○○市様</div><div class="lw-voice-1__text"><h3 style="color:#000000;font-weight:500" data-lw_font_set="Noto Sans JP">相談から施工まで、とても丁寧な対応でした</h3><p style="color:#000000;font-weight:500" data-lw_font_set="Noto Sans JP">「問い合わせの段階から細かい説明があり、とても安心してお願いできました。水漏れの心配も解消され、洗面所が快適な空間になりました。仕上がりもとてもきれいで家族みんな喜んでいます。」</p></div></li><li class="lw-voice-1__li"><div class="lw-voice-1__name" style="background-color:var(--color-main);color:#ffffff;font-weight:500" data-lw_font_set="Noto Sans JP">K様／△△市</div><div class="lw-voice-1__text"><h3 style="color:#000000;font-weight:500" data-lw_font_set="Noto Sans JP">壁紙の張り替えで部屋が見違えるほど明るく</h3><p style="color:#000000;font-weight:500" data-lw_font_set="Noto Sans JP">「古くなった壁紙を思い切ってリフォームして正解でした。部屋が見違えるほど明るくなり、家族もとても喜んでいます。説明もわかりやすく、安心してお任せできました。」</p></div></li><li class="lw-voice-1__li"><div class="lw-voice-1__name" style="background-color:var(--color-main);color:#ffffff;font-weight:500" data-lw_font_set="Noto Sans JP">S様／□□町</div><div class="lw-voice-1__text"><h3 style="color:#000000;font-weight:500" data-lw_font_set="Noto Sans JP">職人さんの丁寧な仕事ぶりに感動しました</h3><p style="color:#000000;font-weight:500" data-lw_font_set="Noto Sans JP">「施工中も職人さんがとても丁寧に作業してくださり、途中経過まできちんと説明があり安心できました。細部まできれいに仕上げていただき、想像以上の出来栄えに大満足です。次回のリフォームもぜひお願いしたいと思います。」</p></div></li></ul></div>
<!-- /wp:wdl/lw-voice-1 -->

<!-- wp:wdl/paid-block-cta-4 {"mainTitle1":"\u003cstrong\u003eContact\u003c/strong\u003e","subTitle1":"\u003cstrong\u003eお問合せ\u003c/strong\u003e","desc1":"まずはお気軽にご相談ください。","backgroundImage1":"https://lite-word.com/wp-content/uploads/2025/06/reform_icon4.png","filterColor1":"#003366","filterOpacity1":32,"bgColor1":"#3399cc","mainTitle2":"\u003cstrong\u003eAccess\u003c/strong\u003e","subTitle2":"\u003cstrong\u003e事務所アクセス\u003c/strong\u003e","desc2":"素材サンプルもご用意しています。","backgroundImage2":"https://lite-word.com/wp-content/uploads/2025/06/reform_icon16.png","filterColor2":"#003366","filterOpacity2":32,"bgColor2":"#3399cc"} -->
<div class="wp-block-wdl-paid-block-cta-4 paid-block-cta-4"><ul><li><a href="#"><h2 class="ttl parts_page_ttl_main" data-lw_font_set="Lato"><div class="main"><strong>Contact</strong></div><div class="sub"><strong>お問合せ</strong></div></h2><p>まずはお気軽にご相談ください。</p><div class="btn"><div style="color:#ffffff">詳細はこちら</div><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" style="fill:#ffffff"><path d="M342.6 233.4c12.5 12.5 
 12.5 32.8 0 45.3l-192 192c-12.5 
 12.5-32.8 12.5-45.3 0s-12.5-32.8 
 0-45.3L274.7 256 105.4 86.6c-12.5-12.5-12.5-32.8 
 0-45.3s32.8-12.5 45.3 0l192 192z"></path></svg><div class="btn_bg" style="background-color:#3399cc;color:#ffffff"></div></div></a><div class="this_filter" style="background:#003366;opacity:32%"></div><div class="bg_img"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon4.png" alt="CTA1背景"/></div></li><li><a href="#"><h2 class="ttl parts_page_ttl_main"><div class="main" data-lw_font_set="Lato"><strong>Access</strong></div><div class="sub"><strong>事務所アクセス</strong></div></h2><p>素材サンプルもご用意しています。</p><div class="btn"><div style="color:#ffffff">詳細はこちら</div><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" style="fill:#ffffff"><path d="M342.6 233.4c12.5 12.5 
 12.5 32.8 0 45.3l-192 192c-12.5 
 12.5-32.8 12.5-45.3 0s-12.5-32.8 
 0-45.3L274.7 256 105.4 86.6c-12.5-12.5-12.5-32.8 
 0-45.3s32.8-12.5 45.3 0l192 192z"></path></svg><div class="btn_bg" style="background-color:#3399cc;color:#ffffff"></div></div></a><div class="this_filter" style="background:#003366;opacity:32%"></div><div class="bg_img"><img src="https://lite-word.com/wp-content/uploads/2025/06/reform_icon16.png" alt="CTA2背景"/></div></li></ul></div>
<!-- /wp:wdl/paid-block-cta-4 -->