wp.domReady(function() {
    wp.blocks.unregisterBlockType('core/spacer');
});