/* ------------------------------------------------------------------
 * ① ドロワー開閉ボタン
 * ----------------------------------------------------------------*/

	//ページが読み込みされたら
	document.addEventListener('DOMContentLoaded', () => {
		if(document.querySelector('.drawer_nav')){
			const drawerNavOpenBtns = document.querySelectorAll('.drawer_nav_open');
			const body   = document.body;
			const html   = document.documentElement;
			const hamBtn = document.querySelector('.ham_btn');
			const drawer = document.querySelector('.drawer_nav');
			const filter = document.querySelector('.drawer_nav_filter');
	
			const toggleDrawer = () => {
				hamBtn.classList.toggle('active');
				drawer.classList.toggle('active');
				filter.classList.toggle('active');
				body.classList.toggle('scroll_off');
				html.classList.toggle('scroll_off');
			};
	
			drawerNavOpenBtns.forEach((btn) => btn.addEventListener('click', toggleDrawer));
	
			/* ----------------------------------------------------------------
			* ② 同一ページ内アンカーリンクでドロワーを閉じる  ★追加
			* ----------------------------------------------------------------*/
			const drawerLinks = drawer.querySelectorAll('a');
	
			drawerLinks.forEach((link) => {
				// 絶対 URL 化して現在ページと比較
				const url = new URL(link.href, location.href);
	
				// ① hash がある ＆ ② pathname・search が現在と一致 ⇒ 同一ページ内アンカー
				const isSamePageAnchor =
					url.hash &&
					url.pathname === location.pathname &&
					url.search === location.search;
	
				if (isSamePageAnchor) {
					link.addEventListener('click', () => {
						// ドロワーが開いているときだけ閉じる
						if (drawer.classList.contains('active')) {
							hamBtn.classList.remove('active');
							drawer.classList.remove('active');
							filter.classList.remove('active');
							body.classList.remove('scroll_off');
							html.classList.remove('scroll_off');
						}
					});
				}
			});
		}else{
			// ドロワーがない場合はハンバーガーボタンを非表示に
			if(document.querySelector('.ham_btn')){
				document.querySelector('.ham_btn').style.display = 'none';
			}
		}

	});


/* ------------------------------------------------------------------
 * ③ サブメニュー用：jQuery（そのまま）
 * ----------------------------------------------------------------*/
jQuery(document).ready(function ($) {
	const addDownBtn = function (menuItems) {
		menuItems.each(function () {
			const subMenu = $(this).children('ul.sub-menu');
			if (subMenu.length) {
				const downBtn = $('<div class="down_btn"><div></div></div>');
				$(this).prepend(downBtn);

				downBtn.on('click', function () {
					$(this).toggleClass('active');
					subMenu.slideToggle().toggleClass('active');
				});

				addDownBtn(subMenu.children('li')); // 再帰
			}
		});
	};

	addDownBtn($('.menu_sp > li')); // ルート階層から開始
});



/**
 * .lw_header_mainの高さを取得して、cssの変数「--lw_header_height」にセット
 */
{
  const lw_header = document.querySelector(".lw_header_main");
  if (lw_header) {
    const LwheaderMeinHeight = lw_header.offsetHeight; // .lw_header_mainの高さを取得
    document.documentElement.style.setProperty(
      "--header-main-height",
      `${LwheaderMeinHeight}px`
    ); // CSS変数にセット
  }
}
/**
 * スクロール時にヘッダーの高さを考慮して、スムーススクロールを実装
 */
document.addEventListener("DOMContentLoaded", () => {
  const anchors = document.querySelectorAll('a[href^="#"]');

  anchors.forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const href = this.getAttribute("href");
      if (href.length <= 1) return; // href="#" のときは無視

      const targetId = href.slice(1);
      const target = document.getElementById(targetId);
      if (!target) return;

      e.preventDefault();

      // ヘッダーの高さと調整分（マイナスで上にずらす）
      const headerHeight =
        parseInt(
          getComputedStyle(document.documentElement).getPropertyValue(
            "--header-main-height"
          )
        ) || 0;
      const adjustOffset = 40; // ← ここを変えると調整できる

      // スクロール先の位置（ヘッダー + 追加の調整）
      const offset =
        target.getBoundingClientRect().top +
        window.scrollY -
        headerHeight -
        adjustOffset;

      // スムーズスクロール実行
      window.scrollTo({
        top: offset,
        behavior: "smooth",
      });
    });
  });
});

/**
 * 新しいタブで開くをdataで指定
 */
document.addEventListener("DOMContentLoaded", () => {
  document
    .querySelectorAll('a[data-open-in-new-tab="true"]')
    .forEach((link) => {
      link.setAttribute("target", "_blank");
      link.setAttribute("rel", "noopener noreferrer");
    });
});

/* ================================================
    lw_in_text_splitが付与されていたら
    * 文字列を分割して <span> タグで囲む
   ----------------------------------------------- */
document.addEventListener("DOMContentLoaded", () => {
  // 対象 … .ttl .main.no_line_break
  const targets = document.querySelectorAll(".lw_in_text_split");

  targets.forEach((el) => {
    // 既に処理済みならスキップ
    if (el.classList.contains("lw_split_done")) return;

    // <br> → \n へ置換して分割
    const lines = el.innerHTML.replace(/<br\s*\/?>/gi, "\n").split(/\n/);

    // 各行を <span class="in_text"> で囲む
    el.innerHTML = lines
      .map((txt) => `<span class="lw_in_text_box">${txt}</span>`)
      .join("");

    // 二重処理防止フラグ
    el.classList.add("lw_split_done");
  });
});

/* ------------------------------------------------------------
 * 〈ピュア JavaScript〉
 * <span class="lw-br …"> → <br class="lw-br …"> に置換
 * ---------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', () => {
	// 1) すべての span.lw-br を取得
	document.querySelectorAll('span.lw-br').forEach(span => {

		// 2) 新しい <br> 要素を生成
		const br = document.createElement('br');

		// 3) span が持つすべての属性をそのままコピー
		[...span.attributes].forEach(attr => {
			br.setAttribute(attr.name, attr.value);
		});

		// 4) DOM を置き換え
		span.replaceWith(br);
	});
});



