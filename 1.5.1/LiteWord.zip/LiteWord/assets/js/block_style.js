/**
 * WordPress Block Editor - Dynamic CSS Loader
 * エディター画面でブロックが追加された際に動的にCSSを読み込む
 * 改善版 - より確実な読み込みとタイミング制御
 */

(function() {
    'use strict';

    // WordPress API の存在確認
    if (!window.wp || !window.wp.data || !window.MyThemeSettings) {
        console.warn('WDL Dynamic Styles: Required WordPress APIs or MyThemeSettings not available');
        return;
    }

    class WDLDynamicStyleLoader {
        constructor() {
            this.loadedStyles = new Set();
            this.pendingStyles = new Set();
            this.isInitialized = false;
            this.unsubscribe = null;
            this.retryAttempts = new Map();
            this.maxRetries = 3;
            
            // DOM読み込み完了後に初期化
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => this.init());
            } else {
                this.init();
            }
        }

        init() {
            try {
                // エディターが利用可能になるまで待機
                this.waitForEditor();
                
                // ブロック挿入イベントを直接監視
                this.setupBlockInsertionListener();
                
            } catch (error) {
                console.error('WDL Dynamic Styles: Initialization failed', error);
            }
        }

        waitForEditor() {
            const checkEditor = () => {
                const blockEditor = wp.data.select('core/block-editor');
                
                if (blockEditor && typeof blockEditor.getBlocks === 'function') {
                    this.startMonitoring();
                } else {
                    // 100ms後に再試行
                    setTimeout(checkEditor, 100);
                }
            };
            
            checkEditor();
        }

        setupBlockInsertionListener() {
            // ブロック挿入時のイベントをフック
            if (wp.hooks && wp.hooks.addAction) {
                wp.hooks.addAction(
                    'blocks.registerBlockType',
                    'wdl/dynamic-styles',
                    (settings, name) => {
                        if (name && name.startsWith('wdl/')) {
                            // ブロック登録時に即座にCSSを準備
                            setTimeout(() => {
                                this.preloadBlockStyle('wdl/' + name.replace('wdl/', ''));
                            }, 0);
                        }
                    }
                );
            }
        }

        startMonitoring() {
            if (this.isInitialized) {
                return;
            }

            console.log('WDL Dynamic Styles: Starting enhanced block monitoring');
            
            let previousBlockTypes = new Set();
            let debounceTimer = null;

            // エディターの変更を監視（デバウンス付き）
            this.unsubscribe = wp.data.subscribe(() => {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => {
                    this.checkForNewBlocks(previousBlockTypes);
                }, 50);
            });

            // ブロック挿入の直接監視
            const originalInsertBlocks = wp.data.dispatch('core/block-editor').insertBlocks;
            if (originalInsertBlocks) {
                wp.data.dispatch('core/block-editor').insertBlocks = (...args) => {
                    const result = originalInsertBlocks.apply(wp.data.dispatch('core/block-editor'), args);
                    
                    // 挿入されたブロックを即座に処理
                    setTimeout(() => {
                        this.scanAndLoadStyles();
                    }, 0);
                    
                    return result;
                };
            }

            this.isInitialized = true;

            // 初期ロード（遅延を短くする）
            setTimeout(() => {
                this.loadExistingBlockStyles();
            }, 10);
        }

        checkForNewBlocks(previousBlockTypes) {
            try {
                const blockEditor = wp.data.select('core/block-editor');
                if (!blockEditor) return;

                const currentBlocks = blockEditor.getBlocks();
                const currentBlockTypes = this.extractBlockTypes(currentBlocks);
                
                // 新しく追加されたブロックタイプを検出
                const newBlockTypes = currentBlockTypes.filter(
                    type => !previousBlockTypes.has(type) && 
                           !this.loadedStyles.has(type) && 
                           !this.pendingStyles.has(type)
                );
                
                // 新しいブロックのCSSを読み込み
                if (newBlockTypes.length > 0) {
                    console.log('WDL Dynamic Styles: New blocks detected:', newBlockTypes);
                    newBlockTypes.forEach(blockType => {
                        this.loadBlockStyle(blockType, true);
                    });
                }
                
                // 更新
                previousBlockTypes.clear();
                currentBlockTypes.forEach(type => previousBlockTypes.add(type));
                
            } catch (error) {
                console.error('WDL Dynamic Styles: Error in monitoring', error);
            }
        }

        extractBlockTypes(blocks) {
            const types = new Set();
            
            const traverse = (blockArray) => {
                if (!Array.isArray(blockArray)) return;
                
                blockArray.forEach(block => {
                    if (block && block.name && block.name.startsWith('wdl/')) {
                        types.add(block.name);
                    }
                    if (block && block.innerBlocks && Array.isArray(block.innerBlocks)) {
                        traverse(block.innerBlocks);
                    }
                });
            };
            
            traverse(blocks);
            return Array.from(types);
        }

        scanAndLoadStyles() {
            try {
                const blockEditor = wp.data.select('core/block-editor');
                if (!blockEditor) return;

                const currentBlocks = blockEditor.getBlocks();
                const currentBlockTypes = this.extractBlockTypes(currentBlocks);
                
                currentBlockTypes.forEach(blockType => {
                    if (!this.loadedStyles.has(blockType) && !this.pendingStyles.has(blockType)) {
                        this.loadBlockStyle(blockType, true);
                    }
                });
            } catch (error) {
                console.error('WDL Dynamic Styles: Error in scanAndLoadStyles', error);
            }
        }

        loadExistingBlockStyles() {
            try {
                const blockEditor = wp.data.select('core/block-editor');
                if (!blockEditor) return;

                const currentBlocks = blockEditor.getBlocks();
                const currentBlockTypes = this.extractBlockTypes(currentBlocks);
                
                if (currentBlockTypes.length > 0) {
                    console.log('WDL Dynamic Styles: Loading existing blocks:', currentBlockTypes);
                    currentBlockTypes.forEach(blockType => {
                        this.loadBlockStyle(blockType, false);
                    });
                }
            } catch (error) {
                console.error('WDL Dynamic Styles: Error loading existing blocks', error);
            }
        }

        preloadBlockStyle(blockType) {
            if (this.loadedStyles.has(blockType) || this.pendingStyles.has(blockType)) {
                return;
            }
            
            // プリロードとしてマーク
            this.pendingStyles.add(blockType);
            
            // 少し遅延させて実際の読み込み
            setTimeout(() => {
                this.loadBlockStyle(blockType, true);
            }, 100);
        }

        loadBlockStyle(blockType, isPriority = false) {
            if (this.loadedStyles.has(blockType)) {
                return;
            }

            // 既に読み込み中の場合はスキップ
            if (this.pendingStyles.has(blockType)) {
                return;
            }

            this.pendingStyles.add(blockType);

            try {
                const blockName = blockType.replace('wdl/', '');
                const baseUrl = MyThemeSettings.themeUrl + '/my-blocks/build/' + blockName + '/';
                
                // 優先度が高い場合は即座に読み込み
                const delay = isPriority ? 0 : 100;
                
                setTimeout(() => {
                    // editor.css を読み込み
                    this.loadStylesheet(
                        'wdl-' + blockName + '-editor-dynamic',
                        baseUrl + 'editor.css',
                        'editor',
                        blockType
                    );
                    
                    // style.css を読み込み（プレビュー用）
                    this.loadStylesheet(
                        'wdl-' + blockName + '-style-dynamic',
                        baseUrl + 'style.css',
                        'style',
                        blockType
                    );
                }, delay);
                
            } catch (error) {
                console.error('WDL Dynamic Styles: Error loading styles for', blockType, error);
                this.pendingStyles.delete(blockType);
            }
        }

        loadStylesheet(id, href, type, blockType) {
            // 既に読み込まれていないかチェック
            if (document.getElementById(id)) {
                this.pendingStyles.delete(blockType);
                this.loadedStyles.add(blockType);
                return;
            }

            const link = document.createElement('link');
            link.id = id;
            link.rel = 'stylesheet';
            link.href = href + '?v=' + Date.now(); // キャッシュバスティング
            link.type = 'text/css';
            
            // エラーハンドリング
            link.onerror = () => {
                console.warn('WDL Dynamic Styles: Failed to load', type, 'stylesheet:', href);
                this.pendingStyles.delete(blockType);
                
                // リトライロジック
                const attempts = this.retryAttempts.get(blockType) || 0;
                if (attempts < this.maxRetries) {
                    this.retryAttempts.set(blockType, attempts + 1);
                    setTimeout(() => {
                        console.log('WDL Dynamic Styles: Retrying load for', blockType);
                        this.loadBlockStyle(blockType, true);
                    }, 500 * (attempts + 1));
                }
            };
            
            link.onload = () => {
                console.log('WDL Dynamic Styles: Successfully loaded', type, 'stylesheet for:', blockType);
                this.pendingStyles.delete(blockType);
                this.loadedStyles.add(blockType);
                this.retryAttempts.delete(blockType);
                
                // 読み込み完了後にエディターを強制更新
                this.forceEditorRefresh();
            };
            
            document.head.appendChild(link);
        }

        forceEditorRefresh() {
            // エディターの表示を強制的に更新
            if (window.wp && window.wp.data) {
                const editor = document.querySelector('.block-editor-writing-flow');
                if (editor) {
                    // 微小な変更を加えて再レンダリングを促す
                    editor.style.opacity = '0.999';
                    setTimeout(() => {
                        editor.style.opacity = '1';
                    }, 10);
                }
            }
        }

        destroy() {
            if (this.unsubscribe) {
                this.unsubscribe();
                this.unsubscribe = null;
            }
            this.isInitialized = false;
            this.loadedStyles.clear();
            this.pendingStyles.clear();
            this.retryAttempts.clear();
            console.log('WDL Dynamic Styles: Monitoring stopped');
        }
    }

    // インスタンス作成
    let dynamicLoader;

    // エディター画面でのみ実行
    if (window.wp && window.wp.data) {
        // wp.domReady を使用してより確実に初期化
        if (window.wp.domReady) {
            window.wp.domReady(() => {
                dynamicLoader = new WDLDynamicStyleLoader();
            });
        } else {
            dynamicLoader = new WDLDynamicStyleLoader();
        }
        
        // ページ離脱時のクリーンアップ
        window.addEventListener('beforeunload', () => {
            if (dynamicLoader) {
                dynamicLoader.destroy();
            }
        });
    }

    // デバッグ用: グローバルに公開
    if (window.location.search.includes('wdl_debug=1')) {
        window.WDLDynamicStyleLoader = dynamicLoader;
    }

})();