<!-- wp:wdl/paid-block-cta-3 {"leadText":"365日年中無休お電話受付中\u003cbr\u003e査定は完全無料です。"} -->
<div class="wp-block-wdl-paid-block-cta-3 paid-block-cta-3"><a class="this_wrap" href="tel:0120-000-000" style="background-color:#f8f4de;border-color:#f45353"><div class="text_in"><h2 class="title">中古車・高価買取</h2><p>365日年中無休お電話受付中<br>査定は完全無料です。</p><ul><li><span>即日買取</span></li><li><span>出張買取</span></li><li><span>実績多数</span></li></ul><div class="tel"><span data-lw_font_set="Montserrat">0120-000-000</span></div></div><div class="image"><img src="https://lite-word.com/sample_img/reception/women/6.webp" alt="CTA画像" class="object_fit_cover object_position_center"/></div></a><div class="tap_tel"><p>タップしてお電話ください</p></div><style>
                        @container (max-width: 700px) {
                            .paid-block-cta-3 .this_wrap h2.title  {
                                background-color: #f45353 !important;
                            }
                        }
                    
                    </style></div>
<!-- /wp:wdl/paid-block-cta-3 -->