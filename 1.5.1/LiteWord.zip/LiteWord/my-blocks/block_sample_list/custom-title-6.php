<!-- wp:wdl/custom-title-6 -->
<h2 class="wp-block-wdl-custom-title-6 custom-title-6"><div class="main"><span>CONTENT</span><div class="accent" style="background-color:var(--color-main)"></div></div></h2>
<!-- /wp:wdl/custom-title-6 -->