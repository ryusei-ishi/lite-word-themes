<!-- wp:wdl/paid-block-solution-2 {"blockId":"paid-block-solution-2-a819eb75"} -->
<div class="wp-block-wdl-paid-block-solution-2 paid-block-solution-2 paid-block-solution-2-a819eb75"><div class="paid-block-solution-2_inner" style="border-color:var(--color-main)"><h2 class="ttl" style="background:var(--color-main)">このな事が解決できます</h2><ul class="list"><li><div class="img_wrap icon_image" data-imagesize="icon"><img src="https://lite-word.com/sample_img/icon/people_1.svg" alt=""/></div><p>テキストテキストテキストテキストテキス</p></li><li><div class="img_wrap icon_image" data-imagesize="icon"><img src="https://lite-word.com/sample_img/icon/en_5.svg" alt=""/></div><p>テキストテキストテキストテキストテキスト</p></li><li><div class="img_wrap icon_image" data-imagesize="icon"><img src="https://lite-word.com/sample_img/icon/ambulance_1.svg" alt=""/></div><p>テキストテキストテキストテキストテキスト</p></li></ul></div><style>
                        .paid-block-solution-2-a819eb75 .paid-block-solution-2_inner ul.list li + li:before {
                            background: var(--color-main);
                        }
                    </style></div>
<!-- /wp:wdl/paid-block-solution-2 -->