<!-- wp:wdl/custom-title-1 -->
<h2 class="wp-block-wdl-custom-title-1 custom-title-1"><span class="main">タイトル</span><span class="sub">サブタイトル</span></h2>
<!-- /wp:wdl/custom-title-1 -->