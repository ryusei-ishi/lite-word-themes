<!-- wp:wdl/custom-title-5 -->
<h2 class="wp-block-wdl-custom-title-5 custom-title-5" style="border-color:var(--color-main)"><span class="sub" style="color:var(--color-main)">製品紹介</span><span class="main">PRODUCTS</span></h2>
<!-- /wp:wdl/custom-title-5 -->