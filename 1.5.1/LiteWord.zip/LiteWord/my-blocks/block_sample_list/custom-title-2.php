<!-- wp:wdl/custom-title-2 -->
<h2 class="wp-block-wdl-custom-title-2 custom-title-2 left"><span class="main">CONTENT</span><span class="sub">SUB TITLE TEXT</span></h2>
<!-- /wp:wdl/custom-title-2 -->