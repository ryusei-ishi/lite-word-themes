<!-- wp:wdl/lw-pr-custom-title-12 -->
<div class="wp-block-wdl-lw-pr-custom-title-12 lw-pr-custom-title-12" style="--color-main:#0a71c0;--lw-pr-custom-title-12-sub-color:#13214c"><h2 class="ttl"><span class="main">カスタムタイトル</span><span class="sub">サブタイトル</span></h2></div>
<!-- /wp:wdl/lw-pr-custom-title-12 -->