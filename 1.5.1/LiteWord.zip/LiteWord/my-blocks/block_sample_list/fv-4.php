<!-- wp:wdl/fv-4 -->
<div class="wp-block-wdl-fv-4 fv-4 min-h-pc-480px min-h-tb-400px min-h-sp-360px"><div class="fv-4_inner pc_left sp_left" style="max-width:1040px"><h1 style="color:#fff"><span class="sub" style="color:#fff">軽量で簡単なWordPressテーマ</span><span class="main" style="color:#fff">Lite Word</span></h1><p style="color:#fff">デザイナーとプログラマーが共同で開発した
コーポレートサイトやオウンドメディアに最適なテーマ</p></div><div class="filter" style="background-color:var(--color-main);opacity:1"></div></div>
<!-- /wp:wdl/fv-4 -->