<!-- wp:wdl/paid-block-cta-4 -->
<div class="wp-block-wdl-paid-block-cta-4 paid-block-cta-4"><ul><li><a href="#"><h2 class="ttl parts_page_ttl_main" data-lw_font_set="Lato"><div class="main">Franchise</div><div class="sub">加盟店募集</div></h2><p>独立を応援！フランチャイズ加盟しませんか？</p><div class="btn"><div style="color:#ffffff">詳細はこちら</div><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" style="fill:#ffffff"><path d="M342.6 233.4c12.5 12.5 
 12.5 32.8 0 45.3l-192 192c-12.5 
 12.5-32.8 12.5-45.3 0s-12.5-32.8 
 0-45.3L274.7 256 105.4 86.6c-12.5-12.5-12.5-32.8 
 0-45.3s32.8-12.5 45.3 0l192 192z"></path></svg><div class="btn_bg" style="background-color:#d88d00;color:#ffffff"></div></div></a><div class="this_filter" style="background:rgba(38,129,147,1);opacity:60%"></div><div class="bg_img"><img src="https://lite-word.com/sample_img/shop/1.webp" alt="CTA1背景"/></div></li><li><a href="#"><h2 class="ttl parts_page_ttl_main"><div class="main" data-lw_font_set="Lato">Recruit</div><div class="sub">求人情報</div></h2><p>◯では、一緒に働くスタッフを全店で募集しております！</p><div class="btn"><div style="color:#ffffff">詳細はこちら</div><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" style="fill:#ffffff"><path d="M342.6 233.4c12.5 12.5 
 12.5 32.8 0 45.3l-192 192c-12.5 
 12.5-32.8 12.5-45.3 0s-12.5-32.8 
 0-45.3L274.7 256 105.4 86.6c-12.5-12.5-12.5-32.8 
 0-45.3s32.8-12.5 45.3 0l192 192z"></path></svg><div class="btn_bg" style="background-color:#F02D2D;color:#ffffff"></div></div></a><div class="this_filter" style="background:#690707;opacity:60%"></div><div class="bg_img"><img src="https://lite-word.com/sample_img/shop/5.webp" alt="CTA2背景"/></div></li></ul></div>
<!-- /wp:wdl/paid-block-cta-4 -->