<!-- wp:wdl/lw-pr-custom-title-13 {"orderReversed":true} -->
<div class="wp-block-wdl-lw-pr-custom-title-13 lw-pr-custom-title-13" style="--color-main:#0a71c0"><h2 class="ttl"><span class="main">カスタムタイトル</span><span class="sub">サブタイトル</span><div class="left"></div><div class="right"></div></h2></div>
<!-- /wp:wdl/lw-pr-custom-title-13 -->