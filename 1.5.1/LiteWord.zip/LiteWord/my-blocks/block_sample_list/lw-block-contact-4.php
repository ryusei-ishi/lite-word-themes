<!-- wp:columns {"style":{"color":{"gradient":"linear-gradient(90deg,rgb(24,106,153) 0%,rgb(57,127,159) 48%,rgb(29,103,161) 100%)"}},"paddingTopPc":"lw_padding_top_pc_48","paddingTopTb":"lw_padding_top_tb_40","paddingTopSp":"lw_padding_top_sp_32","paddingBottomPc":"lw_padding_bottom_pc_64","paddingBottomTb":"lw_padding_bottom_tb_48","paddingBottomSp":"lw_padding_bottom_sp_40","paddingLeftPc":"lw_padding_left_pc_48","paddingLeftTb":"lw_padding_left_tb_32","paddingLeftSp":"lw_padding_left_sp_20","paddingRightPc":"lw_padding_right_pc_48","paddingRightTb":"lw_padding_right_tb_32","paddingRightSp":"lw_padding_right_sp_20","maxWidthType":"100vw","maxWidthPx":880,"borderRadiusPc":"borderRadius_pc_0"} -->
<div class="wp-block-columns has-background lw_padding_top_pc_48 lw_padding_top_tb_40 lw_padding_top_sp_32 lw_padding_bottom_pc_64 lw_padding_bottom_tb_48 lw_padding_bottom_sp_40 lw_padding_left_pc_48 lw_padding_left_tb_32 lw_padding_left_sp_20 lw_padding_right_pc_48 lw_padding_right_tb_32 lw_padding_right_sp_20 lw_max_width_100vw borderRadius_pc_0" style="background:linear-gradient(90deg,rgb(24,106,153) 0%,rgb(57,127,159) 48%,rgb(29,103,161) 100%)"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:wdl/lw-contact-3 {"formId":2,"maxWidth":680,"labelColor":"#ffffff","inputBgColor":"#ffffff","buttonBgColor":"#d83939","uniqueClass":"lw-contact-3-e7e8ca1f"} -->
<div class="wp-block-wdl-lw-contact-3 lw-contact-3 lw-contact-3-e7e8ca1f" style="max-width:680px">[lw_mail_form_select id='1']<style>
                    .lw-contact-3-e7e8ca1f .lw_mail_form .label_in label,.supplement_text { color: #ffffff; }
                    .lw-contact-3-e7e8ca1f .lw_mail_form input[type="text"],
                    .lw-contact-3-e7e8ca1f .lw_mail_form input[type="email"],
                    .lw-contact-3-e7e8ca1f .lw_mail_form input[type="tel"],
                    .lw-contact-3-e7e8ca1f .lw_mail_form input[type="url"],
                    .lw-contact-3-e7e8ca1f .lw_mail_form input[type="password"],
                    .lw-contact-3-e7e8ca1f .lw_mail_form textarea,
                    .lw-contact-3-e7e8ca1f .lw_mail_form select {
                        background-color: #ffffff;
                        color: #000000;
                    }
                    .lw-contact-3-e7e8ca1f .lw_mail_form select option { color: #000000; }
                    .lw-contact-3-e7e8ca1f .lw_mail_form .checkbox_in label,
                    .lw-contact-3-e7e8ca1f .lw_mail_form .radio_in label {
                        color: #ffffff;
                    }
                    .lw-contact-3-e7e8ca1f .lw_mail_form .submit_wrap button {
                        background-color: #d83939;
                        color: #ffffff;
                    }
                    .lw-contact-3-e7e8ca1f .lw_mail_form .required:not(.is-optional) {
                        background-color: #da3838 !important;
                        color: #ffffff !important;
                    }
                    .lw-contact-3-e7e8ca1f .lw_mail_form .required.is-optional {
                        background-color: #dddddd !important;
                        color: #000000 !important;
                    }
                </style></div>
<!-- /wp:wdl/lw-contact-3 --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

