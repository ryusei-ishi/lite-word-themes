<!-- wp:wdl/lw-pr-custom-title-14 {"mainTitle":"カスタムタイトル"} -->
<div class="wp-block-wdl-lw-pr-custom-title-14 lw-pr-custom-title-14" style="--color-main:#0a71c0;width:100%;--custom-title-14-border-radius:6px"><h2 class="ttl"><span class="sub"><span class="text">サブタイトルサブタイトル</span></span><span class="main">カスタムタイトル</span></h2></div>
<!-- /wp:wdl/lw-pr-custom-title-14 -->