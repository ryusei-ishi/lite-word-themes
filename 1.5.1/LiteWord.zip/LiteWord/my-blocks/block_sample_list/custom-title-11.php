<!-- wp:wdl/lw-pr-custom-title-11 -->
<div class="wp-block-wdl-lw-pr-custom-title-11 lw-pr-custom-title-11" style="--color-main:#0a71c0"><h2 class="ttl"><span class="sub">サブタイトル</span><span class="main">カスタムタイトル</span></h2></div>
<!-- /wp:wdl/lw-pr-custom-title-11 -->