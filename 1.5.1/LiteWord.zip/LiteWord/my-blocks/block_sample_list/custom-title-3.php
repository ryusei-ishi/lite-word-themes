<!-- wp:wdl/custom-title-3 -->
<h2 class="wp-block-wdl-custom-title-3 custom-title-3 left"><div class="main"><span>CONTENT</span></div><div class="accent" style="background-color:var(--color-main)"></div><div class="sub"><span>テキストテキストテキストテキスト<br>テキストテキキストテキスト</span></div></h2>
<!-- /wp:wdl/custom-title-3 -->