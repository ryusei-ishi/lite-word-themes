<!-- wp:wdl/lw-gallery-01 -->
<nav class="wp-block-wdl-lw-gallery-01 lw-gallery-01"><p class="center_pc left_sp" style="max-width:800px">テキストテキストテキストテキスト
テキストテキストテキストテキストテキストテキストテキストテキスト</p><ul class="lw-gallery-01__wrap" style="max-width:800px"><li><img src="https://picsum.photos/1000/1000?random=1" alt=""/></li><li><img src="https://picsum.photos/1000/1000?random=2" alt=""/></li><li><img src="https://picsum.photos/1000/1000?random=3" alt=""/></li></ul><p class="center_pc left_sp" style="max-width:800px">テキストテキストテキストテキスト
テキストテキストテキストテキストテキストテキストテキストテキスト</p></nav>
<!-- /wp:wdl/lw-gallery-01 -->

