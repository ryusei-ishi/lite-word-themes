<!-- wp:wdl/custom-title-4 -->
<h2 class="wp-block-wdl-custom-title-4 custom-title-4"><span class="sub">サブタイトル</span><span class="main">タイトル</span></h2>
<!-- /wp:wdl/custom-title-4 -->