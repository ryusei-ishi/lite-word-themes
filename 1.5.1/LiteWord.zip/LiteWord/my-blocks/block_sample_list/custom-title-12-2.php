<!-- wp:wdl/lw-pr-custom-title-12 {"subTitle":"","colorMain":"#da5353","colorSub":"#6e5d5d","orderReversed":true,"maxWidth":480} -->
<div class="wp-block-wdl-lw-pr-custom-title-12 lw-pr-custom-title-12" style="--color-main:#da5353;--lw-pr-custom-title-12-sub-color:#6e5d5d;max-width:480px"><h2 class="ttl"><span class="main">カスタムタイトル</span></h2></div>
<!-- /wp:wdl/lw-pr-custom-title-12 -->