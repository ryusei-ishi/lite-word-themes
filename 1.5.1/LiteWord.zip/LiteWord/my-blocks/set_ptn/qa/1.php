<!-- wp:columns {"bgEnabled":true,"marginTopPc":"lw_margin_top_pc_0","marginBottomPc":"lw_margin_bottom_pc_0","paddingTopPc":"lw_padding_top_pc_48","paddingTopTb":"lw_padding_top_tb_40","paddingTopSp":"lw_padding_top_sp_32","paddingBottomPc":"lw_padding_bottom_pc_48","paddingBottomTb":"lw_padding_bottom_tb_40","paddingBottomSp":"lw_padding_bottom_sp_32"} -->
<div class="wp-block-columns lw_block_bg width_100vw lw_margin_top_pc_0 lw_margin_bottom_pc_0 lw_padding_top_pc_48 lw_padding_top_tb_40 lw_padding_top_sp_32 lw_padding_bottom_pc_48 lw_padding_bottom_tb_40 lw_padding_bottom_sp_32" style="--lw-block-bg-color:var(--color-main);--lw-block-bg-opacity:0.1"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:wdl/custom-title-4 {"mainTitle":"よくある質問","subTitle":"FAQ"} -->
<h2 class="wp-block-wdl-custom-title-4 custom-title-4"><span class="sub">FAQ</span><span class="main">よくある質問</span></h2>
<!-- /wp:wdl/custom-title-4 -->

<!-- wp:wdl/lw-qa-1 {"blockId":"lw-qa-1745031725085-1317"} -->
<div class="wp-block-wdl-lw-qa-1 lw-qa-1" id="lw-qa-1745031725085-1317"><dl class="lw-qa-1__dl"><dt><div class="label" data-lw_font_set="Roboto" style="font-weight:">Q<div style="background:var(--color-main)"></div></div><div class="lw-qa-1__text_q"><p data-lw_font_set="" style="font-weight:">質問テキスト質問テキスト質問テキスト</p></div><div class="open_icon" style="background:var(--color-main)"></div></dt><dd><div class="label" data-lw_font_set="Roboto" style="font-weight:;color:var(--color-main)">A<div style="background:var(--color-main)"></div></div><div class="lw-qa-1__text_a"><p data-lw_font_set="" style="font-weight:">回答テキスト回答テキスト回答テキスト回答テキスト</p></div></dd></dl><dl class="lw-qa-1__dl"><dt><div class="label" data-lw_font_set="Roboto" style="font-weight:">Q<div style="background:var(--color-main)"></div></div><div class="lw-qa-1__text_q"><p data-lw_font_set="" style="font-weight:">質問テキスト質問テキスト質問テキスト</p></div><div class="open_icon" style="background:var(--color-main)"></div></dt><dd><div class="label" data-lw_font_set="Roboto" style="font-weight:;color:var(--color-main)">A<div style="background:var(--color-main)"></div></div><div class="lw-qa-1__text_a"><p data-lw_font_set="" style="font-weight:">回答テキスト回答テキスト回答テキスト回答テキスト</p></div></dd></dl><dl class="lw-qa-1__dl"><dt><div class="label" data-lw_font_set="Roboto" style="font-weight:">Q<div style="background:var(--color-main)"></div></div><div class="lw-qa-1__text_q"><p data-lw_font_set="" style="font-weight:">質問テキスト質問テキスト質問テキスト</p></div><div class="open_icon" style="background:var(--color-main)"></div></dt><dd><div class="label" data-lw_font_set="Roboto" style="font-weight:;color:var(--color-main)">A<div style="background:var(--color-main)"></div></div><div class="lw-qa-1__text_a"><p data-lw_font_set="" style="font-weight:">回答テキスト回答テキスト回答テキスト回答テキスト</p></div></dd></dl><dl class="lw-qa-1__dl"><dt><div class="label" data-lw_font_set="Roboto" style="font-weight:">Q<div style="background:var(--color-main)"></div></div><div class="lw-qa-1__text_q"><p data-lw_font_set="" style="font-weight:">新しい質問</p></div><div class="open_icon" style="background:var(--color-main)"></div></dt><dd><div class="label" data-lw_font_set="Roboto" style="font-weight:;color:var(--color-main)">A<div style="background:var(--color-main)"></div></div><div class="lw-qa-1__text_a"><p data-lw_font_set="" style="font-weight:">新しい回答</p></div></dd></dl><script>
(function(){
	const scriptEl  = document.currentScript;
	if ( !scriptEl ) return;
	const container = scriptEl.parentNode;           // <script> の親 = lw-qa-1 本体
	if ( !container || !container.classList.contains('lw-qa-1') ) return;

	/* クリックイベントをバインド ---------------------- */
	function bind () {
		container.querySelectorAll(".lw-qa-1__dl").forEach( function( dl ){
			if ( dl.dataset.lwQaBound ) return;      // 二重バインド防止
			dl.dataset.lwQaBound = "1";
			dl.addEventListener("click", function(){ dl.classList.toggle("active"); } );
		} );
	}

	bind(); // まず 1 回

	/* MutationObserver – QA が動的に増減しても OK */
	const mo = new MutationObserver(bind);
	mo.observe(container,{ childList:true, subtree:true });
})();
		</script></div>
<!-- /wp:wdl/lw-qa-1 -->

<!-- wp:wdl/lw-button-01 -->
<div class="wp-block-wdl-lw-button-01 wp-block-wdl-button-01 padding-M align-center align-sp-center" style="margin-top:10px;margin-bottom:10px;--button-01-max-width-sp:240px"><a href="" style="max-width:240px;font-size:100%;background-color:var(--color-main);color:#ffffff;padding:0.9em 1.4em;text-align:center;text-decoration:none;border-radius:0px;border-width:0px;border-style:none;border-color:#000000">詳細はこちら</a></div>
<!-- /wp:wdl/lw-button-01 --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->