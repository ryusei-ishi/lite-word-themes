<!-- wp:columns {"bgEnabled":true,"marginTopPc":"lw_margin_top_pc_0","marginBottomPc":"lw_margin_bottom_pc_0","paddingTopPc":"lw_padding_top_pc_48","paddingTopTb":"lw_padding_top_tb_40","paddingTopSp":"lw_padding_top_sp_32","paddingBottomPc":"lw_padding_bottom_pc_64","paddingBottomTb":"lw_padding_bottom_tb_48","paddingBottomSp":"lw_padding_bottom_sp_32"} -->
<div class="wp-block-columns lw_block_bg width_100vw lw_margin_top_pc_0 lw_margin_bottom_pc_0 lw_padding_top_pc_48 lw_padding_top_tb_40 lw_padding_top_sp_32 lw_padding_bottom_pc_64 lw_padding_bottom_tb_48 lw_padding_bottom_sp_32" style="--lw-block-bg-color:var(--color-main);--lw-block-bg-opacity:0.1"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:wdl/paid-block-custom-title-7 {"subTitle":"staff info","mainTitle":"スタッフ紹介","sizeClass":"size_l"} -->
<div class="wp-block-wdl-paid-block-custom-title-7 paid-block-custom-title-7 size_l position_center"><h2 class="ttl"><span class="sub" style="color:var(--color-main)">staff info</span><span class="main">スタッフ紹介</span><span class="border_wrap"><span class="border_inner" style="border-radius:10px"><span class="border left" style="background-color:var(--color-main);opacity:0.2"></span><span class="border right" style="background-color:var(--color-main);opacity:1"></span></span></span></h2></div>
<!-- /wp:wdl/paid-block-custom-title-7 -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">テキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト<br>テキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
<!-- /wp:paragraph -->

<!-- wp:wdl/lw-space-1 {"pcHeight":32,"tbHeight":24,"spHeight":20} -->
<div class="wp-block-wdl-lw-space-1 lw_space_1"><div class="pc" style="height:32px"></div><div class="tb" style="height:24px"></div><div class="sp" style="height:20px"></div></div>
<!-- /wp:wdl/lw-space-1 -->

<!-- wp:columns {"className":"is-style-columns_gap_32_4"} -->
<div class="wp-block-columns is-style-columns_gap_32_4"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:wdl/paid-block-image-1 {"fontSizeClass":"font_size_ss"} -->
<div class="wp-block-wdl-paid-block-image-1 paid-block-image-1 font_size_ss" style="max-width:480px;margin-left:undefined;margin-right:undefined"><div class="paid-block-image-1__inner" style="aspect-ratio:400 / 340;border-radius:0.9em"><img src="https://placehold.jp/600x440.png" alt=""/><h3 class="name_plate" style="background-color:var(--color-main);border-color:var(--color-main);border-radius:0.2em;border-width:2px"><span class="sub">主任</span><span class="main">大阪 京子</span></h3></div></div>
<!-- /wp:wdl/paid-block-image-1 -->

<!-- wp:paragraph {"marginTopPc":"lw_margin_top_pc_20"} -->
<p class="lw_margin_top_pc_20">テキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:wdl/paid-block-image-1 {"fontSizeClass":"font_size_ss"} -->
<div class="wp-block-wdl-paid-block-image-1 paid-block-image-1 font_size_ss" style="max-width:480px;margin-left:undefined;margin-right:undefined"><div class="paid-block-image-1__inner" style="aspect-ratio:400 / 340;border-radius:0.9em"><img src="https://placehold.jp/600x440.png" alt=""/><h3 class="name_plate" style="background-color:var(--color-main);border-color:var(--color-main);border-radius:0.2em;border-width:2px"><span class="sub">主任</span><span class="main">大阪 京子</span></h3></div></div>
<!-- /wp:wdl/paid-block-image-1 -->

<!-- wp:paragraph {"marginTopPc":"lw_margin_top_pc_20"} -->
<p class="lw_margin_top_pc_20">テキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:wdl/paid-block-image-1 {"fontSizeClass":"font_size_ss"} -->
<div class="wp-block-wdl-paid-block-image-1 paid-block-image-1 font_size_ss" style="max-width:480px;margin-left:undefined;margin-right:undefined"><div class="paid-block-image-1__inner" style="aspect-ratio:400 / 340;border-radius:0.9em"><img src="https://placehold.jp/600x440.png" alt=""/><h3 class="name_plate" style="background-color:var(--color-main);border-color:var(--color-main);border-radius:0.2em;border-width:2px"><span class="sub">主任</span><span class="main">大阪 京子</span></h3></div></div>
<!-- /wp:wdl/paid-block-image-1 -->

<!-- wp:paragraph {"marginTopPc":"lw_margin_top_pc_20"} -->
<p class="lw_margin_top_pc_20">テキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"className":"is-style-columns_gap_32_4"} -->
<div class="wp-block-columns is-style-columns_gap_32_4"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:wdl/paid-block-image-1 {"fontSizeClass":"font_size_ss"} -->
<div class="wp-block-wdl-paid-block-image-1 paid-block-image-1 font_size_ss" style="max-width:480px;margin-left:undefined;margin-right:undefined"><div class="paid-block-image-1__inner" style="aspect-ratio:400 / 340;border-radius:0.9em"><img src="https://placehold.jp/600x440.png" alt=""/><h3 class="name_plate" style="background-color:var(--color-main);border-color:var(--color-main);border-radius:0.2em;border-width:2px"><span class="sub">主任</span><span class="main">大阪 京子</span></h3></div></div>
<!-- /wp:wdl/paid-block-image-1 -->

<!-- wp:paragraph {"marginTopPc":"lw_margin_top_pc_20"} -->
<p class="lw_margin_top_pc_20">テキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:wdl/paid-block-image-1 {"fontSizeClass":"font_size_ss"} -->
<div class="wp-block-wdl-paid-block-image-1 paid-block-image-1 font_size_ss" style="max-width:480px;margin-left:undefined;margin-right:undefined"><div class="paid-block-image-1__inner" style="aspect-ratio:400 / 340;border-radius:0.9em"><img src="https://placehold.jp/600x440.png" alt=""/><h3 class="name_plate" style="background-color:var(--color-main);border-color:var(--color-main);border-radius:0.2em;border-width:2px"><span class="sub">主任</span><span class="main">大阪 京子</span></h3></div></div>
<!-- /wp:wdl/paid-block-image-1 -->

<!-- wp:paragraph {"marginTopPc":"lw_margin_top_pc_20"} -->
<p class="lw_margin_top_pc_20">テキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:wdl/paid-block-image-1 {"fontSizeClass":"font_size_ss"} -->
<div class="wp-block-wdl-paid-block-image-1 paid-block-image-1 font_size_ss" style="max-width:480px;margin-left:undefined;margin-right:undefined"><div class="paid-block-image-1__inner" style="aspect-ratio:400 / 340;border-radius:0.9em"><img src="https://placehold.jp/600x440.png" alt=""/><h3 class="name_plate" style="background-color:var(--color-main);border-color:var(--color-main);border-radius:0.2em;border-width:2px"><span class="sub">主任</span><span class="main">大阪 京子</span></h3></div></div>
<!-- /wp:wdl/paid-block-image-1 -->

<!-- wp:paragraph {"marginTopPc":"lw_margin_top_pc_20"} -->
<p class="lw_margin_top_pc_20">テキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->