<!-- wp:columns {"className":"is-style-columns_gap_32_4"} -->
<div class="wp-block-columns is-style-columns_gap_32_4"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:wdl/paid-block-image-1 {"aspectRatioW":600,"aspectRatioH":440,"maxWidth":800,"innerRadiusEm":0,"showNamePlate":false} -->
<div class="wp-block-wdl-paid-block-image-1 paid-block-image-1 font_size_m" style="max-width:800px;margin-left:undefined;margin-right:undefined"><div class="paid-block-image-1__inner" style="aspect-ratio:600 / 440;border-radius:0em"><img src="https://placehold.jp/600x440.png" alt=""/></div></div>
<!-- /wp:wdl/paid-block-image-1 --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:wdl/custom-title-5 {"subTitle":"","mainTitle":"見出しタイトル","headingLevel":3,"fontSize":"s","marginTopPc":"lw_margin_top_pc_0"} -->
<h3 class="wp-block-wdl-custom-title-5 custom-title-5 font_size_s lw_margin_top_pc_0" style="border-color:var(--color-main)"><span class="main">見出しタイトル</span></h3>
<!-- /wp:wdl/custom-title-5 -->

<!-- wp:paragraph -->
<p class="">テキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキストテキスト</p>
<!-- /wp:paragraph -->

<!-- wp:wdl/lw-button-01 {"maxWidth":280,"maxWidthSp":1000,"marginTop":20,"marginBottom":20,"alignment":"flex-start"} -->
<div class="wp-block-wdl-lw-button-01 wp-block-wdl-button-01 padding-M align-flex-start align-sp-center" style="margin-top:20px;margin-bottom:20px;--button-01-max-width-sp:1000px"><a href="" style="max-width:280px;font-size:100%;background-color:var(--color-main);color:#ffffff;padding:0.9em 1.4em;text-align:center;text-decoration:none;border-radius:0px;border-width:0px;border-style:none;border-color:#000000">詳細はこちら</a></div>
<!-- /wp:wdl/lw-button-01 --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->