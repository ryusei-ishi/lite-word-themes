<?php
if ( !defined( 'ABSPATH' ) ) exit;
function register_custom_block_categories($categories, $post) {
    // カスタムカテゴリーを配列で定義
    $custom_categories = array(
        array(
            'slug'  => 'liteword-firstview',
            'title' => 'LiteWord ファーストビュー',
            'icon'  => 'format-image', // カテゴリーのアイコン（任意のアイコン名に変更可能）
        ),
        array(
            'slug'  => 'liteword-title',
            'title' => 'LiteWord タイトル',
            'icon'  => 'columns',
        ),
        array(
            'slug'  => 'liteword-other',
            'title' => 'LiteWord ブロック',
            'icon'  => 'columns',
        ),
        array(
            'slug'  => 'liteword-buttons',
            'title' => 'LiteWord リンクボタン',
            'icon'  => 'button',
        ),
        array(
            'slug'  => 'liteword-banner',
            'title' => 'LiteWord リンクバナー系',
            'icon'  => 'columns',
        ),
        array(
            'slug'  => 'liteword-comment',
            'title' => 'LiteWord 吹き出しコメント',
            'icon'  => 'format-chat',
        ),
        // さらに必要なカテゴリーを追加できます
    );

    // カテゴリーを「デザイン」の下に挿入
    $design_category_index = array_search('design', array_column($categories, 'slug'));

    if ($design_category_index !== false) {
        // 「デザイン」カテゴリーの次にカスタムカテゴリーを挿入
        array_splice($categories, $design_category_index + 1, 0, $custom_categories);
    } else {
        // 「デザイン」カテゴリーが存在しない場合、カスタムカテゴリーを末尾に追加
        $categories = array_merge($categories, $custom_categories);
    }

    return $categories;
}
add_filter('block_categories_all', 'register_custom_block_categories', 10, 2);
