<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * 指定 template_id が active_flag = 1 で登録されているか判定
 * ------------------------------------------------------------
 * @param string $template_id
 * @return bool
 */
function lw_template_is_active( $template_id_1 = "", $template_id_2 = "" ) {
    // 両方とも空の場合は false を返す
    if ( empty($template_id_1) && empty($template_id_2) ) {
        return false;
    }
    
    $templateSetting = new LwTemplateSetting();
    $is_active_1 = false;
    $is_active_2 = false;
    
    // 1つ目のテンプレートIDが空でない場合のみチェック
    if ( !empty($template_id_1) ) {
        $row_1 = $templateSetting->get_template_setting_by_id( $template_id_1 );
        $is_active_1 = $row_1 && intval( $row_1['active_flag'] ) === 1;
    }
    
    // 2つ目のテンプレートIDが空でない場合のみチェック
    if ( !empty($template_id_2) ) {
        $row_2 = $templateSetting->get_template_setting_by_id( $template_id_2 );
        $is_active_2 = $row_2 && intval( $row_2['active_flag'] ) === 1;
    }
    
    // どちらかがアクティブであれば true を返す
    return $is_active_1 || $is_active_2;
}

/**
 * すべての有料ブロックディレクトリを取得
 * ------------------------------------------------------------
 * サブスクリプション契約者または試用期間中の場合、
 * すべての paid-block-* を返す
 * @return array
 */
function lw_all_paid_block_dirs() {

	// サブスクリプション契約者の確認
	$is_subscription_active = lw_template_is_active( 'paid-lw-parts-sub-hbjkjhkljh',"sub_pre_set" );
	
	// 試用期間の確認
	$is_trial_active = false;
	if ( function_exists( 'lw_is_trial_active' ) ) {
		$is_trial_active = lw_is_trial_active();
	}
	
	// サブスクリプション契約者でも試用期間中でもない場合は空配列を返す
	if ( ! $is_subscription_active && ! $is_trial_active ) {
		return [];
	}

	/* テーマ内 /my-blocks/build/paid-block-* を走査 */
	$dir_paths = glob(
		get_theme_file_path( '/my-blocks/build/paid-block-*' ),
		GLOB_ONLYDIR
	);

	$block_names = array_map( 'basename', $dir_paths ); // 'paid-block-xxx' だけにする
	return $block_names;
}

/**
 * エディター用動的CSS読み込みスクリプトを登録
 * ------------------------------------------------------------
 */
function wdl_enqueue_editor_dynamic_loader() {
	// エディター画面でのみ読み込み
	if ( is_admin() ) {
		$script_path = '/my-blocks/build/editor-dynamic-styles.js';
		$script_file = get_theme_file_path( $script_path );
		
		if ( file_exists( $script_file ) ) {
			wp_enqueue_script(
				'wdl-editor-dynamic-styles',
				get_theme_file_uri( $script_path ),
				['wp-data', 'wp-blocks', 'wp-dom-ready'],
				filemtime( $script_file ),
				true
			);
			
			wp_localize_script(
				'wdl-editor-dynamic-styles',
				'MyThemeSettings',
				[
					'homeUrl'  => home_url(),
					'themeUrl' => get_template_directory_uri(),
					'adminUrl' => admin_url(),
				]
			);
		}
	}
}
add_action( 'enqueue_block_editor_assets', 'wdl_enqueue_editor_dynamic_loader' );

/* =============================================================
 * ブロック登録メイン関数
 * =========================================================== */
function wdl_register_blocks() {

	/* ---------- 1) LiteWord 標準ブロック一覧 ---------- */
	$block_files = [
		"lw-my-parts-embed",
		"cta-1",
		"cta-2",
		"custom-title-1",
		"custom-title-2",
		"custom-title-3",
		"custom-title-4",
		"custom-title-5",
		"custom-title-6",
		"custom-title-accordion-1",
		"fv-1",
		"fv-2",
		"fv-3",
		"fv-4",
		"fv-5",
		"fv-6",
		"fv-7",
		"lw-banner-info-01",
		"lw-banner-info-02",
		"lw-banner-info-03",
		"lw-banner-info-04",
		"lw-banner-info-05",
		"lw-button-1",
		"lw-button-2",
		"lw-button-3",
		"lw-comment-1",
		"lw-company-1",
		"lw-company-2",
		"lw-contact-3",
		"lw-content-1",
		"lw-content-2",
		"lw-content-8",
		"lw-gallery-01",
		"lw-gallery-02",
		"lw-list-1",
		"lw-list-2",
		"lw-list-3",
		"lw-list-4",
		"lw-link-list-1",
		"lw-image-2",
		"lw-message-1",
		"lw-news-list-1",
		"lw-page-list-1",
		"lw-post-list-1",
		"lw-post-list-2",
		"lw-post-list-3",
		"lw-step-1",
		"lw-step-2",
		"lw-qa-1",
		"lw-voice-1",
		"profile-1",
		"solution-1",
		"lw-space-1",
		"lw-bg-1",
		
		
	];
	//プレミアム限定ブロック
	if(LW_HAS_SUBSCRIPTION === true){
		array_push($block_files, 
			"lw-pr-text-1",
			"lw-pr-table-1",
			"lw-pr-calendar-1",
			"lw-pr-button-1",
			"lw-pr-button-2",
			"lw-pr-button-3",
			"lw-pr-button-4",
			"lw-pr-button-5",
			"lw-pr-button-6",
			"lw-pr-button-7",
			"lw-pr-button-8",
			"lw-pr-button-9",
			"lw-pr-button-10",
			"lw-pr-custom-title-11",
			"lw-pr-custom-title-12",
			"lw-pr-custom-title-13",
			"lw-pr-custom-title-14",
			"lw-pr-custom-title-15",
			"lw-pr-custom-title-16",
			"lw-pr-fv-13",
			"lw-pr-fv-14",
			"lw-pr-fv-15",
			"lw-pr-fv-16",
			"lw-pr-fv-17",
		);
	}
	/* ---------- 2) 有料テンプレートに紐付くブロック ---------- */
	foreach ( lw_active_template_ids() as $block_name ) {
		if ( strpos( $block_name, 'paid-block-' ) !== false ) {
			$block_files[] = $block_name;
		}
	}
	foreach ( lw_active_page_template() as $block_name ) {
		$block_files[] = $block_name;
	}

	/* ---------- 3) 特別ルール：paid-block 全解放 ---------- */
	$block_files = array_merge( $block_files, lw_all_paid_block_dirs() );

	/* ---------- 4) 重複排除 ---------- */
	$block_files = array_values( array_unique( $block_files ) );
	/* ---------- 4.5) 買い切り専用ブロックを除外 ---------- */
	$block_Outright_purchase_only = block_Outright_purchase_only();
	if ( ! empty( $block_Outright_purchase_only ) ) {
		$block_files = array_diff( $block_files, $block_Outright_purchase_only );
		$block_files = array_values( $block_files );
	}

	/* ---------- 5) 各ブロックの登録処理 ---------- */
	foreach ( $block_files as $block_name ) {

		$block_dir        = "/my-blocks/build/{$block_name}/";
		$js_file          = get_theme_file_path( "{$block_dir}{$block_name}.js" );
		$editor_css_file  = get_theme_file_path( "{$block_dir}editor.css" );
		$style_css_file   = get_theme_file_path( "{$block_dir}style.css" );

		/* --- JS が無ければ登録しない --- */
		if ( ! file_exists( $js_file ) ) {
			continue;
		}

		/* --- 5-1. スクリプト / アセット登録 --- */
		$asset_file = get_theme_file_path( "{$block_dir}{$block_name}.asset.php" );
		$asset      = file_exists( $asset_file )
			? include( $asset_file )
			: [ 'dependencies' => [], 'version' => filemtime( $js_file ) ];

		wp_register_script(
			"wdl-{$block_name}-script",
			get_theme_file_uri( "{$block_dir}{$block_name}.js" ),
			$asset['dependencies'],
			$asset['version'],
			true
		);

		/* --- ローカライズ --- */
		wp_localize_script(
			"wdl-{$block_name}-script",
			'MyThemeSettings',
			[
				'homeUrl'  => home_url(),
				'themeUrl' => get_template_directory_uri(),
				'adminUrl' => admin_url(),
			]
		);

		/* --- 5-2. エディタ用スタイル（動的読み込み用に登録のみ） --- */
		if ( file_exists( $editor_css_file ) ) {
			wp_register_style(
				"wdl-{$block_name}-editor-style",
				get_theme_file_uri( "{$block_dir}editor.css" ),
				[ 'wp-edit-blocks' ],
				filemtime( $editor_css_file )
			);
		}

		/* --- 5-3. フロント用スタイル（動的読み込み用に登録のみ） --- */
		if ( file_exists( $style_css_file ) ) {
			wp_register_style(
				"wdl-{$block_name}-style",
				get_theme_file_uri( "{$block_dir}style.css" ),
				[],
				filemtime( $style_css_file )
			);
		}

		/* --- 5-4. ブロックタイプ登録 --- */
		if ( is_admin() ) {
			/** エディタ（管理画面）側 - CSSは動的読み込みに変更 **/
			register_block_type(
				"wdl/{$block_name}",
				[
					'editor_script' => "wdl-{$block_name}-script",
					// CSS は JavaScript で動的読み込みするため初期では読み込まない
					'editor_style'  => null,
					'style'         => null,
				]
			);
		} else {
			/** フロント側 **/
			register_block_type(
				"wdl/{$block_name}",
				[
					// 初期ロードでは CSS を読み込まない（lazy）
					'style'           => null,
					'render_callback' => function ( $attributes, $content ) use ( $block_name, $style_css_file ) {
						static $loaded_styles = [];

						// まだ読み込んでいなければ enqueue
						if ( ! is_admin() && file_exists( $style_css_file ) && ! in_array( $block_name, $loaded_styles, true ) ) {
							wp_enqueue_style( "wdl-{$block_name}-style" );
							$loaded_styles[] = $block_name;
						}
						return $content;
					},
				]
			);
		}
	}
}
add_action( 'init', 'wdl_register_blocks' );