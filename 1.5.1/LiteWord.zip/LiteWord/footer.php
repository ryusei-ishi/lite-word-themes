<?php 
if ( !defined( 'ABSPATH' ) ) exit; 
wp_footer(); ?>   
</body>
</html>

